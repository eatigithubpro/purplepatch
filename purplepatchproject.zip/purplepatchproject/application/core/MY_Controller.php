<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/* load the MX_Router class */
require APPPATH . "third_party/MX/Controller.php";

class MY_Controller extends MX_Controller
{	

	function __construct() 
	{
		parent::__construct();
		$this->_hmvc_fixes();
	}
	
	function _hmvc_fixes()
	{		
		//fix callback form_validation		
		//https://bitbucket.org/wiredesignz/codeigniter-modular-extensions-hmvc
		$this->load->library('form_validation');
		$this->form_validation->CI =& $this;
	}


	public function render($page='',$customData=''){

			$this->load->view('templates/header');

		if(!empty($customData)){
			$this->load->view($page,$customData);
		}else{
			$this->load->view($page);
		}
		$this->load->view('templates/footer');
	}
	public function loadContaint($page='',$customData=''){

		$data['setting'] = $this->Commonmodel->getRow("custom_setting");

		$this->load->view('blinkeye/common/header',$data);
		//echo Modules::run('blinkEye/common/header/index');
		if(!empty($customData)){
			$this->load->view($page,$customData);
		}else{
			$this->load->view($page);
		}
		$this->load->view('blinkeye/common/footer');
		//echo Modules::run('blinkEye/common/footer/index');	
	}

}
