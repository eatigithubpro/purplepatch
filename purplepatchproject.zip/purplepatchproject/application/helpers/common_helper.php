<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('convertDateFormat')) {
	function convertDateFormat($date,$format)
	{
		$Newdate = date_create($date);
		return date_format($Newdate,$format);

	    
	}
}

// ---------------- All function created by Randheer singh ----------------------

if (!function_exists('browser_info')) {
	function browser_info($agent=null) {
			$u_agent = $_SERVER['HTTP_USER_AGENT']; 
			$bname = 'Unknown';
			$platform = 'Unknown';
			$version= "";

			//First get the platform?
			if (preg_match('/linux/i', $u_agent)) {
			    $platform = 'linux';
			}
			elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
			    $platform = 'mac';
			}
			elseif (preg_match('/windows|win32/i', $u_agent)) {
			    $platform = 'windows';
			}

			// Next get the name of the useragent yes seperately and for good reason
			if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) 
			{ 
			    $bname = 'Internet Explorer'; 
			    $ub = "MSIE"; 
			} 
			elseif(preg_match('/Firefox/i',$u_agent)) 
			{ 
			    $bname = 'Mozilla Firefox'; 
			    $ub = "Firefox"; 
			} 
			elseif(preg_match('/Chrome/i',$u_agent)) 
			{ 
			    $bname = 'Google Chrome'; 
			    $ub = "Chrome"; 
			} 
			elseif(preg_match('/Safari/i',$u_agent)) 
			{ 
			    $bname = 'Apple Safari'; 
			    $ub = "Safari"; 
			} 
			elseif(preg_match('/Opera/i',$u_agent)) 
			{ 
			    $bname = 'Opera'; 
			    $ub = "Opera"; 
			} 
			elseif(preg_match('/Netscape/i',$u_agent)) 
			{ 
			    $bname = 'Netscape'; 
			    $ub = "Netscape"; 
			} 

			// finally get the correct version number
			$known = array('Version', $ub, 'other');
			$pattern = '#(?<browser>' . join('|', $known) .
			')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
			if (!preg_match_all($pattern, $u_agent, $matches)) {
			    // we have no matching number just continue
			}

			// see how many we have
			$i = count($matches['browser']);
			if ($i != 1) {
			    //we will have two since we are not using 'other' argument yet
			    //see if version is before or after the name
			    if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
			        $version= $matches['version'][0];
			    }
			    else {
			        $version= $matches['version'][1];
			    }
			}
			else {
			    $version= $matches['version'][0];
			}

			// check if we have a number
			if ($version==null || $version=="") {$version="?";}

			return array(
			    'userAgent' => $u_agent,
			    'name'      => $bname,
			    'version'   => $version,
			    'platform'  => $platform,
			    'pattern'    => $pattern
			);
			 
		}

	}
	// for make drowpdown of month date and year
	if (!function_exists('make_calendar_pulldown')) {
		function make_calendar_pulldown() {
		     $months = array (1 => 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');

		     echo '<select name="month" class="form-control">';
		     foreach ($months as $key => $value) {
		        echo "<option value=\"$key\">$value</option>\n";
		     }

		     echo '</select>
		     <select name="day" class="form-control">';
		     for ($day = 1; $day <= 31; $day++) {
		         echo "<option value=\"$day\">$day</option>\n";
		     }
		     echo '</select>

		     <select name="year" class="form-control">';
		    $year = 2003;
		     while ($year <= date('Y')) {
		         echo "<option value=\"$year\">$year</option>\n";
		         $year++;
		     }
		     echo '</select>';
	 	} // End of the make_calendar_pulldown() function.
	}
	
//money format
 if (!function_exists('AmountFormat')) {
	function AmountFormat($amount = '0', $symbal = '') {
		$amount = round($amount,2);
		$sign = '';
		if ( substr($amount, 0, 1) == '-'){
			$sign = '-';
			$amount = substr($amount, 1);
		}
		if($symbal == " ") {		// If you want the format without any symbol then pass space, ie: " "
			$amount = $sign . number_format($amount, 2,'.','');
		} else {
			$amount = $sign . $symbal . number_format($amount, 2);
		}
		return $amount;
		} 
	}

		

/***********datediff**********/
if (!function_exists('date_difference')) {
		function date_difference($earlierDate, $laterDate) {
			//returns an array of numeric values representing days, hours, minutes & seconds respectively
			$ret = array('days'=>0, 'hours'=>0, 'minutes'=>0, 'seconds'=>0);
			$totalsec = strtotime($laterDate) - strtotime($earlierDate);

			if ($totalsec >= 86400) {
				$ret['days'] = floor($totalsec/86400);
				$totalsec = $totalsec % 86400;
			}
			if ($totalsec >= 3600) {
				$ret['hours'] = floor($totalsec/3600);
				$totalsec = $totalsec % 3600;
			}
			if ($totalsec >= 60) {
				$ret['minutes'] = floor($totalsec/60);
			}
			$ret['seconds'] = $totalsec % 60;
			return $ret;
		}
	}
	
if (!function_exists('func_date_conversion')) {
		function func_date_conversion($date_format_source, $date_format_destiny, $date_str){
/*
		$df_src = 'Y-m-d';
		$df_des = 'd-m-Y';
		$final_Date=func_date_conversion($df_src, $df_des,date('Y-m-d'));
		echo $final_Date;
*/
		$base_format     = split('[:/.\ \-]', $date_format_source);
		$date_str_parts = split('[:/.\ \-]', $date_str );
		
		$date_elements = array();
		
		$p_keys = array_keys( $base_format );
		foreach ( $p_keys as $p_key )
		{
			if ( !empty( $date_str_parts[$p_key] ))
			{
				$date_elements[$base_format[$p_key]] = $date_str_parts[$p_key];
			}
			else
				return false;
		}
		
		if (array_key_exists('M', $date_elements)) {
			$Mtom = array(
				"Jan" => "01",
				"Feb" => "02",
				"Mar" => "03",
				"Apr" => "04",
				"May" => "05",
				"Jun" => "06",
				"Jul" => "07",
				"Aug" => "08",
				"Sep" => "09",
				"Oct" => "10",
				"Nov" => "11",
				"Dec" => "12",
			);
			$date_elements['m']=$Mtom[$date_elements['M']];
		}
		
		$dummy_ts = mktime($date_elements['H'], $date_elements['i'], $date_elements['s'], $date_elements['m'], $date_elements['d'], $date_elements['Y'] );
		
		return date( $date_format_destiny, $dummy_ts );
		}

	}
	
/**

	For encrypt of Selected String
 */

if (!function_exists('encryptor')) {

    function encryptor($string) {
        $output = false;

        $encrypt_method = "AES-256-CBC";
        //pls set your unique hashing key
        $secret_key = 'e@c@l@i@c@k';
        $secret_iv = 'S3cur3';

        // hash
        $key = hash('sha512', $secret_key);

        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha512', $secret_iv), 0, 16);

        //do the encyption given text/string/number

        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);

        return $output;
    }

}
/**
	For Decrypt of encrypted value
 */
if (!function_exists('decryptor')) {

    function decryptor($string) {
        $output = false;

        $encrypt_method = "AES-256-CBC";
        //pls set your unique hashing key
        $secret_key = 'e@c@l@i@c@k';
        $secret_iv = 'S3cur3';

        // hash
        $key = hash('sha512', $secret_key);

        // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
        $iv = substr(hash('sha512', $secret_iv), 0, 16);
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);


        return $output;
    }

}



if (!function_exists('strip_html_tags')) {

    /**
 * Remove HTML tags, including invisible text such as style and
 * script code, and embedded objects.  Add line breaks around
 * block-level tags to prevent word joining after tag removal.
 */
    function strip_html_tags($text)
    {
        $text = preg_replace(
        array(
          // Remove invisible content
            '@<head[^>]*?>.*?</head>@siu',
            '@<style[^>]*?>.*?</style>@siu',
            '@<script[^>]*?.*?</script>@siu',
            '@<object[^>]*?.*?</object>@siu',
            '@<embed[^>]*?.*?</embed>@siu',
            '@<applet[^>]*?.*?</applet>@siu',
            '@<noframes[^>]*?.*?</noframes>@siu',
            '@<noscript[^>]*?.*?</noscript>@siu',
            '@<noembed[^>]*?.*?</noembed>@siu',
          // Add line breaks before and after blocks
            '@</?((address)|(blockquote)|(center)|(del))@iu',
            '@</?((div)|(h[1-9])|(ins)|(isindex)|(p)|(pre))@iu',
            '@</?((dir)|(dl)|(dt)|(dd)|(li)|(menu)|(ol)|(ul))@iu',
            '@</?((table)|(th)|(td)|(caption))@iu',
            '@</?((form)|(button)|(fieldset)|(legend)|(input))@iu',
            '@</?((label)|(select)|(optgroup)|(option)|(textarea))@iu',
            '@</?((frameset)|(frame)|(iframe))@iu',
          ),
          array(
            ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ',
            "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0", "\n\$0",
            "\n\$0", "\n\$0",
          ),
           $text );
           return strip_tags( $text );
    }

}



   /**
	To Get login user details 
 */
 
if (!function_exists('getLoginUserDetails')) {

    function getLoginUserDetails() {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		// $CI->load->model('Emploginmodel');
		$CI->load->model('Adminmodel');
			$session_data=($CI->session->userdata("session_info"));
			$loginId=$session_data['id'];
			// $Companyid=$session_data['CreatedBy'];
			$data=array();
			$data['loginUserData']=$CI->Adminmodel->getRow("users","id='$loginId'");
			
			return $data; 
    }

}

if (!function_exists('getLoginUserPermission')) {
    function getLoginUserPermission($id='') {
    	$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$loginData=getLoginUserDetails();
		$roleId=$loginData['loginUserData'][0]['role_has_permission_id'];
		$result=$CI->Adminmodel->getRow("role_has_permissions","id='$roleId'");
		return $result[0];
    }
}


 
//---------------------------Notification Details------------------

if (!function_exists('getNotificationDetails')) {

    function getNotificationDetails($id="",$roleId="") {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Emploginmodel');
		$CI->load->model('Adminmodel');
			$condtion="company_id='$id' and roleid='$roleId' and Status='0'";
			$data['getNotificationData']=$CI->Adminmodel->getRow("notification",$condtion);
			return $data; 
    }

}

//---------------------------For Check Duplicate Value Details------------------on

if (!function_exists('checkDuplicateValue')) {
    function checkDuplicateValue($table,$condition) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$CI->db->select("*")->from($table)->where($condition);
		$query = $CI->db->get();	
		if ($query->num_rows() > 0) {
			return $query->num_rows();;
		} else {
			return 0;
		}
	}
}

//---------------------------For Check Duplicate Value Details------------------on

if (!function_exists('getValues')) {

    function getValues($table,$condition) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$CI->db->select("*")->from($table)->where($condition);
		$query = $CI->db->get();	
			if ($query->num_rows() > 0) {
				//echo $CI->db->last_query();
				return $query->result_array();
			} else {
				return 0;
			} 
    
	}
}

/**
	To gernerate random number
 */
if (!function_exists('random_number')) {

    function random_number($length) {
	    $chars = "0123456789";
	    $password = substr( str_shuffle( $chars ), 0, $length );
	    return $password;
	}
}

/**
	To Generate random po number 
 */
 
if (!function_exists('random_po_number')) {

    function random_po_number($length) {
	    $chars = "ASDFGHJKLMNBVCXZQWERTYUIOP0123456789asdfghjklqwertyuiopzxcvbnm";
	    $password = substr( str_shuffle( $chars ), 0, $length );
	    return $password;
	}
}



if (!function_exists('charNo')) {

    function charNo($length) {
	    $chars = "ASDFGHJKLMNBVCXZQWERTYUIOP";
	    $password = substr( str_shuffle( $chars ), 0, $length );
	    return $password;
	}
}
//------------------For Dynamic Breadcumb------------------------

if(!function_exists('generateBreadcrumb')){
	
	function generateBreadcrumb(){
		  $ci = &get_instance();
		  $i=1;
		  $uri = $ci->uri->segment($i);
		  $link = '
		  <ul class="breadcrumb">';

		  while($uri != ''){
			$prep_link = '';
		  for($j=1; $j<=$i;$j++){
			$prep_link .= $ci->uri->segment($j).'/';
		  }

		  if($ci->uri->segment($i+1) == ''){

			$link.='<li class="active"><a href="'.site_url($prep_link).'">';
			$link.=strtoupper(str_replace(array('_','-'),array(' ',' '),$ci->uri->segment($i))).'</a></li> ';
		  }else{
			$link.='<li><a href="'.site_url($prep_link).'">';
			$link.=strtoupper($ci->uri->segment($i)).'</a></li> ';
		  }

		  $i++;
		  $uri = $ci->uri->segment($i);
		  }
			$link .= '</ul>';
			return $link;
		}
	}

	/**
	For custom pagination 
 */
if(!function_exists('get_pagination')){
	
	function get_pagination(){
            $config['base_url'] = base_url().'itemlist/index/';
            $config['total_rows'] = $this->db->get('item')->num_rows();
            $config['per_page'] = 4;
            $config['num_links'] = 5;

            $config['full_tag_open'] = '<ul class="pagination pagination-sm">';
            $config['full_tag_close'] = '</ul><!--pagination-->';

            $config['first_link'] = '&laquo;';
            $config['first_tag_open'] = '<li class="prev page">';
            $config['first_tag_close'] = '</li>';
//
            $config['last_link'] = '&raquo;';
            $config['last_tag_open'] = '<li class="next page">';
            $config['last_tag_close'] = '</li>';
//
            $config['next_link'] = '&rarr;';
            $config['next_tag_open'] = '<li class="next page">';
            $config['next_tag_close'] = '</li>';
//
            $config['prev_link'] = '&larr;';
            $config['prev_tag_open'] = '<li class="prev page">';
            $config['prev_tag_close'] = '</li>';

            $config['cur_tag_open'] = '<li class="active"><a href="">';
            $config['cur_tag_close'] = '</a></li>';

            $config['num_tag_open'] = '<li class="page">';
            $config['num_tag_close'] = '</li>';
 
            $this->pagination->initialize($config);
		}
	}
/**
	For csrf prtection 
 */	
	//------------------For Dynamic Breadcumb------------------------

if (!function_exists('printArray')) {
    function printArray($array){
       echo"<pre>";
       print_r($array);
        echo"</pre>";
    }
}

// get hour and minutes
if (!function_exists('get_hr_min')) {
    function get_hr_min($t){
	    $h = floor($t/60) ? floor($t/60) .' hours' : '';
	    $m = $t%60 ? $t%60 .' minutes' : '';
	    return $h && $m ? $h.' and '.$m : $h.$m;
    }
}


// get hour and minutes
if (!function_exists('year_list')) {
	function year_list($startYear, $endYear, $id="year"){ 
    //start the select tag 
	        for ($i=$endYear;$i>=$startYear;$i--){ 
	        echo "<option value=".$i.">".$i."</option>";     
	        } 
		}
	}

	//---------------------------Notification Details------------------

if (!function_exists('saveNotification')) {
    function saveActionPerform($data) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$result=$CI->Adminmodel->savedata("action",$data);
		return $result; 
    }
}


if (!function_exists('getConnectRelationWithName')) {

    function getConnectRelationWithName($condtion) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$CI->load->model('Common_model');
		$sql="select CONCAT(first_name,' ',last_name) as Name FROM users where $condtion";
		
		return $result; 
    }

}

	//---------------------------Notification Details------------------

if (!function_exists('getReverseRelation')) {

    function getReverseRelation($data) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$result=$CI->Adminmodel->getRow("relation ",$data)[0];
		return $result; 
    }

}

if (!function_exists('getReferralOrReferre')) {

    function getReferralOrReferre($data) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$result=$CI->Adminmodel->getRow("connect_with_each_other",$data)[0];
		return $result; 
    }

}
// get hour
if (!function_exists('hour_list')) {
	function hour_list(){ 
//start the select tag 
        for ($i='00';$i<='23';$i++){ 
        echo "<option value=".$i.">".$i."</option>";     
        } 
	}
}


// get minutes
if (!function_exists('min_list')) {
	function min_list(){ 
//start the select tag 
        for ($j='00';$j<='59';$j++){ 
        echo "<option value=".$j.">".$j."</option>";     
        } 
	}
}


if (!function_exists('groupName')) {

    function groupName($condit='',$condit1='' ) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
			$session_data=($CI->session->userdata("session_info"));
			
			$data=array();
			$sql="SELECT group_type FROM manage_group WHERE $condit";
			$sql1="SELECT count FROM major_activity WHERE $condit1";
			//echo $sql1; exit;
			$query = $CI->db->query($sql);
			$query1 = $CI->db->query($sql1);
		//return $this->db->last_query();
		if ($query->num_rows() > 0) {
	 	 	$values=$query1->result_array();
	 	 	$result=$query->result_array();

	 	 	$datas=[];
	 	 	for($i=0;$i<count($result);$i++){
	 	 		$data['group_type']=$result[$i]['group_type'];
	 	 		array_push($datas,$data);

	 	 	}
	 	 		return $datas;
		} else {
	   		return false;
	  	} 
    }

}

if (!function_exists('majorActivityCount')) {

    function majorActivityCount($condit='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
			$session_data=($CI->session->userdata("session_info"));
			$data=array();
			//program_id=23
			//$sql="SELECT SUM(SPLIT_STR(count, ',', 1) + SPLIT_STR(count, ',', 2)) as total FROM major_activity WHERE $condit";
			$sql="SELECT * FROM major_activity WHERE $condit";
			$query = $CI->db->query($sql);
			if ($query->num_rows() > 0) {
				$inputs=$query->result_array();
				$sum = 0;
				foreach($inputs as $input){
					
					$res = explode(',',$input['count']);
					$result = array_sum($res);
					 $sum+= $result;
					//array_push($sum,$result);
				}
				
		 	 return intval($sum);
			} else {
		   		return false;
		  	} 
   	 	}
	}

if (!function_exists('get_string_between')) {

   function get_string_between($string, $start, $end){
	    $string = ' ' . $string;
	    $ini = strpos($string, $start);
	    if ($ini == 0) return '';
	    $ini += strlen($start);
	    $len = strpos($string, $end, $ini) - $ini;
	    return substr($string, $ini, $len);
		}

	}
	
if (!function_exists('refreshAfterSomeTime')) {

   function refreshAfterSomeTime($time, $location){
	   		header("Refresh: 1; url=".base_url().'team-member/dashboard');
		}

	}
	// to get permission list 
if (!function_exists('getPermission')) {

   	function getPermission($condition=''){
		$CI = get_instance();
		$CI->load->database();
		$CI->load->library('session');

		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));
		$data=array();

		if(empty($condition)){
			$result=$CI->Adminmodel->getRow("user_permission");
		}else{
			$result=$CI->Adminmodel->getRow("user_permission",$condition);
		}


		if (count($result[0])>0) {
			return $result;
		}else {
			return false;
		} 
   	}
	

}
	
	if (!function_exists('saveConnect')) {

    function saveConnect($data) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));
		$CI->db->insert("connect_with_each_other", $data);
   	 	}
	}

if (!function_exists('getConnectId')) {

    function getConnectId($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT GROUP_CONCAT(connected_with_id) as connectedId FROM  connect_with_each_other  WHERE user_id='$condition'";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}

if (!function_exists('getConnectIdonly')) {

    function getConnectIdonly($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT GROUP_CONCAT(connected_with_id) as connectedId FROM  connect_with_each_other  WHERE user_id='$condition' and referral_or_connect='Connection'";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}

if (!function_exists('getGenderUsingName')) {

    function getGenderUsingName($name='') {
		$response = json_decode(file_get_contents("https://genderapi.io/api/?name=".$name));
		if($response->gender == 'null'){
			return "M";
		}else if($response->gender == "male"){
				return "M";
		}else{
			return "F";
		}
			
			exit;
   	}
}

if (!function_exists('aes128Encrypt')) {

    function aes128Encrypt($str,$key='') {
		$block = mcrypt_get_block_size('rijndael_128', 'ecb');
		$pad = $block - (strlen($str) % $block);
		$str .= str_repeat(chr($pad), $pad);
		return base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $key, $str, MCRYPT_MODE_ECB));
   	}
}



if (!function_exists('getCityStateId')) {

   	function getCityStateId($condition=''){
		$CI = get_instance();
		$CI->load->database();
		$CI->load->library('session');

		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));
		$data=array();
		$result=$CI->Adminmodel->getRow("cities",$condition);
		if (count($result[0])>0) {
			return $result;
		}else {
			return false;
		} 
   	}
	

}

if (!function_exists('getStageName')) {
    function getStageName($id) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$sql="SELECT CONCAT(name,'-',description) as stageName FROM stage WHERE id='$id'";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	}
    }
}

  if (!function_exists('getConnectIdList')) {

    function getConnectIdList($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT GROUP_CONCAT(connected_with_id) as connectedId FROM  connect_with_each_other  WHERE $condition";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}

if (!function_exists('getProgramId')) {

    function getProgramId($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT GROUP_CONCAT(id ORDER BY campus,str_to_date(from_date,'%d-%m-%Y'),id ASC) as programId FROM  program  WHERE $condition";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}
 if (!function_exists('getparentMobileNo')) {
    function getparentMobileNo($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT mobile_no FROM  users  WHERE $condition";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}

if (!function_exists('getparentName')) {

    function getparentName($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT CONCAT(first_name,' ',last_name) as name FROM  users  WHERE $condition";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}

if (!function_exists('getConnectParentonly')) {

    function getConnectParentonly($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT GROUP_CONCAT(connected_with_id) as connectedId FROM  connect_with_each_other  WHERE $condition";
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}


if (!function_exists('getConnectIdFromUsers')) {

    function getConnectIdFromUsers($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT GROUP_CONCAT(id) as connectedId FROM  users  WHERE $condition";
		
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}

if (!function_exists('getPermissionName')) {

    function getPermissionName($condition='') {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		
		$CI->load->model('Adminmodel');
		$session_data=($CI->session->userdata("session_info"));

		$sql="SELECT GROUP_CONCAT(name SEPARATOR '<br>') as permissionName FROM instructor WHERE $condition";
		
		//echo $sql; exit;
		$query = $CI->db->query($sql);
	
		if ($query->num_rows() > 0) {
	 	 	$result=$query->result_array();
	 	 		return $result;
		} else {
	   		return false;
	  	} 
   	}
}
	// for save meta details//
if (!function_exists('saveMetaDetails')) {
    function saveMetaDetails($data,$page) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$CI->load->model('Commonmodel');
		if($CI->Commonmodel->countResult("page","url_name='$page'")>0) {
			$result=$CI->Commonmodel->updateRow("page",$data,"url_name='$page'");
		}else{
			$data['url_name']	= $page;
			$data['name']    	= $page;
			$result=$CI->Commonmodel->savedata("page",$data);
		}
		
		return $result; 
    }
}


// upload image 
if (!function_exists('addImages')) {
 	function addImages($filesName,$fileTempName)
    {    
    	$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
        $CI->load->library('S3_upload');
        $CI->load->library('S3');
    		$type1 = explode(".", $filesName);	
			$type1 = end($type1);
			$file_name=time().uniqid().".".$type1;
		$dir = dirname($fileTempName);
        $destination = $dir . DIRECTORY_SEPARATOR . $file_name;
        rename($fileTempName, $destination);
        $upload = $CI->s3_upload->upload_file($destination);
        return $upload;

        	/*$type1 = explode(".", $filesName);	
			$type1 = end($type1);
			$upload_dir = "assets/uploads/";
			$file_name=time().uniqid().".".$type1;
			$upload_file = $upload_dir.$file_name;
			if(move_uploaded_file($fileTempName,$upload_file)){
				$source_image = $upload_file;
				$image_destination = $upload_dir."min".$file_name;
				$compress_images = compressImage($source_image, $image_destination);
				if($compress_images){

					$dir = dirname($fileTempName);
        			$destination = $dir . DIRECTORY_SEPARATOR . $file_name;
					$dest = imagecreatefromjpeg($destination);
					$src = imagecreatefromjpeg($image_destination); 

					// Copy and merge 
					imagecopymerge($dest, $src, 10, 10, 0, 0, 500, 200, 75); 

					// Output and free from memory 
					header('Content-Type: image/gif'); 
					imagegif($dest); 

					imagedestroy($dest); 
					imagedestroy($src);

					return $destination;
				}
					
			} */

    	


    	/*$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
        $CI->load->library('S3_upload');
        $CI->load->library('S3');
        
 			$dir = dirname($fileTempName);
            $destination = $dir . DIRECTORY_SEPARATOR . $filesName;
            rename($fileTempName, $destination);
            $upload = $CI->s3_upload->upload_file($destination);
            return $upload;*/

    	/*$filesCount = count($_FILES['files']['name']);
        for($i = 0; $i < $filesCount; $i++){
            $_FILES['file']['name']     = $_FILES['files']['name'][$i];
            $_FILES['file']['type']     = $_FILES['files']['type'][$i];
            $_FILES['file']['tmp_name'] = $_FILES['files']['tmp_name'][$i];
            $_FILES['file']['error']    = $_FILES['files']['error'][$i];
            $_FILES['file']['size']     = $_FILES['files']['size'][$i];
            $dir = dirname($_FILES["file"]["tmp_name"]);
            $destination = $dir . DIRECTORY_SEPARATOR . $_FILES["file"]["name"];
            rename($_FILES["file"]["tmp_name"], $destination);
            $upload = $CI->s3_upload->upload_file($destination);
            echo $upload; exit;            
        }    */ 
    }
}

function compressImage($source_image, $compress_image) {
	$image_info = getimagesize($source_image);
	if ($image_info['mime'] == 'image/jpeg') {
		$source_image = imagecreatefromjpeg($source_image);
		imagejpeg($source_image, $compress_image, 75);
	}elseif ($image_info['mime'] == 'image/jpg') {
		$source_image = imagecreatefromjpeg($source_image);
		imagegif($source_image, $compress_image, 75);
	} elseif ($image_info['mime'] == 'image/gif') {
		$source_image = imagecreatefromgif($source_image);
		imagegif($source_image, $compress_image, 75);
	} elseif ($image_info['mime'] == 'image/png') {
		$source_image = imagecreatefrompng($source_image);
		imagepng($source_image, $compress_image, 6);
	}
	return $compress_image;
}


// for menu list 

if (!function_exists('getMenuList')) {
    function getMenuList() {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$CI->load->model('Commonmodel');
		$result = $CI->Commonmodel->getRow("master_page");
		return $result; 
    }
}
if (!function_exists('getIdUsingSlug')) {
    function getIdUsingSlug($slugName) {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$CI->load->model('Commonmodel');
		$result = $CI->Commonmodel->getRow("master_page","slug='$slugName'");
		if(count($result[0])>0){
			if(empty($result[0]['page_id'])){
				return 1;
			}else{
				return $result[0]['page_id']; 
			}
		}else{
			return 0;
		}
		
		
    }
}

if (!function_exists('sendmail')) {
	function sendmail($to,$subject,$message,$sharedEmail=''){
		$CI = get_instance();
		$CI->load->library("PhpMailerLib");
        $mail = $CI->phpmailerlib->load();

        // get set from and reply to dynamic
		$setting = getSetting();
		$setFrom = ($setting['getSettingData'][0]['emailFrom']);
		$addReplyTo = ($setting['getSettingData'][0]['emailTo']);

	    $mail->isSMTP();                                           
	    $mail->Host       = 'email-smtp.us-east-1.amazonaws.com'; 
	    $mail->SMTPAuth   = true;                                   
	    $mail->Username   = 'AKIAUDTIRMPCMJ6Y2GPP';
	    $mail->Password   = 'BGF8az2h/yJk9iik2mcuET5sHq0DDKifIX7mjLxQVNPT'; 
	    $mail->SMTPSecure = 'tls';                                  
	    $mail->Port       = 587;                                    
	    //Recipients
	    //$mail->setFrom('info@lgbtweddings.com', 'LGBTWeddings');
	    $mail->setFrom($setFrom, 'Mani-budapest');
	    $mail->addAddress($to);
	    $mail->addReplyTo($addReplyTo, 'Mani-budapest');
	    if(!empty($sharedEmail)){
			$mail->addCC($sharedEmail);
	    }
	   // $mail->addReplyTo('info@lgbtweddings.com', 'LGBTWeddings');
		//$mail->addCC($cc[$i]);
	    //$mail->addBCC('ajay.kumar@webfume.com');
	    // Attachments
	   // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
	   // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

	    // Content
	    $mail->isHTML(true);                                  // Set email format to HTML
	    $mail->Subject = $subject;
	    $mail->Body    = $message;
	    $mail->send();
	    /*if($mail->send()){
	    	echo"1";
	    }else{
	    	echo"0";
	    }*/
	}
}
if (!function_exists('customSetting')) {
    function customSetting() {
		$CI = get_instance();
		$CI->load->database();
        $CI->load->library('session');
		$CI->load->model('Adminmodel');
		$CI->load->model('Commonmodel');
		$result = $CI->Commonmodel->getRow("custom_setting");
		return $result;	
    }
}

?>