<?php

/************************************************
 * This Model file has been created by           *   
 * Randheer  Singh                               *    
 * This Model is used to manipulate              *
 * the functionality in Admin Panel              *
 * Date -: 19/June/2019                          *           
 ************************************************
 */

Class Commonmodel extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

   public function savedata($table,$args) {
  
	
       $this->db->insert($table, $args);
        $insert_id = $this->db->insert_id();
		return $insert_id;
		//return $this->db->last_query(); 
    } 
    
	public function getRow($table,$condition="",$orderby="",$limit='', $start='') {
		//echo $start; exit;
		if(empty($condition)){
			 $this->db->select("*")->from($table)->order_by($orderby);
			 if($limit){
			 	$this->db->limit($limit,$start);
			 }
				
			
			$query = $this->db->get();
			
		//return $this->db->last_query();
			if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return 0;
			}
		}else{
			$this->db->select("*")->from($table)->where($condition)->order_by($orderby);
			if($limit){
			 	$this->db->limit($limit,$start);
			 }
			$query = $this->db->get();
		//return $this->db->last_query();
		
		if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return 0;
			} 
		}	
    }
	
	public function countResult($table,$condition=""){
		$this->db->select("*")->from($table)->where($condition);
		$query = $this->db->get();
	  	if ($query->num_rows() > 0) {
			return $query->num_rows();
		} else {
			return 0;
		} 
	
	}
	
	
 	public function updateRow($table,$data,$condition) {
        $this->db->where($condition);
        $this->db->update($table,$data);
	//return $this->db->last_query();
         if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        } 
    }
	
	public function deleteRecord($table,$cond) {
        $this->db->where($cond);
        $this->db->delete($table);
        //echo $this->db->last_query();
        return True;
    }

    public function changeDeleteStatus($table,$set,$cond) {
        $sql = "update $table set $set where $cond";
		$query = $this->db->query($sql);
		//echo $this->db->last_query();
	  	 if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        } 
    }
	
	
	public function changeStatus($table,$set,$cond) {
        $sql = "update $table set $set where $cond";
        //echo $sql; exit;
		$query = $this->db->query($sql);
	  	 if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        } 
    }

    public function changeActiveToInactive($table,$cond) {
        $sql = "update $table set is_active = not is_active where $cond";
		$query = $this->db->query($sql);
	  	 if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        } 
    }
	

	



	public function getUserWithRoleAndPermission($conditions='',$limit=''){
		if(empty($conditions)){
			
			$sql = "select users.*,if(users.role_id=2,(select role_name FROM role_has_permissions where users.role_has_permission_id=role_has_permissions.id),(select name FROM roles where users.role_id=roles.id)) as userRoleName from users inner join role_has_permissions  on users.role_has_permission_id=role_has_permissions.id order by users.id desc ";
			//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}else{
			
			$sql = "select users.*,if(users.role_id=2,(select role_name FROM role_has_permissions where users.role_has_permission_id=role_has_permissions.id),(select name FROM roles where users.role_id=roles.id)) as userRoleName from users inner join role_has_permissions  on users.role_has_permission_id=role_has_permissions.id WHERE $conditions order by users.id desc $limit";

			//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}
	}
// program fee list
	public function programFeeList($conditions='',$limit=''){
		if(empty($conditions)){
			$sql = "select program_fee.*,campus.CampusName,campus.OwnCampus,campus.ContactNo,campus.Zone,campus.ColorCode,campus.Address,campus.GSTIN,(select program_type FROM program_type WHERE program_type.id=program_fee.program_type) as program_type_name,(select name FROM program WHERE program.id= program_fee.program) as program_name from program_fee INNER JOIN campus ON program_fee.campus=campus.id INNER JOIN program on program.id= program_fee.program order by program_fee.program_fee_id desc $limit";
		
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}else{
			
			$sql = "select program_fee.*,campus.CampusName,campus.OwnCampus,campus.ContactNo,campus.Zone,campus.ColorCode,campus.Address,campus.GSTIN,(select program_type FROM program_type WHERE program_type.id=program_fee.program_type) as program_type_name,(select name FROM program WHERE program.id= program_fee.program) as program_name from program_fee INNER JOIN campus ON program_fee.campus=campus.id INNER JOIN program_type on program_type.id= program_fee.program_type INNER JOIN program on program_fee.program=program.id WHERE $conditions order by program_fee.program_fee_id desc $limit";

			//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}
	}


// --- to get Agent data  ----
	public function program_type_list($conditions='',$limit=''){
		if(empty($conditions)){
			$sql = "select stage.*,stage.id as stageId,stage.status as stage_status,program_type.*,program_type.program_type as program_type_name from stage inner JOIN program_type on program_type.id = stage.program_type order by stage.position ASC";
			if(!empty($limit)){
				$sql.=$limit;
			}
		//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}else{
			$sql = "select stage.*,stage.id as stageId,stage.status as stage_status,program_type.*,program_type.program_type as program_type_name from stage inner JOIN program_type on program_type.id = stage.program_type WHERE $conditions order by stage.position ASC";
			if(!empty($limit)){
				$sql.=$limit;
			}
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}
	}

	


// --- to get Agent data  ----
	public function program_type($conditions=''){
	if(empty($conditions)){
		$sql = "select stage.*,stage.id as stageId,stage.status as stage_status,program_type.*,program_type.program_type as program_type_name from stage inner JOIN program_type on program_type.id = stage.program_type";
		$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}else{
		$sql = "select stage.*,stage.id as stageId,stage.status as stage_status,program_type.*,program_type.program_type as program_type_name from stage inner JOIN program_type on program_type.id = stage.program_type WHERE $conditions";
		$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}
}

// --- to get Agent data  ----
	public function programLists($conditions='',$limit='',$orderby=""){
	if(empty($conditions)){
		$sql = "SELECT program.*,program.program_type as programId,(select program_type FROM program_type WHERE program_type.id= program.program_type) as program_type_name,lower(program_type.activityYN) as activityYN FROM program inner JOIN program_type on  program_type.id= program.program_type order by id desc $limit";
	
			$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}else{
		$sql="SELECT program.*,program.program_type as programId,(select program_type FROM program_type WHERE program_type.id= program.program_type) as program_type_name,lower(program_type.activityYN) as activityYN FROM program inner JOIN program_type on  program_type.id= program.program_type  WHERE $conditions order by id desc $limit";
		//echo $sql; exit;
		$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}
}

// --- to get Attachement file  ----
	public function getAttachement($conditions=''){
	if(empty($conditions)){
		$sql = "select * from manage_attachement inner JOIN program_type on program_type.id = manage_attachement.program_type order by manage_attachement.attachement_id desc";
		$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}else{
		$sql = "select * from manage_attachement inner JOIN program_type on program_type.id = manage_attachement.program_type WHERE $conditions order by manage_attachement.attachement_id desc";
		$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}
}
	
public function contactList($conditions='',$limit=''){
	if(empty($conditions)){
		$sql = "select * from  contact_type inner JOIN program_type on program_type.id =  contact_type.program_type order by contact_type.contact_id desc $limit";
		$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}else{
		$sql = "select * from  contact_type inner JOIN program_type on program_type.id =  contact_type.program_type WHERE $conditions order by contact_type.contact_id desc $limit";
		$query = $this->db->query($sql);
	  	if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		} 
	}
}
	// for get all package 



public function advanceSearchLead($condition=""){
  	if(empty($condition)){
    	$sql="SELECT users.*,(select source_name FROM manage_source WHERE source_id=users.source) as sourcename,customer_interactions.interaction_id,customer_interactions.customer_id,customer_interactions.stage_id,(SELECT name FROM stage WHERE id=customer_interactions.stage_id LIMIT 1) as stagename,customer_interactions.contact_type_id,(SELECT contact_type FROM contact_type WHERE contact_id=customer_interactions.contact_type_id LIMIT 1) as contactTypeName FROM users INNER JOIN  customer_interactions on users.id=customer_interactions.customer_id group by users.id";

      	$query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
        	return $query->result_array();
      	} else {
        	return false;
      	} 
    }else{
        $sql="SELECT users.*,(select source_name FROM manage_source WHERE source_id=users.source) as sourcename,customer_interactions.interaction_id,customer_interactions.customer_id,customer_interactions.stage_id,(SELECT name FROM stage WHERE id=customer_interactions.stage_id LIMIT 1) as stagename,customer_interactions.contact_type_id,(SELECT contact_type FROM contact_type WHERE contact_id=customer_interactions.contact_type_id LIMIT 1) as contactTypeName FROM users INNER JOIN  customer_interactions on users.id=customer_interactions.customer_id WHERE $condition";

      	$query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
        	return $query->result_array();
      	} else {
        	return false;
      	} 
    }
}






		
	 //-------------------------------Update employee Details Using Inner Join------------------
	 
	 public function updateEmployeeDetails($con,$data)
	 {  
			 $sql="update empinfo 
			inner join document on empinfo.EmpID=document.EmpID
			inner join companydetails on empinfo.EmpID=companydetails.EmpID
			Inner join accountdetails ON empinfo.EmpID=accountdetails.EmpID set ";

		/* $sql="update empinfo 
			inner join document on empinfo.EmpID=document.EmpID
			inner join companydetails on empinfo.EmpID=companydetails.EmpID
			Inner join accountdetails ON empinfo.EmpID=accountdetails.EmpID
			Inner join salary ON empinfo.EmpID=salary.EmpID set "; */				
				
			foreach ($data as $field => $value)
			$sql .=  $field."= '".$value."',";
			$sql = substr($sql,0,strlen($sql)-1);
			$sql .="where empinfo.EmpID='".$con."'";
			$query = $this->db->query($sql);
			//return $this->db->last_query();
				 return TRUE;
	 }
	 
	
// --- to get StageData  ----
public function getNextActionData($conditions='',$limit=''){
 if(empty($conditions)){
  $sql = "select next_action.*,next_action.id as nextActionId,next_action.status as next_action_status,program_type.*,program_type.program_type as program_type_name from next_action inner JOIN program_type on program_type.id = next_action.program_type order by next_action.id desc $limit";
	  $query = $this->db->query($sql);
	  //return $this->db->last_query();
	    if ($query->num_rows() > 0) {
	   		return $query->result_array();
	  	} else {
	   		return false;
	  	} 
	}else{
  	$sql = "select next_action.*,next_action.id as nextActionId,next_action.status as next_action_status,program_type.*,program_type.program_type as program_type_name from next_action inner JOIN program_type on program_type.id = next_action.program_type WHERE $conditions order by next_action.id desc $limit";
  	//echo $sql; exit;
	$query = $this->db->query($sql);
		//return $this->db->last_query();
		if ($query->num_rows() > 0) {
	 	 	return $query->result_array();
		} else {
	   		return false;
	  	} 
	}
} 
public function getMajorActivity($conditions=''){
 if(empty($conditions)){
  $sql = "SELECT major_activity.*,program.name,activity.activity_name FROM major_activity INNER JOIN program on major_activity.program_id=program.id INNER JOIN activity ON major_activity.activity_id=activity.activity_id order by major_activity.major_activity_id desc";
	  $query = $this->db->query($sql);
	  //return $this->db->last_query();
	    if ($query->num_rows() > 0) {
	   return $query->result_array();
	  } else {
	   return false;
	  } 
	}else{
  	$sql = "SELECT major_activity.*,program.name,activity.activity_name FROM major_activity INNER JOIN program on major_activity.program_id=program.id INNER JOIN activity ON major_activity.activity_id=activity.activity_id  WHERE $conditions order by major_activity.major_activity_id desc";
	$query = $this->db->query($sql);
		//return $this->db->last_query();
		if ($query->num_rows() > 0) {
	 	 	return $query->result_array();
		} else {
	   		return false;
	  	} 
	}
} 
public function getMajorActivityList($conditions=''){
 if(empty($conditions)){
  $sql = "SELECT major_activity.*,activity.activity_name FROM major_activity INNER JOIN activity ON major_activity.activity_id=activity.activity_id order by major_activity.major_activity_id desc";
	  $query = $this->db->query($sql);
	  //return $this->db->last_query();
	    if ($query->num_rows() > 0) {
	   return $query->result_array();
	  } else {
	   return false;
	  } 
	}else{
  	$sql = "SELECT major_activity.*,activity.activity_name FROM major_activity INNER JOIN activity ON major_activity.activity_id=activity.activity_id  WHERE $conditions order by major_activity.major_activity_id desc";
  	
	$query = $this->db->query($sql);
		//return $this->db->last_query();
		if ($query->num_rows() > 0) {
	 	 	return $query->result_array();
		} else {
	   		return false;
	  	} 
	}
}
	

	function get_main_modules()
	{  
	  return $this->db->select('*')->get('module_master')->result_array();
	}

	function get_role_list()
	{
	  return $this->db->select('role_name,id')->where('is_deleted',0)->get('role_has_permissions')->result_array();	
	}


	

	function programTypeList()
	 {
	 	$sql ="SELECT id, program_type,activityYN, IF(status=1,'Active','Inactive') as status ,DATE_FORMAT(from_date,'%d-%b-%y') as from_date,DATE_FORMAT(to_date,'%d-%b-%y') as to_date from program_type
	 	      where is_deleted=0 order by id desc ";
	 		return $this->db->query($sql)->result_array();  
	 }	


	 function campus_location_states()
	 {
	 	$sql="SELECT distinct location.state as state_id,states.name as state from states,location where states.id=location.state and location.is_deleted=0 order by states.name asc";
	 	return $this->db->query($sql)->result_array(); 
	 }

 	function campus($condition='',$limit='')
 	{
 		if(empty($condition)){
			$sql ="SELECT campus.id, campus.CampusName,campus.Zone,states.name as state,IF(campus.status=1,'Active','In Active') as statusname,campus.status, campus.Address,IF(campus.GSTIN='','----',campus.GSTIN) as GSTIN from states,campus where campus.State=states.id order by campus.id desc $limit";
 			return $this->db->query($sql)->result_array();

 		}else{
			$sql ="SELECT campus.id, campus.CampusName,campus.Zone,states.name as state,IF(campus.status=1,'Active','In Active') as statusname,campus.status, campus.Address,IF(campus.GSTIN='','----',campus.GSTIN) as GSTIN from states,campus where campus.State=states.id and ($condition) order by campus.id desc $limit";
		 	//echo $sql; exit;
		 	return $this->db->query($sql)->result_array();
 		}
 	}


function campusList($conditions)
 {
 	if(empty($conditions)){
	  	$sql = "SELECT program.*,campus.*,campus.id as campusId FROM program INNER JOIN campus ON program.campus=campus.id";
		$query = $this->db->query($sql);
	    if ($query->num_rows() > 0) {
		   return $query->result_array();
		} else {
		   return false;
		} 
	}else{
  		$sql = "SELECT program.*,campus.*,campus.id as campusId FROM program INNER JOIN campus ON program.campus=campus.id WHERE $conditions";
		$query = $this->db->query($sql);
		if ($query->num_rows() > 0) {
	 	 	return $query->result_array();
		} else {
	   		return false;
	  	} 
	}
 }
































































































































	
	
	



































































































































































































































































	// To get =login User Details ----------------------------
public function getUserLoginDetails($con){
		$sql="select empinfo.EmpID as employeeId,empinfo.emptype,(select MasterData from master where empinfo.emptype=MasterID limit 1) as employeeType,empinfo.Name,empinfo.FName,empinfo.DOB,empinfo.DOB,
			empinfo.Gender,empinfo.Phone,empinfo.LocalAddress,empinfo.PermanentAddress,
			empinfo.Email,empinfo.Password,empinfo.ProfileImage,empinfo.CreatedBy,
			empinfo.CreatedDate,empinfo.empinfostatus,empinfo.assigned_team_lead_id,empinfo.Permission,
			document.Resume,document.OfferLetter,document.JoiningLetter,document.ContractAgrement,document.IdProof,
			companydetails.EmployeeID,companydetails.Department,companydetails.Designation,
			(select MasterData from master where companydetails.Department=MasterID limit 1) as DepartmentName,
			(select MasterData from master where companydetails.Designation=MasterID limit 1) as DesignationName,
			companydetails.DOJ,companydetails.JoiningSalary,
			accountdetails.HolderName,accountdetails.AccountNumber,accountdetails.BankName,
			accountdetails.IFSCCode,accountdetails.PANNumber,accountdetails.Branch,
			salary.Basic,salary.HRA,salary.Conveyance,salary.splAllow,salary.PF,salary.ESI,salary.otherinst,salary.otherded,
			salary.grossSalary,salary.netsalary,companyinfo.Logo,companyinfo.Name as companyName,companyinfo.address as companyAddress,companyinfo.MobileNumber as comapanyMobile
			from empinfo
			inner join document on empinfo.EmpID=document.EmpID
			inner join companydetails on empinfo.EmpID=companydetails.EmpID
			Inner join accountdetails ON empinfo.EmpID=accountdetails.EmpID
			Inner join salary ON empinfo.EmpID=salary.EmpID 
			Inner join companyinfo ON empinfo.CreatedBy=companyinfo.InfoID where $con";
				$query = $this->db->query($sql);
				//return $this->db->last_query();
			  if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
	
	}
// To Select All Leave Applied by Employee ---------------------
	
	public function selectAllLeave($condition)
		{
		$sql = "SELECT leaveapplication.*,count(leaveapplication.ApplicationID) as totalTakenLeave,master.* FROM  leaveapplication INNER JOIN master ON master.MasterID=leaveapplication.LeaveTypeID where $condition";
	  
	//exit; 
		$query = $this->db->query($sql);
			//return $this->db->last_query();
			  if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
				
		}
	//-------------------------------All Deliverd list on 19-05-2017 -----------------------
		
		public function empLeaveList($con)
			{
			$sql="select leaveapplication.units,
			(select MasterData from master where leaveapplication.LeaveTypeID=MasterID limit 1) as LeaveType,
			leaveapplication.Reason,leaveapplication.LeaveTypeID,leaveapplication.AppliedDate,leaveapplication.Status as leaveStatus,
			empinfo.EmpID as employeeId,empinfo.emptype,empinfo.Name,empinfo.FName,empinfo.DOB,empinfo.DOB,
			empinfo.Gender,empinfo.Phone,empinfo.LocalAddress,empinfo.PermanentAddress,
			empinfo.Email,empinfo.Password,empinfo.ProfileImage,empinfo.CreatedBy,
			empinfo.CreatedDate,empinfo.empinfostatus,empinfo.assigned_team_lead_id,
			(select MasterData from master where companydetails.Department=MasterID limit 1) as DepartmentName,
			(select MasterData from master where companydetails.Designation=MasterID limit 1) as DesignationName,companydetails.EmployeeID
			from leaveapplication
			inner join empinfo on leaveapplication.EmpID=empinfo.EmpID
			inner join companydetails on empinfo.EmpID=companydetails.EmpID where $con";
				$query = $this->db->query($sql);
			//return $this->db->last_query();
			  if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
			
			}
	
	// To Select All Leave Applied by Employee ---------------------
	
	/* public function remainLeaves($condition)
		{
	   $sql="SELECT leaveapplication.*, count(leaveapplication.ApplicationID) as totalTakenLeave, (select MasterData from master where leaveapplication.LeaveTypeID=MasterID limit 1) as leaveTypeName, (select TotalLeave from master where leaveapplication.LeaveTypeID=MasterID limit 1) as totalLeave FROM leaveapplication INNER JOIN master ON leaveapplication.LeaveTypeID=master.MasterID WHERE $condition group BY leaveapplication.LeaveTypeID";
		$query = $this->db->query($sql);
				//return $this->db->last_query();
			   if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
				
		} */
		
		public function remainLeaves($condition)
		{
	   $sql="SELECT leaveapplication.*,count(leaveapplication.ApplicationID) as takenLeave, 
		case leaveapplication.units 
		when '1' then STR_TO_DATE(leaveapplication.startDate,'%Y-%m') 
		when '2' then STR_TO_DATE(leaveapplication.date,'%Y-%m')
		end as LeaveapplicationMonthYear, 
			(select MasterData from master where leaveapplication.LeaveTypeID=MasterID limit 1) as leaveTypeName, (select TotalLeave from master where leaveapplication.LeaveTypeID=MasterID limit 1) as totalLeave FROM leaveapplication INNER JOIN master ON leaveapplication.LeaveTypeID=master.MasterID WHERE $condition group BY leaveapplication.LeaveTypeID";
		$query = $this->db->query($sql);
				//return $this->db->last_query();
			//exit;
				
			   if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
				
		}
		
		public function notificationList($condition){
			
			$sql="select empinfo.EmpID as employeeId,empinfo.emptype,empinfo.Name,empinfo.FName,empinfo.DOB,empinfo.DOB,empinfo.Gender,empinfo.Phone,empinfo.LocalAddress,empinfo.PermanentAddress,empinfo.Email,empinfo.Password,empinfo.ProfileImage,empinfo.CreatedBy,empinfo.CreatedDate,empinfo.empinfostatus,empinfo.assigned_team_lead_id,notification.NotificationID,notification.userid,notification.company_id,notification.roleid,notification.Action,notification.CreatedDate,notification.Status from empinfo inner join notification on empinfo.EmpID=notification.userid where $condition";
				$query = $this->db->query($sql);
			//return $this->db->last_query();
			  if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
			
			
		}
		//-------------------Print Salary--------------------------

		public function printSalarySlip($condition){
			
			$sql="SELECT * FROM empinfo INNER JOIN document ON empinfo.EmpID=document.EmpID
					INNER JOIN accountdetails ON empinfo.EmpID=accountdetails.EmpID
					INNER JOIN companydetails ON empinfo.EmpID=companydetails.EmpID
					INNER JOIN monthlysalarydetails ON empinfo.EmpID=monthlysalarydetails.EmpID
					INNER JOIN master ON companydetails.Department=master.MasterID
					INNER JOIN companyinfo ON companyinfo.InfoID=empinfo.CreatedBy
						where $condition";
				$query = $this->db->query($sql);
			//return $this->db->last_query();
			  if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
			
			
		}
//------------------- for Display attenace with punching system by Randhir kumar on 26-06-2017---------------------

		public function selectAttendanceWithPunching($condition){
			
			$sql="select attendance.*,(CASE WHEN punchinY_N = 0 THEN 'manual' WHEN punchinY_N = 1 THEN 'mobile' end) as punchedBy from attendance where $condition";
				$query = $this->db->query($sql);
			//return $this->db->last_query();
			  if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 
			
			
		}

	public function getSendedMessage($condition){
			$sql="SELECT * FROM inbox_message INNER JOIN empinfo ON inbox_message.user_id=empinfo.EmpID where $condition";
				$query = $this->db->query($sql);
			//return $this->db->last_query();
			  if ($query->num_rows() > 0) {
					return $query->result_array();
				} else {
					return false;
				} 

			}
		

	
//--------------------------------To create Custom pagination ---------------------------------------//
	
	public function customPagination($table,$columns,$searColumns){
		$sqlQuery="SELECT * FROM $table";
		
		$requestData= $_REQUEST;
		
		$sql = $sqlQuery;
		$query = $this->db->query($sql);
		$totalData = $query->num_rows();
		$totalFiltered = $totalData; 


		if( !empty($requestData['search']['value']) ) {
			$sql = $sqlQuery;

			$cwhere=" WHERE ";
					for($i=0;$i<count($searColumns);$i++)
					{
					$cwhere .=$searColumns[$i]." Like '".$requestData['search']['value']."%' OR ";
					} 
				$sql .=substr($cwhere,0,strlen($cwhere)-3);
			
			$query=$this->db->query($sql);
			$totalFiltered = $query->num_rows(); 

			$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   "; 
			$query=$this->db->query($sql); 
			
		} else {
			$sql = $sqlQuery;
			$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   ";
			$query=$this->db->query($sql); 	
		}
		$rows=$query->result_array();
		
		$data['draw']=intval($requestData['draw']);
		$data['recordsTotal']=intval($totalData);
		$data['recordsFiltered']=intval($totalFiltered);
		$data['data']=$rows;
		return $data;	
	}
	public function getInteractionReport($conditions='',$team_member='',$limit='')
	 {
	  if(empty($conditions)){

	    $sql="select u1.*,customer_interactions.*,(SELECT concat(first_name,' ',last_name) FROM users u2 WHERE id=customer_interactions.responsibility_to_user ) as responsibleByName,(select contact_type from contact_type where contact_id=customer_interactions.contact_type_id) as contactTypeName ,(select concat(first_name,' ',last_name) FROM users  WHERE id=u1.leadOwner) as LeadOwnerName  From users u1 inner join customer_interactions on u1.id=customer_interactions.customer_id where customer_interactions.created_by in($team_member) $limit";
	    // echo $sql; exit;
	     $query = $this->db->query($sql);
	        if ($query->num_rows() > 0) {
	        return $query->result_array();
	      } else {
	        return false;
	      } 
	    }else{
	        $sql = "select u1.*,customer_interactions.*,(SELECT concat(first_name,' ',last_name) FROM users WHERE id=customer_interactions.responsibility_to_user ) as responsibleByName,(select contact_type from contact_type where contact_id=customer_interactions.contact_type_id) as contactTypeName ,(select concat(first_name,' ',last_name) FROM users  WHERE id=u1.leadOwner) as LeadOwnerName  From users u1 inner join customer_interactions on u1.id=customer_interactions.customer_id where $conditions  customer_interactions.created_by in($team_member) $limit";
	        // echo $sql; exit;
		      $query = $this->db->query($sql);
		        if ($query->num_rows() > 0) {
		        return $query->result_array();
		      } else {
		        return false;
		      }
	    }
	 }

	 public function getconnectReport($conditions='',$team_member='',$limit='')
	 {
	 	if(empty($conditions)){
	 		$sql="select users.*,connect_with_each_other.*,connect_with_each_other.created_by as createdById,(SELECT concat(first_name,' ',last_name) FROM users WHERE id=connect_with_each_other.created_by) as connectedByName  From users inner join connect_with_each_other on users.id=connect_with_each_other.user_id WHERE connect_with_each_other.created_by in($team_member)  and connect_with_each_other.referral_or_connect='Connection' $limit";	
	 	}else
	 	{
	 		$sql="select users.*,connect_with_each_other.*,connect_with_each_other.created_by as createdById,(SELECT concat(first_name,' ',last_name) FROM users WHERE id=connect_with_each_other.created_by) as connectedByName  From users inner join connect_with_each_other on users.id=connect_with_each_other.user_id WHERE $conditions connect_with_each_other.created_by in($team_member)  and connect_with_each_other.referral_or_connect='Connection' $limit";
	 	}
	 	  $query = $this->db->query($sql);
		        if ($query->num_rows() > 0) {
		        return $query->result_array();
		      } else {
		        return false;
		      }
	 } 	

	 public function getAttachementReport($conditions='',$team_member='',$limit='')		
	 {
	 	if(empty($conditions))
	 	{
			$sql="select users.*,customer_attachement.*,if(customer_attachement.attachment_type='0','Other',(select attachement_type_name FROM attachement_type WHERE id=customer_attachement.attachment_type limit 1)) as attachementType ,(SELECT concat(first_name,' ',last_name) FROM users WHERE id=customer_attachement.created_by) as createdByName  FROM users INNER JOIN customer_attachement on users.id = customer_attachement.customer_id  customer_attachement.created_by in($team_member) $limit";
	 	}else
	 	{
	 		$sql="select users.*,customer_attachement.*,if(customer_attachement.attachment_type='0','Other',(select attachement_type_name FROM attachement_type WHERE id=customer_attachement.attachment_type limit 1)) as attachementType ,(SELECT concat(first_name,' ',last_name) FROM users WHERE id=customer_attachement.created_by) as createdByName  FROM users INNER JOIN customer_attachement on users.id = customer_attachement.customer_id where $conditions customer_attachement.created_by in($team_member) $limit";
	 	}
	 	  $query = $this->db->query($sql);
		        if ($query->num_rows() > 0) {
		        return $query->result_array();
		      } else {
		        return false;
		      }
	 }	
	 public function  getProfileReport($conditions='',$team_member='',$limit='')
	 {
	 	if(empty($conditions))
	 	{
	 		$sql="select u1.*,u1.created_by as createdById,(select first_name FROM users WHERE id=u1.created_by) as createdByName From users u1,users u2 where u1.created_by=u2.id and  u1.created_by in($team_member) $limit";
	 	}else
	 	{
	 		$sql="select u1.*,u1.created_by as createdById,(select first_name FROM users WHERE id=u1.created_by) as createdByName From users u1,users u2 where $conditions u1.created_by=u2.id and  u1.created_by in($team_member) $limit";
	 	}
	 	// echo $sql;exit;
	 	  $query = $this->db->query($sql);
		        if ($query->num_rows() > 0) {
		        return $query->result_array();
		      } else {
		        return false;
		      }

	 }	

	 public function leadersList($conditions='',$limit=''){
		if(empty($conditions)){
			$sql = "SELECT *,(select name FROM  instructor where users.role_has_permission_id= instructor.id) as userRoleName  FROM `users` INNER JOIN leaders ON users.id=leaders.user_id ORDER BY leaders.leader_id desc $limit";
		
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}else{
			
			$sql = "SELECT *,(select name FROM  instructor where users.role_has_permission_id= instructor.id) as userRoleName  FROM `users` INNER JOIN leaders ON users.id=leaders.user_id  WHERE $conditions ORDER BY leaders.leader_id desc $limit";

			//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}
	}
	public function allocateLeaderList($conditions='',$limit=''){
		if(empty($conditions)){
			$sql = "SELECT *,(select allocation_id FROM manage_leader_allocation WHERE instructor_id=users.id limit 1) as allocationId,(select name FROM  instructor where users.role_has_permission_id= instructor.id) as userRoleName  FROM `users` INNER JOIN leaders ON users.id=leaders.user_id desc $limit";
		
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}else{
			
			/*$sql = "SELECT *,(select allocation_id FROM manage_leader_allocation WHERE instructor_id=users.id limit 1) as allocationId,(select no_days FROM manage_leader_allocation WHERE instructor_id=users.id limit 1) as customeNoOfDays,(select name FROM  instructor where users.role_has_permission_id= instructor.id) as userRoleName  FROM `users` INNER JOIN leaders ON users.id=leaders.user_id WHERE $conditions ORDER BY leaders.leader_id desc $limit";*/
			$sql = "SELECT users.*,manage_leader_allocation.*,manage_leader_allocation.allocation_id as allocationId,manage_leader_allocation.no_days as customeNoOfDays,(select name FROM  instructor where users.role_has_permission_id= instructor.id) as userRoleName,leaders.fee_per_day,leaders.leader_id FROM manage_leader_allocation INNER JOIN users ON manage_leader_allocation.instructor_id=users.id INNER JOIN leaders ON manage_leader_allocation.instructor_id=leaders.user_id WHERE $conditions";
			//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}
	}
	public function instructorWithRoles($conditions='',$limit=''){
		if(empty($conditions)){
			$sql="SELECT instructor.id as instructorId,instructor.name as instructorName,users.id as userId,concat(users.first_name,users.last_name) as userName FROM instructor LEFT JOIN users ON instructor.id=users.role_has_permission_id";
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}else{
			$sql = "SELECT instructor.id as instructorId,instructor.name as instructorName,users.id as userId,concat(users.first_name,users.last_name) as userName FROM instructor LEFT JOIN users ON instructor.id=users.role_has_permission_id WHERE $conditions $limit";
			//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}
	}
	
	/*public function allocateLeaderList($conditions='',$limit=''){
		if(empty($conditions)){
			$sql = "SELECT *,(select allocation_id FROM manage_leader_allocation WHERE instructor_id=users.id limit 1) as allocationId,(select name FROM  instructor where users.role_has_permission_id= instructor.id) as userRoleName  FROM `users` INNER JOIN leaders ON users.id=leaders.user_id desc $limit";
		
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}else{
			
			$sql = "SELECT *,(select allocation_id FROM manage_leader_allocation WHERE instructor_id=users.id limit 1) as allocationId,(select no_days FROM manage_leader_allocation WHERE instructor_id=users.id limit 1) as customeNoOfDays,(select name FROM  instructor where users.role_has_permission_id= instructor.id) as userRoleName  FROM `users` INNER JOIN leaders ON users.id=leaders.user_id WHERE $conditions ORDER BY leaders.leader_id desc $limit";

			//echo $sql; exit;
			$query = $this->db->query($sql);
		  	if ($query->num_rows() > 0) {
				return $query->result_array();
			} else {
				return false;
			} 
		}
	}*/
}