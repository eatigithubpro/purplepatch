<?php	
if(!defined('BASEPATH')) exit('direct access not allowed');
class Login_model extends CI_Model
{
	

	function userAuth($args) {
		
        $this->db->select("*")->from('users');
        $this->db->where("email", $args['email']);
        $this->db->where('password',encryptor($args['password']));
		$this->db->where('user_status', '1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row_array();
        } else {
            return false;
        }
    }

}
