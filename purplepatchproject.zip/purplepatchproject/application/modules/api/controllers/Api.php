<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/REST_Controller.php';
//use Restserver\Libraries\REST_Controller;
//require APPPATH . 'libraries/Format.php';
/*require_once(APPPATH."third_party/phpmailer/PHPMailer.php");
require_once(APPPATH."third_party/phpmailer/Exception.php");
require_once(APPPATH."third_party/phpmailer/SMTP.php");*/
/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Eati sinha
 * @license         Webfume
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Api extends REST_Controller{
	private $user_details;
	public function __construct(){
		parent::__construct();
		//$this->load->library('session');
		$this->load->model('Modelapi');
		$this->load->helper('url');
		//$this->load->model('Commonmodel');
		header("Access-Control-Allow-Origin: *");
		header("Content-Type: application/json; charset=UTF-8");
		// validating user 
		if(!empty($_SERVER['HTTP_TOKEN'])){
			$readed_data = read_user_session($_SERVER['HTTP_TOKEN']);
			if(!empty($readed_data)){
				$this->user_details = $readed_data;
			}else{
				$this->user_details = NULL;
			}
		}else{
			$this->user_details = NULL;
		}
		
	}

	public function saveContact_post()
    {
    	extract($this->post());
    	//print_r($this->post());*/
    	/*$pdata = $this->input->post();
        print_r($pdata); exit;*/

         if ($contactname == "") { //ADMIN/DRIVER/COMPANY
            $data = array("status" => 0, "message" => 'The Full Name field is required');
            $this->response($data, 400);
            exit();
        }

         if ($contactemail == "") { //ADMIN/DRIVER/COMPANY
            $data = array("status" => 0, "message" => 'The Email field is required');
            $this->response($data, 400);
            exit();
        }

         if ($contactsubject == "") { //ADMIN/DRIVER/COMPANY
            $data = array("status" => 0, "message" => 'The Subject field is required');
            $this->response($data, 400);
            exit();
        }

         if ($contactmsg == "") { //ADMIN/DRIVER/COMPANY
            $data = array("status" => 0, "message" => 'The Message field is required');
            $this->response($data, 400);
            exit();
        }


    	$pdata = $this->post();
       // print_r($pdata); exit;
       

         $data['name']           = $pdata['contactname'];
       // $data['last_name']      = $pdata['contactlastname'];
        $data['email']          = $pdata['contactemail'];
       // $data['mobile']         = $pdata['contactnumber'];
        $data['subject']     = $pdata['contactsubject'];
        $data['message']        = $pdata['contactmsg'];
        $data['created_date']   = date('Y-m-d');
        $data['created_by']     = '';
        $data['contact_status'] = '1';
        $results = $this->Modelapi->savedata("contact_us",$data);

        // for send email
        $subject = "Your Query Successfully Send";
       // $message = $this->load->view('request_query_template',$data,true);
        //$this->sendmail($pdata['contactemail'],$subject,$message); 

            if($results){
                $responce['err'] = 0;
                $responce['msg'] = "Your Query Successfully Send.";
                echo json_encode($responce); 
            }else{
                $responce['err'] = 2;
                $responce['msg'] = "Error.";
                echo json_encode($responce); 
            } 
    }


	
}