<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modelapi extends CI_Model
{
  
function __construct()
{
    parent::__construct();
       
}

function getData($param) {

  extract($param);    
  $data = array();
  try{

    // print_r($findinset);
    // exit;
    // echo $findinset['value'];
    // exit;


  
    // $query=$this->db;
     if(isset($parameter) && $parameter!=''){
     $query=$this->db->select($parameter);
     }
     else {
      $query=$this->db->select("*");

     }
      $query=$this->db->from($table_name);
    //  if(isset($join) && $join!=''){
    //  $this->db->join("tbl_students","tbl_students.student_id=tbl_attendance.attendance");
    // }

    if(isset($wherecondition) && $wherecondition!=''){
      $this->db->where($wherecondition);
    }
    if(isset($findinset) && $findinset!=''){
      $this->db->where("FIND_IN_SET(".$findinset['value'].",'". $findinset['findinset']."')!=",0);
    }
    if(isset($findinsetout) && $findinsetout!=''){
      $this->db->where("FIND_IN_SET('".$findinsetout['value']."',". $findinsetout['findinset'].")!=",0);
    }
    if(isset($between) && $between!=''){
    $this->db->where("date(".$between['from'].") <=", $between['value']);
    $this->db->where("date(".$between['to'].") >=",  $between['value']);
    }

    if(isset($lessthan) && $lessthan!=''){
    
    $this->db->where("".$lessthan['to'].">=",  $lessthan['value']);
    }

    if(isset($greaterthan) && $greaterthan!=''){
    $this->db->where("".$greaterthan['from']." <=", $greaterthan['value']);
    }

    if(isset($lessthandate) && $lessthandate!=''){
    
    $this->db->where("date(".$lessthandate['to'].") >=",  $lessthandate['value']);
    }

    if(isset($greaterthandate) && $greaterthandate!=''){
    $this->db->where("date(".$greaterthandate['from'].") <=", $greaterthandate['value']);
    }

    if(isset($orderby) && $orderby!=''){
     // echo "eat";
    //$this->db->order_by('"'.$orderby['field'].'"','"'.$orderby['order'].'"');
    $this->db->order_by($orderby['field'],$orderby['order']);
    }

    // if(isset($groupby) && $groupby!=''){
    // $this->db->GROUP_BY('tbl_students.student_id');
    // }
   // print_r($orderby);

    if($limit!='' && $offset!=''){

      $this->db->limit($limit, $offset);
    }

   
    $query=$this->db->get();
    /*echo $this->db->last_query();
    exit; */
   
    $res=$query->result(); 
 return(array("success" => 1, "data" => $res));      
  }catch(Exception $e){
    return(array("success" => 0, "message" => $e->getMessage()));
  }
  
  
}


function getDatatest($param) {

  extract($param);    
  $data = array();
  try{

    // print_r($findinset);
    // exit;
    // echo $findinset['value'];
    // exit;


  
    // $query=$this->db;
     if(isset($parameter) && $parameter!=''){
     $query=$this->db->select($parameter);
     }
     else {
      $query=$this->db->select("*");

     }
      $query=$this->db->from($table_name);
    //  if(isset($join) && $join!=''){
    //  $this->db->join("tbl_students","tbl_students.student_id=tbl_attendance.attendance");
    // }

    if(isset($wherecondition) && $wherecondition!=''){
      $this->db->where($wherecondition);
    }
    if(isset($findinset) && $findinset!=''){
      $this->db->where("FIND_IN_SET(".$findinset['value'].",'". $findinset['findinset']."')!=",0);
    }
    
    if(isset($findinsetout) && $findinsetout!=''){
      $this->db->where("FIND_IN_SET('".$findinsetout['value']."',". $findinsetout['findinset'].")!=",0);
    }
    if(isset($between) && $between!=''){
    $this->db->where("date(".$between['from'].") <=", $between['value']);
    $this->db->where("date(".$between['to'].") >=",  $between['value']);
    }

    if(isset($lessthan) && $lessthan!=''){
    
    $this->db->where("".$lessthan['to'].">=",  $lessthan['value']);
    }

    if(isset($greaterthan) && $greaterthan!=''){
    $this->db->where("".$greaterthan['from']." <=", $greaterthan['value']);
    }

    if(isset($lessthandate) && $lessthandate!=''){
    
    $this->db->where("date(".$lessthandate['to'].") >=",  $lessthandate['value']);
    }

    if(isset($greaterthandate) && $greaterthandate!=''){
    $this->db->where("date(".$greaterthandate['from'].") <=", $greaterthandate['value']);
    }

    if(isset($orderby) && $orderby!=''){
     // echo "eat";
    //$this->db->order_by('"'.$orderby['field'].'"','"'.$orderby['order'].'"');
    $this->db->order_by($orderby['field'],$orderby['order']);
    }

    // if(isset($groupby) && $groupby!=''){
    // $this->db->GROUP_BY('tbl_students.student_id');
    // }
   // print_r($orderby);

    if($limit!='' && $offset!=''){

      $this->db->limit($limit, $offset);
    }

   
    $query=$this->db->get();
    echo $this->db->last_query();
    exit; 
   
    $res=$query->result(); 
 return(array("success" => 1, "data" => $res));      
  }catch(Exception $e){
    return(array("success" => 0, "message" => $e->getMessage()));
  }
  
  
}


/*
function getData($param) {

  extract($param);    
  $data = array();
  try{

      if($parameter!="")
       $this->db->select($parameter);
      else
       $this->db->select('*');

      if($wherecondition!="")
        $query = $this->db->get_where($table_name, $wherecondition, $limit, $offset);
      else
        $query = $this->db->get($table_name);

      $res=$query->result();  

      return(array("success" => 1, "data" => $res));      
  }catch(Exception $e){
    return(array("success" => 0, "message" => $e->getMessage()));
  }
  
  
}
*/

public function savedata($table,$args) {
  
  
       $this->db->insert($table, $args);
        $insert_id = $this->db->insert_id();
    return $insert_id;
    //return $this->db->last_query(); 
    } 
function postData($param) {

  extract($param);    
 // $data = array();
  try{

     

      
        $query = $this->db->insert($table_name, $data);

    if($query){
      return(array("success" => 1, "message" => 'Data has been added successfully'));    
    }
    else {
      return(array("success" => 1, "message" => 'Error'));    

    }

        
  }catch(Exception $e){
    return(array("success" => 0, "message" => $e->getMessage()));
  }
  
  
}
public function getDataAdvertise($dt,$id,$type){
  $type='t2.'.$type;
  $advertisementlistquery=$this->db->query("SELECT t1.*,t2.* FROM advertisement as t1 INNER JOIN allowed_advertisement as t2 ON t1.advertisement_id=t2.aid_id WHERE t1.status='1' AND t1.is_deleted='0' AND FIND_IN_SET($id,$type) AND (t1.start_date <= '".$dt."' AND t1.end_date >= '".$dt."')  ORDER BY t1.featured_date DESC,t1.last_modified DESC  ");
  
 /* echo "SELECT t1.*,t2.* FROM advertisement as t1 INNER JOIN allowed_advertisement as t2 ON t1.advertisement_id=t2.aid_id WHERE t1.status='1' AND t1.is_deleted='0' AND FIND_IN_SET($id,$type) AND (t1.start_date <= '".$dt."' AND t1.end_date >= '".$dt."')  ORDER BY t1.featured_date DESC,t1.last_modified DESC  ";*/
    

    $data=$advertisementlistquery->result();

    return $data;
}

/*public function getCityList()
{
    $queryData=$this->db->query("SELECT id,city_name,status FROM `vclp_city` where status=1 ORDER BY city_name ASC");
	
    if($queryData->num_rows()>0)
    {
         $data=$queryData->result();
		 return $data;
    }
    

}

*/

         
}
  