<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');
	//echo Modules::run('header/header/index');
?>
	 


<h1>Service API Page</h1>


 
    
<?php
 // echo Modules::run('footer/footer/index');
?>   
    
