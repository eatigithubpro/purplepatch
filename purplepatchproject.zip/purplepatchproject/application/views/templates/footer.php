 </div>
    <!-- /#wrapper -->

    <!-- Core Scripts - Include with every page -->
    
    
    <script src="<?php echo base_url();?>assets/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="<?php echo base_url();?>assets/js/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="<?php echo base_url();?>assets/js/plugins/morris/morris.js"></script>
  
<script src="<?php echo base_url();?>assets/js/plugins/flot/jquery.flot.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url();?>assets/js/plugins/flot/jquery.flot.pie.js"></script>
 <!-- Page-Level Plugin Scripts - Tables -->
<script src="<?php echo base_url();?>assets/js/plugins/dataTables/jquery.dataTables.js"></script>

<script src="<?php echo base_url();?>assets/js/plugins/dataTables/dataTables.bootstrap.js"></script>

<script src="<?php echo base_url();?>assets/js/sb-admin.js"></script> 

</body>

</html>
<script>
$(function(){
/*$('.ckeditor').each(function(e){
CKEDITOR.replace( this.id, {
    filebrowserBrowseUrl: '../assets/ckfinder/ckfinder.html',
    filebrowserImageBrowseUrl: '../assets/ckfinder/ckfinder.html?Type=Images',
    filebrowserUploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
    filebrowserImageUploadUrl: '../assets/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
    filebrowserWindowWidth : '1000',
    filebrowserWindowHeight : '700',
    extraPlugins: 'colorbutton,colordialog,placeholder',
});
 });*/


    $('.ckeditor').each(function(e){
        CKEDITOR.replace( this.id, { 
        filebrowserBrowseUrl:'../assets/kcfinder/browse.php?opener=ckeditor&type=files',
		filebrowserImageBrowseUrl:'../assets/kcfinder/browse.php?opener=ckeditor&type=images',
		filebrowserFlashBrowseUrl:'../assets/kcfinder/browse.php?opener=ckeditor&type=flash',
		filebrowserUploadUrl:'../assets/kcfinder/upload.php?opener=ckeditor&type=files',
		filebrowserImageUploadUrl:'../assets/kcfinder/upload.php?opener=ckeditor&type=images',
		filebrowserFlashUploadUrl:'../assets/kcfinder/upload.php?opener=ckeditor&type=flash',
		filebrowserFlashUploadUrl:'../assets/kcfinder/upload.php?opener=ckeditor&type=flash',
        extraAllowedContent:'*[id];*(*);*{*};p(*)[*]{*};div(*)[*]{*};li(*)[*]{*};ul(*)[*]{*};span(*)[*]{*};table(*)[*]{*};td(*)[*]{*}',
		filebrowserWindowWidth: '1000',
		filebrowserWindowHeight: '700',
		height: 250,
		extraPlugins: 'colorbutton,colordialog,placeholder',
		placeholder :'Type here...'
        });
    });
});
</script>

<script>

	function changePassword(){
		lockModal('passwordModal');
		showModal('passwordModal');
		//alert('')
	}
	function dochangePassword(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
        ///showLoader();
            }, 
        success: function (obj)
        {

      hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
              window.location=base_url+"login/logout";
            },2000)
        
        }
  
        if (obj.err == 1)
        {
          
        showErrorMessage(formId,obj.msg); 
                  
        }
    
        if (obj.err == 2)
        {
            appendMessageBody(formId);
            showDatabaseErrorMessage(formId,obj.msg);  
        }
      
        }
    });
  }
</script>


<div id="passwordModal" class="modal fade in" role="dialog" aria-hidden="false">
   <div class="vertical-alignment-helper"> 
  	<div class="modal-dialog modal400 vertical-align-center">
	    <div class="modal-content">
	      	<div class="modal-header" style="background: rgb(66, 139, 202);">
		        <button type="button" class="close" data-dismiss="modal" style="margin-top: 1%; margin-right: 1%;">×</button>
		        <h4 class="modal-title">Change password</h4>
	      	</div>
	      	<div class="modal-body" id="scr2">
	      		 <form action='' method="post" id="changePasswordForm">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Old Password</label>
                                 <input type="password" name="oldPassword" id="oldPassword" class="form-control" placeholder="Old Password." >
                            </div>
                         </div>
                    </div>
		            <div class="row">
		            	<div class="col-md-12">
	                        <div class="form-group">
	                        	<label>Password</label>
	                             <input type="password" name="cpassword" id="cpassword" class="form-control" placeholder="New Password." >
	                        </div>
		                 </div>
	                </div>
	                <div class="row">
	                	<!-- <div class="col-md-3"></div> -->
	                	<div class="col-md-12"> 
	                        <div class="form-group">
		                        <label>Confirm password</label>
		                          <input type="password" name="ccpassword" id="ccpassword" class="form-control" placeholder="Confirm Password." >
	                        </div>
	                    </div>
	            	</div>
	            </form>    
	      	</div>
	      	<div class="modal-footer text-center">
	      	 	  <button type="button" class="btn btn-info" onclick="dochangePassword('changePasswordForm','admin/doChangePassword')">Submit</button>
	        	<!-- <button type="button" class="btn btn-default" data-dismiss="modal" style="border-radius: 5px;">Close</button> -->
	      	</div>
	    </div>
  	</div>
   </div> 
</div>