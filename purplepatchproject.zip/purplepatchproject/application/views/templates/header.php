<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo TITLE;?></title>
    <!-- Core CSS - Include with every page -->
    <link href="<?php echo base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.css" rel="stylesheet">
    <!-- Page-Level Plugin CSS - Dashboard -->
    <link href="<?php echo base_url();?>assets/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/plugins/timeline/timeline.css" rel="stylesheet">
    <!-- SB Admin CSS - Include with every page -->
    <link href="<?php echo base_url();?>assets/css/sb-admin.css" rel="stylesheet">
     <!-- Page-Level Plugin CSS - Tables -->
    <link href="<?php echo base_url();?>assets/css/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/plugins/social-buttons/social-buttons.css" rel="stylesheet">
    <!-- <script src="<?php echo base_url();?>assets/js/jquery-1.10.2.js"></script> -->
    <script src="<?php echo base_url();?>assets/js-admin/jquery-2.1.0.js"></script>
    <script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
    <script>
        var base_url = "<?= base_url(); ?>";
    </script>
    <script src="<?= base_url();?>assets/js/our_js/app.min.js" type="text/javascript"></script>
    <script src="<?= base_url();?>assets/js/our_js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="<?= base_url();?>assets/js/our_js/sweetalert.js"></script>
    <script src="<?= base_url();?>assets/js/our_js/sweetalert.min.js"></script>
    <link rel="stylesheet" href="<?= base_url();?>assets/js/our_js/sweetalert.css">
    <script src="<?= base_url();?>assets/js/our_js/customFunction.js?v=<?php echo time();?>"></script>
    <link rel="stylesheet" href="<?= base_url();?>assets/js/our_js/bootstrap-select.css">
    <script src="<?= base_url();?>assets/js/our_js/bootstrap-select.js"></script>
  
    <!-- ckeditor -->
   <!--  <script src="<?php //echo base_url();?>assets/ckeditor/ckeditor.js"></script> -->
   <script src="https://cdn.ckeditor.com/4.13.0/standard-all/ckeditor.js"></script> 

    <!------ for multiple select ----------->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/js/our_js/jquery.multiselect.css">
    <script src="<?= base_url();?>assets/js/our_js/jquery.multiselect.js"></script>

    <link   href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
    <link   href="https://cdn.datatables.net/rowreorder/1.2.5/css/rowReorder.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/rowreorder/1.2.5/js/dataTables.rowReorder.min.js"></script>
</head>
<style>
.blockUI{
    z-index: 99999 !important;
}
.err-msg {
    color: red;
    font-style: initial;
}
.dataTables_wrapper .dataTables_processing {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 29%;
    height: 60px;
    margin-left: -16%;
    margin-top: -25px;
    padding-top: 20px;
    text-align: center;
    font-size: 1.2em;
}

 .hr-sect {
        display: flex;
        flex-basis: 100%;
        align-items: center;
        color: black
        font-size: 15px;
        margin: 8px 0px;
        margin-top: 1%;
    }
    .hr-sect::before,
    .hr-sect::after {
        content: "";
        flex-grow: 1;
        background: rgb(66, 139, 202);
        height: 2px;
        font-size: 0px;
        line-height: 0px;
        margin: 0px 16px;
    }
    .popover {
        z-index:99999 !important; 
    }

    .popover{
        max-width: 550px !important;
        max-height: 500px !important; 
        }
    .popover div{
        overflow-x: hidden !important;
    }
</style>
<body>

    <div id="wrapper">

        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header" style="background: background: #000;">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url();?>admin"><img src="<?php echo base_url();?>assets/img/logo.png" style="width:70%;"></img></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
           
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu">
                       <!--  <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li> -->
                        <li>
                            <a href="javascript:void(0);"> Admin </a>
                        </li>
                        <li class="divider"></li>
                       <li><a href="javascript:void(0);" onclick="changePassword();"><i class="fa fa-gear fa-fw"></i> Change password</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="<?php echo base_url();?>login/logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default navbar-static-side" role="navigation">
                <div class="sidebar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="<?php echo base_url();?>admin"><i class="fa fa-dashboard fa-fw"></i> Dashboard </a>
                        </li>
                        <!-- <li>
                            <a href="<?php echo base_url();?>admin/homePage"><i class="fa fa-dashboard fa-fw"></i> Home Page </a>
                        </li> -->
                        <li>
                            <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Content Management <span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                
                                <li>
                                    <a href="<?php echo base_url();?>admin/ourHome"> <i class="fa fa-dashboard fa-fw"></i> Our Home</a>
                                </li>
                                <!-- 
                                <li>
                                    <a href="<?php echo base_url();?>admin/vision"> <i class="fa fa-dashboard fa-fw"></i> Our Vision</a>
                                </li> -->
                                <li>
                                    <a href="<?php echo base_url();?>admin/aboutUs"> <i class="fa fa-dashboard fa-fw"></i> About Us </a>
                                </li>
                                <!-- <li>
                                    <a href="<?php echo base_url();?>admin/pressArticles"> <i class="fa fa-dashboard fa-fw"></i> Press Articles </a>
                                </li> -->
                                <!-- <li>
                                    <a href="<?php echo base_url();?>admin/ourProject"><i class="fa fa-home"></i> Our Project  </a>
                                </li> -->
                                <!-- <li>
                                    <a href="<?php echo base_url();?>admin/ourSale"> <i class="fa fa-dashboard fa-fw"></i> Our sale</a>
                                </li> -->
                                
                                <li>
                                    <a href="<?php echo base_url();?>admin/ourContact"><i class="fa fa-home"></i> Our Contact  </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url();?>admin/ourAppointment"><i class="fa fa-home"></i> Our Appointment  </a>
                                </li>
                                <!-- <li>
                                    <a href="<?php echo base_url();?>admin/whatisTic"><i class="fa fa-home"></i> What is a Tic </a>
                                </li> -->
                            </ul>
                        </li>
                        <li>
                        <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Master Data<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="<?php echo base_url();?>admin/slider"><i class="fa fa-dashboard fa-fw"></i> Slider </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url();?>admin/experience"><i class="fa fa-home"></i> Experience</a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url();?>admin/testimonial"><i class="fa fa-users"></i> Reviews </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url();?>admin/subscrib"><i class="fa fa-users"></i> Subscribed User </a>
                                </li> 
                                <!-- <li>
                                    <a href="<?php echo base_url();?>admin/sale"><i class="fa fa-users"></i> Property List </a>
                                </li> -->
                                <li>
                                    <a href="<?php echo base_url();?>admin/service"><i class="fa fa-users"></i> Services List </a>
                                </li>
                                 <!-- <li>
                                    <a href="<?php echo base_url();?>admin/blogCategory"><i class="fa fa-home"></i> Press Category </a>
                                </li> -->
                                <li>
                                    <a href="<?php echo base_url();?>admin/blog"><i class="fa fa-home"></i> Education List </a>
                                </li>
                               <!--  <li>
                                    <a href="<?php echo base_url();?>admin/growingCompany"><i class="fa fa-home"></i> Growing Comapany </a>
                                </li>
                               
                                <li>
                                    <a href="<?php echo base_url();?>admin/bannerPortfolio"><i class="fa fa-home"></i> Banner/ Protfolio Image </a>
                                </li>
                                
                                 <li>
                                    <a href="<?php echo base_url();?>admin/manageGallery">Manage Gallery</a>
                                </li> 
                                 <li>
                                    <a href="<?php echo base_url();?>admin/portfolioTag">Portfolio Tag</a>
                                </li>
                                 <li>
                                    <a href="<?php echo base_url();?>admin/roadMap">Road Map</a>
                                </li>-->
                                <!-- 
                                 <li>
                                    <a href="<?php echo base_url();?>admin/marketModel">Market Model</a>
                                </li> -->
                                <!-- <li>
                                    <a href="<?php //echo base_url();?>admin/ourVision"><i class="fa fa-dashboard fa-fw"></i> Our Vision </a>
                                </li>
                                <li>
                                    <a href="<?php //echo base_url();?>admin/ourProduct"><i class="fa fa-dashboard fa-fw"></i> Our Product </a>
                                </li>
                                
                                <li>
                                    <a href="<?php ///echo base_url();?>admin/technology"><i class="fa fa-dashboard fa-fw"></i> Technology </a>
                                </li>

                                <li>
                                    <a href="<?php //echo base_url();?>admin/teamManagement"><i class="fa fa-users"></i>  Team Management</a>
                                </li>

                                <li>
                                    <a href="<?php //echo base_url();?>admin/testimonial"><i class="fa fa-users"></i> Testimonials </a>
                                </li> -->
                                <!-- <li>
                                    <a href="<?php echo base_url();?>admin/ourClient"><i class="fa fa-users"></i> Our Client </a>
                                </li> -->
                                 <!-- <li>
                                    <a href="<?php //echo base_url();?>admin/ourLocation"><i class="fa fa-users"></i> Our Location </a>
                                </li> -->

                               <!--  <li>
                                    <a href="<?php echo base_url();?>admin/subscrib"><i class="fa fa-users"></i> Subscribed User </a>
                                </li> -->
                                 <li>
                                    <a href="<?php echo base_url();?>admin/contactUs"><i class="fa fa-users"></i> Contact Us </a>
                                </li>
                                 <li>
                                    <a href="<?php echo base_url();?>admin/appoitment"><i class="fa fa-users"></i> Appoitment List </a>
                                </li>
                                <!-- <li>
                                    <a href="<?php //echo base_url();?>admin/subject"><i class="fa fa-users"></i> Contact Us Subject </a>
                                </li> -->
                                 
                            </ul>
                        </li>
                       <!--  <li>
                            <a href="<?php echo base_url();?>admin/navigation"><i class="fa fa-gear"></i> Navigation </a>
                        </li> -->
                        <li>
                            <a href="<?php echo base_url();?>admin/setting"><i class="fa fa-gear"></i> Setting </a>
                        </li>
                        <li><a href="#"><i class="fa fa-bar-chart-o fa-fw"></i> Manage Menu  <span class="fa arrow"></span></a>
                            <ul>
                                <li><a href="<?php echo base_url();?>admin/manage_menu?menu=1">Header Menu</a></li>
                                    <li><a href="<?php echo base_url();?>admin/manage_menu?menu=2">Footer Menu</a></li>
                            </ul>
                        </li>
                         
                    </ul>
                    <!-- /#side-menu -->
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
