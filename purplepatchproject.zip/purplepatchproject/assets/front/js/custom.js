$(document).ready(function(){
  
  //Check to see if the window is top if not then display button
  $(window).scroll(function(){
    if ($(this).scrollTop() > 100) {
      $('#toTop a').fadeIn();
    } else {
      $('#toTop a').fadeOut();
    }
  });
  
  //Click event to scroll to top
  $('#toTop a').click(function(){
    $('html, body').animate({scrollTop : 0},1800);
    return false;
  });
  
});


// main slider 
    $('.banner_sec .owl-carousel').owlCarousel({
        loop:true,
        margin:0,
        autoplay:true,
        animateIn: 'fadeIn',
        animateOut: 'fadeOut',
        autoplayTimeout:4000,
        autoplayHoverPause:true,
        dots: true,
        nav:false,
        responsive:{

            0:{

                items:1
            },
            600:{

                items:1,
                nav:false
            },
            1000:{

                items:1,
                nav:false
            }
        }
    })

// main slider 
    $('.hot-property .owl-carousel').owlCarousel({
        loop:true,
        margin:0,
        autoplay:true,
        // animateIn: 'fadeIn',
        // animateOut: 'fadeOut',
        autoplayTimeout:4000,
        autoplayHoverPause:true,
        dots: true,
        nav:false,
        responsive:{

            0:{

                items:1
            },
            600:{

                items:1,
            },
            1000:{

                items:1,
            }
        }
    })

// client-testimonial
$('.ourClients .owl-carousel').owlCarousel({
        loop:true,
        margin:30,
        autoplay:true,
        autoplayTimeout:4000,
        autoplayHoverPause:true,
        dots: true,
        nav:true,
        responsive:{

            0:{

                items:1
            },
            600:{

                items:1,
            },
            1000:{

                items:4,
            }
        }
    })
// header fixed 
$(window).scroll(function() {
  var sticky = $('header'),
    scroll = $(window).scrollTop();
   
  if (scroll >= 80) { 
    sticky.addClass('fixed'); }
  else { 
   sticky.removeClass('fixed');

}
}); 
// date piker

$('.sidebar-btn').click(function() {
  $('#sidebar').toggleClass('active');
});


// clientSay

$('.clientSay .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})

// upcomingWeddingFestival

  $('.upcomingWeddingFestival .owl-carousel').owlCarousel({
      center:true,
      loop: true,
      margin: -55,
      nav: false,
      autoplay:true,
      autoplayTimeout:2500,
      autoplayHoverPause:true,
       responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:3
        }
    }
      
    })

$('.left_part_slider .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
})

$('.left_part_slider2 .owl-carousel').owlCarousel({
    loop:true,
    margin:40,
    nav:false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:3
        }
    }
})
