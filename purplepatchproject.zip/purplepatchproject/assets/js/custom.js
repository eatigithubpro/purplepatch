$(window).on('load', function() {
    $(".loader-wrap").fadeOut(500);

});
//console.log(slider_speed);
$(document).ready(function() {

    $('#case-studies').owlCarousel({
        center: true,
        items: 2,
        loop: true,
        margin: 30,
        nav: true,
        autoplay: 5000,
        dots: true,
        smartSpeed: 1500,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,
            },
            1000: {
                items: 2,
            }
        }
    });

    $('#our-clients').owlCarousel({
        center: true,
        items: 2,
        loop: true,
        margin: 30,
        nav: true,
        autoplay: 5000,
        dots: true,
        smartSpeed: 1500,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,
            },
            1000: {
                items: 2,
            }
        }
    });

    $('#our-team').owlCarousel({
        center: true,
        items: 4,
        loop: true,
        margin: 30,
        nav: true,
        autoplay: 5000,
        dots: true,
        smartSpeed: 1500,
        responsive: {
            0: {
                items: 1,
            },
            600: {
                items: 1,
            },
            1000: {
                items: 4,
            }
        }
    });

    if (typeof(slider_speeddetail) != "undefined" && slider_speeddetail !== null) {
        slider_speeddetail = parseInt(slider_speeddetail);
        slider_speeddetail = slider_speeddetail * 1000;
        console.log(slider_speeddetail)
        if (slider_speeddetail == '') {
            slider_speeddetail = 5000;
        }
    } else {
        var slider_speeddetail = 5000;
    }
    $('#p-slider').owlCarousel({
        items: 1,
        loop: true,
        autoplay: 5000,
        margin: 10,
        nav: false,
        dots: true,
        smartSpeed: slider_speeddetail
    });

    $('#h-slider').owlCarousel({
        items: 1,
        loop: true,
        autoplay: 5000,
        margin: 10,
        nav: true,
        dots: false,
        smartSpeed: 1500
    });

    $('.owl-nav button').on('click', function() {
        $('.owl-nav button').removeClass('active');
        $(this).addClass('active');
    });

    $('.menu').click(function(e) {
        e.stopPropagation();
        $('.side_menu').css('transform', 'translateX(0px)');
        $('.content_box ul li').addClass('slideInLeft wow');
        new WOW().init();
    });

    $('.add-link,.d-flex a:not(.video-link),#open-type').on('click', function() {
        $('.typo-form').addClass('active');
    });

    $('.close-type').click(function() {
        $('.typo-form').removeClass('active');
    });

    $('.side_menu').click(function(e) {
        e.stopPropagation();
    });

    $('#close_box').click(function(e) {
        $('.side_menu').css('transform', 'translateX(100%)');
        $('.content_box ul li').removeClass('slideInLeft wow');
    });

    var btn = $('#backtop');

    $(window).scroll(function() {
        if ($(window).scrollTop() > 600) {
            btn.addClass('show');
        } else {
            btn.removeClass('show');
        }
    });

    btn.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: 0 }, '2000');
    });
   // console.log(slider_speed);

   

    new WOW().init();


});

 if (typeof(slider_speed) != "undefined" && slider_speed !== null) {
        slider_speed = parseInt(slider_speed);
        slider_speed = slider_speed * 1000;
       // console.log(slider_speed)
        if (slider_speed == '') {
            slider_speed = 5000;
        }
    } else {
        var slider_speed = 5000;
    }
    console.log(slider_speed);

    $('#homeslider').carousel({
        interval: slider_speed,
        pause: false,
    });


$(document).on('click', 'a.scroll-down[href^="#"]',
    function(e) {
        var id = $(this).attr('href');
        //alert(id);
        var $id = $(id);
        if ($id.length === 0) {
            return;
        }
        e.preventDefault();
        var pos = $id.offset().top - 50 + "px";
        //alert(pos);
        $('body, html').animate({
            scrollTop: pos
        }, {
            duration: 1000
        });
    });


jQuery(document).ready(function($) {
    var overlayNav = $('.cd-overlay-nav'),
        overlayContent = $('.cd-overlay-content'),
        navigation = $('.cd-primary-nav'),
        toggleNav = $('.cd-nav-trigger');

    //inizialize navigation and content layers
    layerInit();
    $(window).on('resize', function() {
        window.requestAnimationFrame(layerInit);
    });

    //open/close the menu and cover layers
    toggleNav.on('click', function() {
        if (!toggleNav.hasClass('close-nav')) {
            //it means navigation is not visible yet - open it and animate navigation layer
            toggleNav.addClass('close-nav');

            overlayNav.children('span').velocity({
                translateZ: 0,
                scaleX: 1,
                scaleY: 1,
            }, 500, 'easeInCubic', function() {
                navigation.addClass('fade-in');
            });
        } else {
            //navigation is open - close it and remove navigation layer
            toggleNav.removeClass('close-nav');

            overlayContent.children('span').velocity({
                translateZ: 0,
                scaleX: 1,
                scaleY: 1,
            }, 500, 'easeInCubic', function() {
                navigation.removeClass('fade-in');

                overlayNav.children('span').velocity({
                    translateZ: 0,
                    scaleX: 0,
                    scaleY: 0,
                }, 0);

                overlayContent.addClass('is-hidden').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend', function() {
                    overlayContent.children('span').velocity({
                        translateZ: 0,
                        scaleX: 0,
                        scaleY: 0,
                    }, 0, function() { overlayContent.removeClass('is-hidden') });
                });
                if ($('html').hasClass('no-csstransitions')) {
                    overlayContent.children('span').velocity({
                        translateZ: 0,
                        scaleX: 0,
                        scaleY: 0,
                    }, 0, function() { overlayContent.removeClass('is-hidden') });
                }
            });
        }
    });

    function layerInit() {
        var diameterValue = (Math.sqrt(Math.pow($(window).height(), 2) + Math.pow($(window).width(), 2)) * 2);
        overlayNav.children('span').velocity({
            scaleX: 0,
            scaleY: 0,
            translateZ: 0,
        }, 50).velocity({
            height: diameterValue + 'px',
            width: diameterValue + 'px',
            top: -(diameterValue / 2) + 'px',
            left: -(diameterValue / 2) + 'px',
        }, 0);

        overlayContent.children('span').velocity({
            scaleX: 0,
            scaleY: 0,
            translateZ: 0,
        }, 50).velocity({
            height: diameterValue + 'px',
            width: diameterValue + 'px',
            top: -(diameterValue / 2) + 'px',
            left: -(diameterValue / 2) + 'px',
        }, 0);
    }
});