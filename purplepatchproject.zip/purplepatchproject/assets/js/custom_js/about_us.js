$(document).ready(function(){ 
    getPagecontent();
     $('#experiencelist').multiselect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });
     $('#pagesliderimage').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });
     $('#reviewslist').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });

  /*  $('#ourteamlist').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });*/

  });
  function getPagecontent(){
    var url="admin/getPageContent";
    var page_id=$("#page_id").val();
      data={page_id:page_id};
      var pro = viewDetailsByData(data,url);
      pro.success(function (succ){
      obj = $.parseJSON(succ);
      console.log('eati')
      console.log(obj)
      console.log(obj['content'][0].content_id)
      console.log('sinah')
      if(obj['content'][0].content_title!=''|| obj['content'][0].content_title!=null){
        $('#pagetitle').val(obj['content'][0].content_title);
      }

      if(obj['content'][0].content_url!==''|| obj['content'][0].content_url!==null){
        $('#pageslug').val(obj['content'][0].content_url);
      }

      // if(obj['content'][0].content_slider_speed!==''|| obj['content'][0].content_slider_speed!==null){
      //   $('#slider_speed').val(obj['content'][0].content_slider_speed);
      // }

       if(obj['content'][0].content_slider!==''|| obj['content'][0].content_slider!==null){
        if(obj['content'][0].content_slider){
              var datas1=obj['content'][0].content_slider;
              dataarray1=datas1.split(",");
              $("#pagesliderimage").val(dataarray1);
              $("#pagesliderimage").multiSelect("refresh");
            }
      }


      if(obj['content'][0].content_aboutimage!=''){
      var imageurl = base_url+obj['content'][0].content_aboutimage;
      $('#about_image_old').val(obj['content'][0].content_aboutimage);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);


    if(obj['content'][0].content_abouttitle!=''|| obj['content'][0].content_abouttitle!=null){
        $('#abouttitle').val(obj['content'][0].content_abouttitle);
      }

    /*if(obj['content'][0].content_aboutsubtitle!=''|| obj['content'][0].content_aboutsubtitle!=null){
        $('#aboutsubtitle').val(obj['content'][0].content_aboutsubtitle);
      }

    if(obj['content'][0].content_aboutlink!=''|| obj['content'][0].content_aboutlink!=null){
        $('#aboutlink').val(obj['content'][0].content_aboutlink);
      }*/

      // if(obj['content'][0].content_aboutcontent!==''|| obj['content'][0].content_aboutcontent!==null){
      //   $('#aboutdis').val(obj['content'][0].content_aboutcontent);
      // }

      if(obj['content'][0].content_aboutcontent!=''|| obj['content'][0].content_aboutcontent!=null){
        $('#aboutdis').val(obj['content'][0].content_aboutcontent);
      }

      if(obj['content'][0].aboutleftcontent!=''){
        CKEDITOR.instances['aboutleftcontent'].setData(obj['content'][0].aboutleftcontent);
      }
      if(obj['content'][0].aboutrightcontent!=''){
        CKEDITOR.instances['aboutrightcontent'].setData(obj['content'][0].aboutrightcontent);
      }

      if(obj['content'][0].content_philosophycontent!=''){
        CKEDITOR.instances['philosophydis'].setData(obj['content'][0].content_philosophycontent);
      }



    if(obj['content'][0].content_philosophytitle!=''|| obj['content'][0].content_philosophytitle!=null){
        $('#philosophytitle').val(obj['content'][0].content_philosophytitle);
      }


      if(obj['content'][0].content_philosophyimage!=''){
      var imageurl2 = base_url+obj['content'][0].content_philosophyimage;
      $('#philosophy_image_old').val(obj['content'][0].content_philosophyimage);
    }else{
      var imageurl2 = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_2').attr('src', imageurl2);



      

    if(obj['content'][0].content_experiencetitle!=''|| obj['content'][0].content_experiencetitle!=null){
        $('#experiencetitle').val(obj['content'][0].content_experiencetitle);
      }

    if(obj['content'][0].content_experiencesubtitle!=''|| obj['content'][0].content_experiencesubtitle!=null){
        $('#experiencesubtitle').val(obj['content'][0].content_experiencesubtitle);
      }

      if(obj['content'][0].content_experiencelist!==''|| obj['content'][0].content_experiencelist!==null){
          if(obj['content'][0].content_experiencelist){
                var datas6=obj['content'][0].content_experiencelist;
                dataarray6=datas6.split(",");
                $("#experiencelist").val(dataarray6);
                $("#experiencelist").multiSelect("refresh");
              }
        }

      /*  if(obj['content'][0].content_teamlisttitle!==''|| obj['content'][0].content_teamlisttitle!==null){
          $('#ourteamtitle').val(obj['content'][0].content_teamlisttitle);
        }*/
        

        if(obj['content'][0].content_reviewstitle!==''|| obj['content'][0].content_reviewstitle!==null){
        $('#reviewstitle').val(obj['content'][0].content_reviewstitle);
      }

      // if(obj['content'][0].content_slider_speed!==''|| obj['content'][0].content_slider_speed!==null){
      //   $('#slider_speed').val(obj['content'][0].content_slider_speed);
      // }

       if(obj['content'][0].content_reviewslist!==''|| obj['content'][0].content_reviewslist!==null){
        if(obj['content'][0].content_reviewslist){
              var datas3=obj['content'][0].content_reviewslist;
              dataarray3=datas3.split(",");
              $("#reviewslist").val(dataarray3);
              $("#reviewslist").multiSelect("refresh");
            }
      }




      $('#updatdId').val(obj['content'][0].content_id);
      $('#meta_key').val(obj['content'][0].content_meta_key);
        $('#meta_title').val(obj['content'][0].content_meta_title);
        $('#meta_desc').val(obj['content'][0].content_meta_desc);
    });
  }


function savePageContent(formId,url){ 
var page_id=$("#page_id").val();
  // if(page_id=='2'){
  // var descp =CKEDITOR.instances["weworkdis"].getData();
  //   document.getElementById("weworkdis").value=descp;
  // }
 /* var aboutdis =CKEDITOR.instances["aboutdis"].getData();
    document.getElementById("aboutdis").value=aboutdis;*/

    var descp =CKEDITOR.instances["aboutleftcontent"].getData();
    document.getElementById("aboutleftcontent").value=descp;
var descp2 =CKEDITOR.instances["aboutrightcontent"].getData();
    document.getElementById("aboutrightcontent").value=descp2;
var descp3 =CKEDITOR.instances["philosophydis"].getData();
    document.getElementById("philosophydis").value=descp3;
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: function(){
        //showLoader();
          }, 
        success: function (obj)
        {  
          console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {

          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg);
           

            setTimeout(function(){
              getPagecontent();
            },2000)
          }
        if (obj.err == 1)
        {
          showErrorMessage(formId,obj.msg);
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);
      }
    }
  });
}
