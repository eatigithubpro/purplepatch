$(document).ready(function(){ 
    

    $('#portfoliotaglist').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });
    /*$('#gallerycatelist').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });*/

    /*$('#slidercategorylist').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });*/
    $('#portfoliolist').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });

  });
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  my_sortable = $('#bannerPortfolioTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/bannerPortfolioList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
        { sWidth: '30%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' }
      ]
    });

  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#bannerPortfolioTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    console.log("id "+ids+" pos "+newPostion );
    var url="admin/updatebannerPortfolioPosition";
    data={menuId:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    //obj = $.parseJSON(succ);
      //alert("Success");
        swal({
          type: 'success',
          title: 'Success',
          showConfirmButton: false,
          timer: 2000
        });

      });
    });

    $('#bannerPortfolioTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
});

function addNew(){
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
 // CKEDITOR.instances['description'].setData('');
 /* $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');*/

  resetForm('bannerPortfolioForm');
  lockModal('bannerPortfolioModal');
  showModal('bannerPortfolioModal');
  $('#bannerPortfolioModal').find(".modal-title").html("");
  $('#bannerPortfolioModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}

function saveBannerPortfolio(formId,url){ 
    /*var descp =CKEDITOR.instances["description"].getData();
    document.getElementById("description").value=descp;*/
  pro= saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
      {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#bannerPortfolioModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          var dt = $("#bannerPortfolioTable").DataTable();
          dt.ajax.reload(null, false);
          close_modal('bannerPortfolioModal');
        },2000)
      }
    if (obj.err == 1)
    {
      $('#bannerPortfolioModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }

    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#bannerPortfolioModal').animate({scrollTop : 0}, 'slow');  
    }
  })
 
}

  function editBannerPortfolio(id){
    //CKEDITOR.instances['description'].setData('');
    $("#updatdId").val(id);
    resetForm('bannerPortfolioForm');
    lockModal('bannerPortfolioModal');
    showModal('bannerPortfolioModal');
    $('#bannerPortfolioModal').find(".modal-title").html("");
    $('#bannerPortfolioModal').find(".modal-title").html("Edit");

    getBannerPortfolioById(id);
  }

function getBannerPortfolioById(id){
  var url="admin/getBannerPortfolioById";
  data={id:id};
  var pro = viewDetailsByData(data,url);
  pro.success(function (succ){
  obj = $.parseJSON(succ);
  $('#banner_title').val(obj['banner'][0].title);
  $('#banner_color').val(obj['banner'][0].color);
  $('#banner_slug').val(obj['banner'][0].slug);

    if(obj['banner'][0].image!=''){
      var imageurl = base_url+obj['banner'][0].image;
      $('#company_image_old').val(obj['banner'][0].image);
      $('#banner_image_old').val(obj['banner'][0].image);
      
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }

    $('#imgbox_1').attr('src', imageurl);


    if(obj['banner'][0].title1!=''){
      $('#banner_title1').val(obj['banner'][0].title1);
    }
    if(obj['banner'][0].title2!=''){
      $('#banner_title2').val(obj['banner'][0].title2);
    }
    if(obj['banner'][0].title3!=''){
      $('#banner_title3').val(obj['banner'][0].title3);
    }



    if(obj['banner'][0].detail_image!=''){
      var imageurl2 = base_url+obj['banner'][0].detail_image;
      $('#detail_image_old').val(obj['banner'][0].detail_image);
      
    }else{
      var imageurl2 = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_2').attr('src', imageurl2);


    if(obj['banner'][0].detail_title!=''){
      $('#detail_title').val(obj['banner'][0].detail_title);
    }
    /*if(obj['banner'][0].detail_subtitle!=''){
      $('#detail_subtitle').val(obj['banner'][0].detail_subtitle);
    }*/
    if(obj['banner'][0].detail_dis!=''){
      $('#detail_desc').val(obj['banner'][0].detail_dis);
    }
    /*if(obj['banner'][0].detail_link!=''){
      $('#detail_link').val(obj['banner'][0].detail_link);
    }*/
    if(obj['banner'][0].creative_content!==''|| obj['banner'][0].creative_content!==null){
        if(obj['banner'][0].creative_content){
              var datas2=obj['banner'][0].creative_content;
              dataarray2=datas2.split(",");
              $("#creativecontentlist").val(dataarray2);
              $("#creativecontentlist").multiSelect("refresh");
            }
    }
    if(obj['banner'][0].featured_list!==''|| obj['banner'][0].featured_list!==null){
        if(obj['banner'][0].featured_list){
              var datas3=obj['banner'][0].featured_list;
              dataarray3=datas3.split(",");
              $("#portfoliotaglist").val(dataarray3);
              $("#portfoliotaglist").multiSelect("refresh");
            }
    }


    if(obj['banner'][0].bannerslider!=''){
      $('#bannerslidercategory').val(obj['banner'][0].bannerslider);
    }
    if(obj['banner'][0].bannersliderspeed!=''){
      $('#bannersliderspeed').val(obj['banner'][0].bannersliderspeed);
    }

    if(obj['banner'][0].sec1_title!=''){
      $('#sec1_title').val(obj['banner'][0].sec1_title);
    }
    if(obj['banner'][0].sec1_subtitle!=''){
      $('#sec1_subtitle').val(obj['banner'][0].sec1_subtitle);
    }

    if(obj['banner'][0].sec1_image!=''){
      var imageurl3 = base_url+obj['banner'][0].sec1_image;
      $('#sec1_image_old').val(obj['banner'][0].sec1_image);
      
    }else{
      var imageurl3= base_url+"assets/images/noimage.png";
    }
    $('#imgbox_3').attr('src', imageurl3);
    
    if(obj['banner'][0].sec1_disc!=''){
      $('#sec1_desc').val(obj['banner'][0].sec1_disc);
    }
    if(obj['banner'][0].sec2_title!=''){
      $('#sec2_title').val(obj['banner'][0].sec2_title);
    }
    if(obj['banner'][0].sec2_subtitle!=''){
      $('#sec2_subtitle').val(obj['banner'][0].sec2_subtitle);
    }
    if(obj['banner'][0].sec2_image!=''){
      var imageurl4 = base_url+obj['banner'][0].sec2_image;
      $('#sec2_image_old').val(obj['banner'][0].sec2_image);
      
    }else{
      var imageurl4= base_url+"assets/images/noimage.png";
    }
    $('#imgbox_4').attr('src', imageurl4);

    if(obj['banner'][0].sec2_disc!=''){
      $('#sec2_desc').val(obj['banner'][0].sec2_disc);
    }

    
    if(obj['banner'][0].sec2_obj_title!=''){
      $('#sec2obj_title').val(obj['banner'][0].sec2_obj_title);
    }
    if(obj['banner'][0].sec2_obj_subtitle!=''){
      $('#sec2obj_subtitle').val(obj['banner'][0].sec2_obj_subtitle);
    }   

    if(obj['banner'][0].sec2_obj_disc!=''){
      $('#sec2obj_desc').val(obj['banner'][0].sec2_obj_disc);
    }
    if(obj['banner'][0].sec2_obj_maindisc!=''){
      $('#sec2main_desc').val(obj['banner'][0].sec2_obj_maindisc);
    }


    if(obj['banner'][0].sec3_title!=''){
      $('#sec3_title').val(obj['banner'][0].sec3_title);
    }
    if(obj['banner'][0].sec3_subtitle!=''){
      $('#sec3_subtitle').val(obj['banner'][0].sec3_subtitle);
    }
    if(obj['banner'][0].sec3_image!=''){
      var imageurl5 = base_url+obj['banner'][0].sec3_image;
      $('#sec3_image_old').val(obj['banner'][0].sec3_image);
      
    }else{
      var imageurl5= base_url+"assets/images/noimage.png";
    }
    $('#imgbox_5').attr('src', imageurl5);
    
    if(obj['banner'][0].sec3_image2!=''){
      var imageurl6 = base_url+obj['banner'][0].sec3_image2;
      $('#sec3_image2_old').val(obj['banner'][0].sec3_image2);
      
    }else{
      var imageurl6= base_url+"assets/images/noimage.png";
    }
    $('#imgbox_6').attr('src', imageurl6);
    
    if(obj['banner'][0].sec3_disc!=''){
      $('#sec3_desc').val(obj['banner'][0].sec3_disc);
    }
    if(obj['banner'][0].sec3_disc2!=''){
      $('#sec3_desc2').val(obj['banner'][0].sec3_disc2);
    }

    if(obj['banner'][0].sec4_title!=''){
      $('#sec4_title').val(obj['banner'][0].sec4_title);
    }
    if(obj['banner'][0].sec4_subtitle!=''){
      $('#sec4_subtitle').val(obj['banner'][0].sec4_subtitle);
    }
    if(obj['banner'][0].sec4_image!=''){
      var imageurl7 = base_url+obj['banner'][0].sec4_image;
      $('#sec4_image_old').val(obj['banner'][0].sec4_image);
      
    }else{
      var imageurl7= base_url+"assets/images/noimage.png";
    }
    $('#imgbox_7').attr('src', imageurl7);
    
    if(obj['banner'][0].sec4_disc!=''){
      $('#sec4_desc').val(obj['banner'][0].sec4_disc);
    }




    /*if(obj['banner'][0].gallery_cate!==''|| obj['banner'][0].gallery_cate!==null){
        if(obj['banner'][0].gallery_cate){
              var datas3=obj['banner'][0].gallery_cate;
              dataarray3=datas3.split(",");
              $("#gallerycatelist").val(dataarray3);
              $("#gallerycatelist").multiSelect("refresh");
            }
    }*/

    /*if(obj['banner'][0].slider_cate!==''|| obj['banner'][0].slider_cate!==null){
        if(obj['banner'][0].slider_cate){
              var datas4=obj['banner'][0].slider_cate;
              dataarray4=datas4.split(",");
              $("#slidercategorylist").val(dataarray4);
              $("#slidercategorylist").multiSelect("refresh");
            }
    }*/

     if(obj['banner'][0].slider_cate!=''){
      $('#slidercategorylist').val(obj['banner'][0].slider_cate);
    }

    
    if(obj['banner'][0].slider_speed!=''){
      $('#slidercategorylistspeed').val(obj['banner'][0].slider_speed);
    }


    if(obj['banner'][0].related_portfolio!==''|| obj['banner'][0].related_portfolio!==null){
        if(obj['banner'][0].related_portfolio){
              var datas5=obj['banner'][0].related_portfolio;
              dataarray5=datas5.split(",");
              $("#portfoliolist").val(dataarray5);
              $("#portfoliolist").multiSelect("refresh");
            }
    }





    if(obj['banner'][0].featured_yn==1){
      $("#featuredYn").prop('checked',true);
      $("#featuredYn").val(1);
    }else{
       $("#featuredYn").prop('checked',false);
      $("#featuredYn").val(0);
    } 
    if(obj['banner'][0].meta_key!=''){
      $('#meta_key').val(obj['banner'][0].meta_key);
    }
    if(obj['banner'][0].meta_title!=''){
      $('#meta_title').val(obj['banner'][0].meta_title);
    }
    if(obj['banner'][0].meta_description!=''){
      $('#meta_desc').val(obj['banner'][0].meta_description);
    }
  }); 
}

function changeBannerPortfolioStatus(bannerId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeBannerPortfolioStatus', { 'bannerId':bannerId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#bannerPortfolioTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteBannerPortfolio(bannerId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteBannerPortfolio', { 'bannerId':bannerId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#bannerPortfolioTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }
