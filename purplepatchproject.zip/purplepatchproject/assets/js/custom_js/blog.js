
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  my_sortable = $('#BlogTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/BlogList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
       // { sWidth: '20%' },
        { sWidth: '20%' },
        { sWidth: '20%' },
        { sWidth: '20%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' } 
      ]
    });

  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#BlogTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    console.log("id "+ids+" pos "+newPostion );
    var url="admin/updateBlogPosition";
    data={menuId:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    //obj = $.parseJSON(succ);
      //alert("Success");
        swal({
          type: 'success',
          title: 'Success',
          showConfirmButton: false,
          timer: 2000
        });

      });
    });

    $('#BlogTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
});

function addNew(){
  //alert('hbhj ');
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');
  resetForm('BlogForm');
  lockModal('BlogModal');
  showModal('BlogModal');
  $('#BlogModal').find(".modal-title").html("");
  $('#BlogModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}

function saveBlog(formId,url){ 
    var descp =CKEDITOR.instances["description"].getData();
    document.getElementById("description").value=descp;
  pro= saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
      {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#BlogModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          var dt = $("#BlogTable").DataTable();
          dt.ajax.reload(null, false);
          close_modal('BlogModal');
        },2000)
      }
    if (obj.err == 1)
    {
      $('#BlogModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }

    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#BlogModal').animate({scrollTop : 0}, 'slow');  
    }
  })
 
}

function editBlog(id){
  CKEDITOR.instances['description'].setData('');
    $("#updatdId").val(id);
    resetForm('BlogForm');
    lockModal('BlogModal');
    showModal('BlogModal');
    $('#BlogModal').find(".modal-title").html("");
    $('#BlogModal').find(".modal-title").html("Edit");

    getBlogById(id);
}

function getBlogById(id){
  var url="admin/getBlogById";
  data={id:id};
  var pro = viewDetailsByData(data,url);
  pro.success(function (succ){
  obj = $.parseJSON(succ);
  console.log(obj)
  $('#blog_title').val(obj['blog'][0].title);
    if(obj['blog'][0].image!=''){
      var imageurl = base_url+obj['blog'][0].image;
      $('#blog_image_old').val(obj['blog'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    if(obj['blog'][0].description!=''){
      CKEDITOR.instances['description'].setData(obj['blog'][0].description);
    }

if(obj['blog'][0].videolink!==''|| obj['blog'][0].videolink!==null){
        $('#videolink').val(obj['blog'][0].videolink);
      }

    if(obj['blog'][0].publish_date!=''){
      $('#publish_date').val(obj['blog'][0].publish_date);
    }
    // if(obj['blog'][0].category_id!=''){
    //   $('#blog_cateid').val(obj['blog'][0].category_id);
    // }
    /*if(obj['blog'][0].blog_type!=''){
      $('#blog_type').val(obj['blog'][0].blog_type);
    }
     $('#author_name').val(obj['blog'][0].blog_author_name);
     $('#press_source').val(obj['blog'][0].press_source);
     $('#press_sourcelink').val(obj['blog'][0].press_sourcelink);*/
     
    // if(obj['blog'][0].blog_author_image!=''){
    //   var imageurl2 = base_url+obj['blog'][0].blog_author_image;
    //   $('#blog_author_image_old').val(obj['blog'][0].blog_author_image);
    // }else{
    //   var imageurl2 = base_url+"assets/images/noimage.png";
    // }
    // $('#imgbox_2').attr('src', imageurl2);
    // if(obj['blog'][0].blog_price!=''){
    //   $('#blog_price').val(obj['blog'][0].blog_price);
    // }
    // if(obj['blog'][0].blog_area!=''){
    //   $('#blog_area').val(obj['blog'][0].blog_area);
    // }
    // if(obj['blog'][0].blog_bedroom!=''){
    //   $('#blog_bedroom').val(obj['blog'][0].blog_bedroom);
    // }
    // if(obj['blog'][0].blog_livingroom!=''){
    //   $('#blog_livingroom').val(obj['blog'][0].blog_livingroom);
    // }
    // if(obj['blog'][0].blog_bathroom!=''){
    //   $('#blog_bathroom').val(obj['blog'][0].blog_bathroom);
    // }

    /* $('#meta_key').val(obj['blog'][0].meta_key);
        $('#meta_title').val(obj['blog'][0].meta_title);
        $('#meta_desc').val(obj['blog'][0].meta_description);*/

  }); 
}

function changeBlogStatus(blogId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeBlogStatus', { 'blogId':blogId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#BlogTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteBlog(blogId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteBlog', { 'blogId':blogId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#BlogTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }





function getAddSliderById(projectId){
    //var serviceId='10';
    //alert(projectId);

     resetForm('addSliderForm');
  lockModal('addSliderModal');
  showModal('addSliderModal');
  $('#addSliderModal').find(".modal-title").html("");
  $('#addSliderModal').find(".modal-title").html("Add Slider");
  $('.error').remove();
  $('#projectid').val(projectId);

    var url="admin/getAddSliderById";
    data={projectId:projectId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
      var table = $('#addSliderlistTable').DataTable({
        "searching": true,
        "pageLength": 20 ,
        "destroy": true,
        "rowReorder": true,
       /* "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
          
          decorateRow();
          //return nRow; 
          } */
        });
      var rows = table.rows().remove().draw();
       obj = $.parseJSON(succ);
       console.log(obj);
       
      $.each(obj['result'], function(i,v) {

//console.log(obj['result'][i].detail_title)
      

      if(obj['result'][i].status==1){
        var status ='<a href="javascript:void(0);" onclick="changeaddSliderStatus('+obj['result'][i].slider_id+','+obj['result'][i].status+');" data-toggle="tooltip" title="active !" "="" style="text-decoration:none;"><span class="label btn-primary">Active</span></a>';
      }else{
        var status ='<a href="javascript:void(0);" onclick="changeaddSliderStatus('+obj['result'][i].slider_id+','+obj['result'][i].status+');" data-toggle="tooltip" title="Inactive!" style="text-decoration:none;"><span class="cancel btn btn-xs btn-danger btn-default">Inactive</span></a>';
      }
      var action='<a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="EDIT" onclick="editaddSlider('+obj['result'][i].slider_id+');"> <i class="fa fa-pencil"></i> </a> <a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="Delete!" onclick="deleteAddSlider('+obj['result'][i].slider_id+');"><i class="fa fa-times"></i></a>';
    


   // var th= '<th>Title</th><th style="width: 17px;">Description</th>';
    var th= '<th>Title</th>';

    if(obj['result'][i].slider_beforeimage){
          var imgsrc=base_url+obj['result'][i].slider_beforeimage;
          var image="<img src="+imgsrc+" style='height: 38px;width: 100%;border-radius: 20%;'></img>";
        }else{
          var imgsrc=base_url+"assets/images/noimage.png";
          var image="<img src="+imgsrc+" style='height: 38px;width: 100%;border-radius: 20%;'></img>"; 
        } 
    if(obj['result'][i].slider_afterimage){
          var imgsrc2=base_url+obj['result'][i].slider_afterimage;
          var image2="<img src="+imgsrc2+" style='height: 38px;width: 100%;border-radius: 20%;'></img>";
        }else{
          var imgsrc2=base_url+"assets/images/noimage.png";
          var image2="<img src="+imgsrc2+" style='height: 38px;width: 100%;border-radius: 20%;'></img>"; 
        } 
        var rowIndex= $('#addSliderlistTable').dataTable().fnAddData([
          (i+1),
          image,
          image2,
          //obj['result'][i].slider_title,         
         // obj['result'][i].detail_dis,
          status,
          action
        ]);

         var row = $('#addSliderlistTable').dataTable().fnGetNodes(rowIndex);
        $(row).attr('id',"row_"+obj['result'][i].slider_id);

          });
          });


   }


   function saveaddSlider(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);
    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
          showLoader();
            }, 
        success: function (obj)
        {
         hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
                  getAddSliderById($('#projectid').val());
                  $('#imgbox_2').attr('src',base_url+'assets/images/noimage.png');
                  $('#imgbox_3').attr('src',base_url+'assets/images/noimage.png');
                  //checkGalleryWithInfoOrWithoutInfo($('#uploadType').val());
                  /*var $radios1 = $('input:radio[name=gallaryWithInfo]');
                  $radios1.filter('[value='+$('#uploadType').val()+']').prop('checked', true);*/
                  $('#cancelBtn').hide();
                /*$('.gallaryInfo').show();
                $('.withoutGallaryInfo').hide();*/
            },2000) 
        }
        if (obj.err == 1)
        { 
        showErrorMessage(formId,obj.msg);           
        }
    
        if (obj.err == 2)
        {
          appendMessageBody(formId);
          showDatabaseErrorMessage(formId,obj.msg);  
        }
      }
    });
  }

  function subdecorateRow(){
  //console.log('Yes');
   var SearchFieldsTable = $("#addSliderlistTable tbody");
    var trows = SearchFieldsTable.children("tr");
     var ids=[];
    var newPostion=[];
 
   
    $.each(trows, function (index, row1) {
      rowId = $(row1).attr("id");
      ids.push(rowId);
      newPostion.push(index+1);
    });

    var url="admin/updateaddSliderPosition";
    data={id:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
  var projectid=$('#projectid').val();

       getAddSliderById(projectid);
    // obj = $.parseJSON(succ);
        console.log(succ);
  
      });
      

}

function deleteAddSlider(addsliderId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteAddSlider', { 'addsliderId':addsliderId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var projectid=$('#projectid').val();
              getAddSliderById(projectid);
              /*var dt = $("#addSliderlistTable").DataTable();
              dt.ajax.reload(null, false);*/
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });


  
  }


  function changeaddSliderStatus(addsliderId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeAddSliderStatus', { 'addsliderId':addsliderId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var projectid=$('#projectid').val();
              getAddSliderById(projectid);
         /* var dt = $("#addSliderlistTable").DataTable();
          dt.ajax.reload(null, false);*/
        },2000)
    })
}

function editaddSlider(addsliderId){
    var url="admin/getaddSliderbysliderId";
    data={addsliderId:addsliderId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
    // $('#addtitle').val(obj['addslider'][0].slider_title);
    // $('#adddes').val(obj['addslider'][0].slider_dis);

    if(obj['addslider'][0].slider_beforeimage){
     var imgsrc=base_url+obj['addslider'][0].slider_beforeimage;
    }else{
      var imgsrc=base_url+"assets/images/noimage.png";
    }
    if(obj['addslider'][0].slider_afterimage){
     var imgsrc2=base_url+obj['addslider'][0].slider_afterimage;
    }else{
      var imgsrc2=base_url+"assets/images/noimage.png";
    }

    $('#imgbox_2').attr('src',imgsrc);
    $('#sliderbefore_image_old').val(obj['addslider'][0].slider_beforeimage);

    $('#imgbox_3').attr('src',imgsrc2);
    $('#sliderafter_image_old').val(obj['addslider'][0].slider_afterimage);
    
    $('#sliderprojectId').val(addsliderId);
    $('#cancelBtn').show();
        
      $('#addSliderModal').animate({
          scrollTop: $("#addSliderModal").first().offset().top - 250
      }, 1000);
  });
}