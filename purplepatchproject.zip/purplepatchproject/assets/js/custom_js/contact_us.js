
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  getRecord();
});
function getRecord(){
  $('#contactUsTable').DataTable({
    "destroy": true,
    "bProcessing": true,
    "language": {
        processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> '
         },
       // "lengthMenu": [[10, 25,50,100 ], [10, 25,50,100]],
        "dom": 'Bfrtip',
        "buttons": [
            'excelHtml5',
            'pdfHtml5','pageLength'
        ],
    "serverSide": true,
    "rowReorder": true,
     "ajax":{
      url :base_url+"admin/contactUsList",
      type: "post"
    },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
       // { sWidth: '20%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '30%' }
      ]
  });
  $('#contactUsTable').on('draw.dt', function () {
    $('.popoverData').popover({ trigger: "hover" });
    $('[data-toggle="tooltip"]').tooltip();
  });
}
