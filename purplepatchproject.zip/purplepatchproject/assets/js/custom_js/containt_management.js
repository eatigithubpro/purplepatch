
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  $('.multiSelectWithCheckbox').multiselect({
    columns: 1,
    placeholder: 'Select',
    search: true,
    selectAll: false
  });

});


function savePageContaint(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: function(){
        showLoader();
          }, 
        success: function (obj)
        {  
          //console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {
          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg); 
          $('#homePageModal').animate({scrollTop : 0}, 'slow'); 
            setTimeout(function(){
              getRecord()
            },2000)
          }
        if (obj.err == 1)
        {
          $('#homePageModal').animate({scrollTop : 0}, 'slow'); 
          showErrorMessage(formId,obj.msg);
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);
        $('#homePageModal').animate({scrollTop : 0}, 'slow');  
      }
    }
  });
}

function editContaint(id){
  $("#updatdId").val(id);
  resetForm('homePageForm');
  lockModal('homePageModal');
  showModal('homePageModal');
  $('#homePageModal').find(".modal-title").html("");
  $('#homePageModal').find(".modal-title").html("Edit");
  getContaint(id);
}

function getContaint(id){
  var url="admin/getContaintById";
  data={id:id};
  var pro = viewDetailsByData(data,url);
  pro.success(function (succ){
  obj = $.parseJSON(succ);
  //alert(obj['containt'][0]);
  $('#title').val(obj['containt'][0].title);
  $('#imageold').val(obj['containt'][0].image);
  if(obj['containt'][0].image!=='' || obj['containt'][0].image!==null){
    
    var imageurl = base_url+obj['containt'][0].image;
  }else{
    //alert('No');
    var imageurl = base_url+"assets/images/noimage.png";
  }
  
  $('#imgbox_0').attr('src', imageurl);
  $('#video_title').val(obj['containt'][0].video_title);
  $('#video_sub_title').val(obj['containt'][0].video_sub_title);
  $('#video_link').val(obj['containt'][0].video_url);
  $('#slug').val(obj['containt'][0].slug);

  var $radios = $('input:radio[name=open_link_in_new_tab_yn]');
  $radios.filter('[value='+obj['containt'][0].open_link_same_tab_yn+']').prop('checked', true);
      //console.log(obj['other_details'][0]); return false;

    $('#vision_desc').val(obj['other_details'][0]['sub_title']);
    
    if(obj['other_details'][0]['vision_id'] !== null){
      vision_id = obj['other_details'][0]['vision_id'];
      var visionArray = vision_id.split(",");
      $("#vision").val(visionArray);
      $("#vision").multiselect("reload");
    }
        
    if(obj['other_details'][0]['product_id'] !== null){
      product_id = obj['other_details'][0]['product_id'];
      var product_idArray = product_id.split(",");
      $("#product").val(product_idArray);
      $("#product").multiselect("reload");
    }
    
    if(obj['other_details'][0]['technology_id'] !== null){
      technology_id = obj['other_details'][0]['technology_id'];
      var technology_idArray = technology_id.split(",");
      $("#technology").val(technology_idArray);
      $("#technology").multiselect("reload");
    }

    if(obj['other_details'][0]['team_management_id'] !== null){
      team_management_id = obj['other_details'][0]['team_management_id'];
      var team_managementArray = team_management_id.split(",");
      $("#team").val(team_managementArray);
      $("#team").multiselect("reload");
    }

    if(obj['other_details'][0]['testimonial_id'] !== null){
      testimonial = obj['other_details'][0]['testimonial_id'];
      var testimonialArray = testimonial.split(",");
      $("#testimonial").val(testimonialArray);
      $("#testimonial").multiselect("reload");
    }

    if(obj['other_details'][0]['client_id'] !== null){
      client = obj['other_details'][0]['client_id'];
      var clientArray = client.split(",");
      $("#client").val(clientArray);
      $("#client").multiselect("reload");
    }

    $('#meta_key').val(obj['containt'][0].meta_key);
    $('#meta_title').val(obj['containt'][0].meta_title);
    $('#meta_desc').val(obj['containt'][0].meta_desc);

    }); 
  }


/*
function changeSliderStatus(sliderId){
  //console.log("test");
    $.post(base_url+'admin/changesliderStatus', { 'sliderId':sliderId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          getRecord();
        },2000)
    })
}*/


 /* function showslider(sliderId){
    lockModal('sliderModal');
    showModal('sliderModal');
    $('#sliderModal').find(".modal-title").html("");
    $('#sliderModal').find(".modal-title").html("View Slider");
    $('.notview').hide();
    $('.updateOnly').hide();
    $('#saveBtn').hide();
    getslider(sliderId);
    $('input[type="text"]').attr('readonly',true);
    $('#slider_name').prop("disabled", true);
    $('#slider_link').prop("disabled", true);
   // $('.summernoteEditor').summernote('disable');
 
  }
*/

/*function deleteSlider(sliderId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteSlider', { 'sliderId':sliderId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              getRecord()
            },2000)
          })
        .fail(function(){
          swal("Cancelled", "Something went wrong", "error");
        })
    }else{
      swal("Cancelled", "Your file is safe", "error"); 
    }
  });
}
*/
/*function showImage(sliderId){
  lockModal('ImageModal');
  showModal('ImageModal');
  $('#ImageModal').find(".modal-title").html("");
  $('#ImageModal').find(".modal-title").html("All Image");
    var url="admin/getslider";
    data={sliderId:sliderId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);
    console.log(obj['sliderlist'][0])
      var imageurl=base_url+'assets/uploads/slider/'+obj['sliderlist'][0].image;
      $('#viewsliderimage').attr('src', imageurl);
    });
  }*/

