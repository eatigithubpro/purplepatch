$(document).ready(function(){
  getRecord();
});
 
function getRecord(){
    var url="admin/getSetting";
    var pro = viewGridView(url);
    pro.success(function (suc){
      obj = $.parseJSON(suc);
    /*  CKEDITOR.instances['header'].setData(obj[0]['header']);
      CKEDITOR.instances['body'].setData(obj[0]['body']);
      CKEDITOR.instances['footer'].setData(obj[0]['footer']);*/
      //CKEDITOR.instances['socialIcon'].setData(obj[0]['socialIcon']);

      $('#sitetag').val(obj[0]['sitetag']);
      $('#sitetagfooter').val(obj[0]['sitetagfooter']);
      $('#header').val(obj[0]['header']);
      $('#body').val(obj[0]['body']);
      $('#footer').val(obj[0]['footer']);
      $('#footertitle').val(obj[0]['footertitle']);
      $('#footerdis').val(obj[0]['footerdis']);
      $('#footeraddress').val(obj[0]['footeraddress']);
      /*$('#footerphonemail').val(obj[0]['footerphonemail']);
      $('#socialIcon').val(obj[0]['socialIcon']);*/
      $('#phone_number').val(obj[0]['phone_number']);
      $('#emailid').val(obj[0]['email_id']);
      $('#facebook').val(obj[0]['facebook']);
      $('#instagram').val(obj[0]['instagram']);
      $('#linkedin').val(obj[0]['linkedin']);
      $('#twitter').val(obj[0]['twitter']);
      $('#dribbble').val(obj[0]['dribbble']);
      $('#copy_right').val(obj[0]['copy_right']);
      $('#emailFrom').val(obj[0]['emailFrom']);
      $('#emailTo').val(obj[0]['reply_to']);
      $('#updated_id').val(obj[0]['setting_id']);
      $('#from_text').val(obj[0]['email_from_text']);
      $('#reply_to_text').val(obj[0]['reply_to_text']);
      $('#cc').val(obj[0]['cc']);
      $('#bcc').val(obj[0]['bcc']);

      if(obj[0]['profile_image']!=''){
      var imageurl = base_url+obj[0]['profile_image'];
      $('#profile_image_old').val(obj[0]['profile_image']);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    $('#profile_name').val(obj[0]['profile_name']);
    $('#profile_detail').val(obj[0]['profile_detail']);
    $('#profilephone_number').val(obj[0]['profilephone_number']);
    $('#profileemailid').val(obj[0]['profileemailid']);

    });
  }


function saveSetting(formId,url){ 
  /*var header =CKEDITOR.instances["header"].getData();
  document.getElementById("header").value=header;

  var body1 =CKEDITOR.instances["body"].getData();
  document.getElementById("body").value=body1;

  var footer =CKEDITOR.instances["footer"].getData();
  document.getElementById("footer").value=footer;*/
/*
  var socialIcon =CKEDITOR.instances["socialIcon"].getData();
  document.getElementById("socialIcon").value=socialIcon;*/


    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
          //showLoader();
            }, 
        success: function (obj)
        {
          hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
              getRecord();
            },1000)
        }

        if (obj.err == 1)
        { 
        showErrorMessage(formId,obj.msg);          
        }
    
        if (obj.err == 2)
        {
          appendMessageBody(formId);
          showDatabaseErrorMessage(formId,obj.msg);  
        }
      }
    });
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}


 
