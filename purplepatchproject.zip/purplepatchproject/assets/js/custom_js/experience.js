$(document).ready(function(){ 
  
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  my_sortable = $('#ExperienceTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/experienceList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' } 
      ]
    });

  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#ExperienceTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    console.log("id "+ids+" pos "+newPostion );
    var url="admin/updateExperiencePosition";
    data={menuId:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    //obj = $.parseJSON(succ);
      //alert("Success");
        swal({
          type: 'success',
          title: 'Success',
          showConfirmButton: false,
          timer: 2000
        });

      });
    });

    $('#ExperienceTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
});

function addNew(){
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
 //CKEDITOR.instances['description'].setData('');
  resetForm('ExperienceForm');
  lockModal('ExperienceModal');
  showModal('ExperienceModal');
  $('#ExperienceModal').find(".modal-title").html("");
  $('#ExperienceModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}

function saveExperience(formId,url){ 
    /*var descp =CKEDITOR.instances["description"].getData();
    document.getElementById("description").value=descp;*/
  pro= saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
      {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#ExperienceModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          var dt = $("#ExperienceTable").DataTable();
          dt.ajax.reload(null, false);
          close_modal('ExperienceModal');
        },2000)
      }
    if (obj.err == 1)
    {
      $('#ExperienceModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }

    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#ExperienceModal').animate({scrollTop : 0}, 'slow');  
    }
  })
 
}

  function editGrowingCompany(id){
    //CKEDITOR.instances['description'].setData('');
    $("#updatdId").val(id);
    resetForm('ExperienceForm');
    lockModal('ExperienceModal');
    showModal('ExperienceModal');
    $('#ExperienceModal').find(".modal-title").html("");
    $('#ExperienceModal').find(".modal-title").html("Edit");

    getExperienceById(id);
  }

function getExperienceById(id){
  var url="admin/getExperienceById";
  data={id:id};
  var pro = viewDetailsByData(data,url);
  pro.success(function (succ){
  obj = $.parseJSON(succ);
  $('#experience_title').val(obj['experience'][0].title);
  
  

    if(obj['experience'][0].link!=''){
      $('#experience_link').val(obj['experience'][0].link);
    }
  }); 
}

function changeExperienceStatus(experienceId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeExperienceStatus', { 'experienceId':experienceId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#ExperienceTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteExperience(experienceId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteExperience', { 'experienceId':experienceId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#ExperienceTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }
