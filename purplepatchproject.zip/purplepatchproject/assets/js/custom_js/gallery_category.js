$(document).ready(function(){
  //$('#countryTable').dataTable();
  getRecord();
      $('input[name="checkVideoType"]').click(function () {
         if (this.checked) {
            $('.uploadedVideo').show();
            $('.videoLink').hide();
         }else{
            $('.uploadedVideo').hide();
            $('.videoLink').show();
         }
      });

});
function showimagepreview(input,count) {
  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }  
}

function getRecord(){
    $('#countryTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "serverSide": true,
       "ajax":{
        url :base_url+"admin/galleryCategoryList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      }
    });
  }

function addNew(){
  resetForm('galleryCategoryForm');
  lockModal('galleryCategoryModal');
  showModal('galleryCategoryModal');
  $('#galleryCategoryModal').find(".modal-title").html("");
  $('#galleryCategoryModal').find(".modal-title").html("Add New Category");
  $('.error').remove();
  
}

function saveGalleryCategory(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
         showLoader();
            }, 
        success: function (obj)
        {
          hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
               getRecord()
               close_modal('galleryCategoryModal');
            },2000) 
        
        }
  
        if (obj.err == 1)
        {
          
        showErrorMessage(formId,obj.msg); 
                  
        }
    
        if (obj.err == 2)
        {
            appendMessageBody(formId);
            showDatabaseErrorMessage(formId,obj.msg);  
        }
      
        }

    });

}

 function changeGCStatus(id){
    $.post(base_url + 'admin/changeGCStatus', { 'id':id })
        .done(function(response){
        console.log(response);
          swal({
            type: 'success',
            title: 'Status successfully changed',
            showConfirmButton: false,
            timer: 2000
          });
        //swal("Status changed.");
        //$('#row_'+stageId).hide();
        setTimeout(function(){
            getRecord();
        },2000)
    })
  }

function manageGallery(cid,uploadType){
  resetForm('galeryForm');
  lockModal('galleryModal');
  showModal('galleryModal');
  $('#galleryModal').find(".modal-title").html("");
  $('#galleryModal').find(".modal-title").html("Upload New Gallery Image");
  $('.error').remove();
  $('#category_id').val(cid);
  $('#uploadType').val(uploadType);
  get_Data(cid,uploadType);
  checkGalleryWithInfoOrWithoutInfo(uploadType);
  var $radios1 = $('input:radio[name=gallaryWithInfo]');
  $radios1.filter('[value='+uploadType+']').prop('checked', true);
}

function checkGalleryWithInfoOrWithoutInfo(val){
  //alert(val)
  if(val==2){
    $('.singleUpload').hide();
    $('.videoUpload').hide(); 
    $('.multiUpload').show(); 
  }
  if(val==3){
    $('.singleUpload').hide();
    $('.videoUpload').show(); 
    $('.multiUpload').hide(); 
  }
  if(val==1){
    $('.singleUpload').show();
    $('.videoUpload').hide(); 
    $('.multiUpload').hide(); 
  }
}


function saveGallery(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);
    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
          //showLoader();
            }, 
        success: function (obj)
        {
         hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
                  get_Data($('#category_id').val(),$('#uploadType').val());
                  checkGalleryWithInfoOrWithoutInfo($('#uploadType').val());
                  var $radios1 = $('input:radio[name=gallaryWithInfo]');
                  $radios1.filter('[value='+$('#uploadType').val()+']').prop('checked', true);
                  $('#cancelBtn').hide();
                /*$('.gallaryInfo').show();
                $('.withoutGallaryInfo').hide();*/
            },2000) 
        }
        if (obj.err == 1)
        { 
        showErrorMessage(formId,obj.msg);           
        }
    
        if (obj.err == 2)
        {
          appendMessageBody(formId);
          showDatabaseErrorMessage(formId,obj.msg);  
        }
      }
    });
  }

  function get_Data(categoryId,uploadType){
  $('#galleryModal').animate({
      scrollTop: $("#galleryModal").first().offset().top + 300
  }, 1000);
  $('#galleryModal').find('.dataTables_wrapper').css("display","none");

    if(uploadType==2){
      $('#customGallery').hide();

    }
 
  $('#category_id').val(categoryId);
  resetForm('galeryForm');
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  $('#wedding_gallery_old').val('');
  $('#updatedId').val('');
    var url="admin/getGalleryByCategory";
    data={categoryId:categoryId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    if(obj.result!=0){
      $('#gridView').show();
      $('#galleryTable_'+uploadType).show();
      $('#galleryTable_'+uploadType+'_wrapper').show();
        
      var table = $('#galleryTable_'+uploadType).DataTable();
      //table.columns.adjust().draw();
      var rows = table.rows().remove().draw();

      $.each(obj['result'], function(i,v) {
        if(obj['result'][i].image){
          var imgsrc=base_url+obj['result'][i].image
          var image="<img src="+imgsrc+" style='height: 38px;width: 100%;border-radius: 20%;'></img>";
        }else{
          var imgsrc=base_url+"assets/images/noimage.png";
          var image="<img src="+imgsrc+" style='height: 38px;width: 100%;border-radius: 20%;'></img>"; 
        } 
        //alert(obj['result'][i].video_link);
        if(obj['result'][i].video_link!=null){
          var videosrc = base_url+obj['result'][i].video_link
          var video = '<video width="200" height="100" controls><source src='+videosrc+' type="video/mp4"></video>';
        }else{
            var videosrc = obj['result'][i].video_code;
            //alert(videosrc)
            var video = '<iframe src="https://www.youtube.com/embed/'+videosrc+'?autoplay=1" height="100" style="width: 147px;"></iframe>';
        }

        
        if(obj['result'][i].status==1){
          var status ='<a href="javascript:void(0);" onclick="changeMGlleryStatus('+obj['result'][i].master_gallery_id+');" data-toggle="tooltip" title="active !" "="" style="text-decoration:none;"><span class="label btn-primary">Active</span></a>';
        }else{
          var status ='<a href="javascript:void(0);" onclick="changeMGlleryStatus('+obj['result'][i].master_gallery_id+');" data-toggle="tooltip" title="Inactive!" style="text-decoration:none;"><span class="cancel btn btn-xs btn-danger btn-default">Inactive</span></a>';
        }
        var action='<a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="EDIT" onclick="editMGallery('+obj['result'][i].master_gallery_id+');"> <i class="fa fa-pencil"></i> </a>';
      
        if(uploadType==2){
          //var th= '<th>Title</th><th style="width: 17px;">Image</th><th>link</th>';
          $('#galleryTable_'+uploadType).dataTable().fnAddData([
            (i+1),
            image,
            status
          ]);
        }
        if(uploadType==1){
          //var th= '<th>Title</th><th style="width: 17px;">Image</th><th>link</th><th>Open In new Tab</th>';
        
          $('#galleryTable_'+uploadType).dataTable().fnAddData([
            (i+1),
            obj['result'][i].title,
            image,
            status,
            action,
          ]);
        }
              
        if(uploadType==3){
           $('#galleryTable_'+uploadType).dataTable().fnAddData([
            (i+1),
            obj['result'][i].title,
            image,
            video,
            status,
            action,
          ]);
        }
      });
    }else{
      $('#gridView').hide();
    }
  });
}

function changeMGlleryStatus(id){
    $.post(base_url + 'admin/changeMGlleryStatus', { 'id':id })
        .done(function(response){
        console.log(response);
          swal({
            type: 'success',
            title: 'Status successfully changed',
            showConfirmButton: false,
            timer: 2000
          });
        setTimeout(function(){
            get_Data( $('#category_id').val(),$('#uploadType').val())
        },2000)
    })
}

function editMGallery(MGId){
    var url="admin/getMasterGalleryById";
    data={master_gallery_id:MGId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    $('#name').val(obj['result'][0].title);
   
   // alert(imgsrc);
    if(obj['result'][0].image){
     var imgsrc=base_url+obj['result'][0].image;
    }else{
      var imgsrc=base_url+"assets/images/noimage.png";
    }
    //alert(imgsrc)
    $('#imgbox_0').attr('src',imgsrc);
    $('#wedding_gallery_old').val(obj['result'][0].image);
    $('#updatedId').val(MGId);
    $('#cancelBtn').show();

      if(obj['result'][0].video_link!=null || obj['result'][0].video_code!=null)
      {
        $('#imgbox_1').attr('src',imgsrc);
        $('#gallery_video_image_old').val(obj['result'][0].image);

         if(obj['result'][0].check_video_type==1){
            $("#checkVideoType").prop('checked',true);
            $("#checkVideoType").val(1);
            $('.uploadedVideo').show();
            $('.videoLink').hide();
            
         }else{
            $("#checkVideoType").prop('checked', false);
            $("#checkVideoType").val(0);
            $('.uploadedVideo').hide();
            $('.videoLink').show();
            $('#video_code').val(obj['result'][0].video_code);
         }
        $('#title').val(obj['result'][0].title);

          if(obj['result'][0].video_link!=null){
            $('#wedding_gallery_video_old').val(obj['result'][0].video_link);
          }
        
          
      }else{
        $('#imgbox_0').attr('src',imgsrc);
      }

      $('#galleryModal').animate({
        scrollTop: $("#galleryModal").first().offset().top - 250
      }, 1000);
  });
}

function cancelUpdate(){
  resetForm('galeryForm');
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  $('#wedding_gallery_old').val('');
  $('#updatedId').val('');
  $('#cancelBtn').hide();
  $('.uploadedVideo').hide();
  $('.videoLink').show();
}

/*
function deleteCountry(id){
  swal({
    title: "Do you want to delete ?",
    //text: "You will not be able to recover this file!",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url + 'admin/deleteCountry', { 'id':id })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
              setTimeout(function(){
                getRecord()
              },2000)
          })
        .fail(function(){
          swal("Cancelled", "Something went wrong", "error");
        })
    }else{
      swal("Cancelled", "Your file is safe", "error"); 
    }
  });
}*/

 
