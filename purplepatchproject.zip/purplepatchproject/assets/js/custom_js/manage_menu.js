$(document).ready(function(){  
//getRecord(); 
  //$('.ckeditor2').ckeditor();     
var table = $('#ManageMenuTable').DataTable();
var menu=$('#menu_for').val();
  my_sortable=$('#ManageMenuTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/MenuList",
        type: "post",
        'data': function ( data ) {
          data.menu = menu ;
        },
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      }
    });

  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#ManageMenuTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      //console.log(row);
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    
    var url="admin/updateMenuPosition";
    
    data={id:ids,newPostion:newPostion};
   //console.log(data)
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
   /* obj = $.parseJSON(succ);
    console.log(obj);*/
      //alert("Success");

      });
    }); 
  my_sortable.ajax.reload(); 

    //getAboutUs();
    $('#menuhave_link').change(function() {
        if($(this).is(":checked")) {
          $('#havemenulinkdiv').show(500);

        }
        else {
          $('#havemenulinkdiv').hide(500);

        }
    });


    var table = $('#submenulistTable').DataTable({
        "searching": true,
        "destroy": true,
        "rowReorder": true,
        "pageLength": 20 
        });
      table.on( 'row-reorder', function ( e, diff, edit ) {
          subdecorateRow();
    });

});
function getRecord(){
  var menu=$('#menu_for').val();

    $('#ManageMenuTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/MenuList",
        type: "post",        
        'data': function ( data ) {
          data.menu = menu ;
        },
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      }
    });
  }

function addNew(){
  $('#imgbox_0').attr('src',base_url+"assets/images/noimage.png");
  resetForm('ManageMenuForm');
  lockModal('ManageMenuModal');
  showModal('ManageMenuModal');
  $('#ManageMenuModal').find(".modal-title").html("");
  $('#ManageMenuModal').find(".modal-title").html("Add New Menu");
  //$('.notview').show();
  $('#saveBtn').show();
  $('#havemenulinkdiv').hide();
  //$('.error').remove();
  $('input[type="text"]').attr('readonly',false);
  $('#menu_name').prop("disabled", false);
  $('#menu_link').prop("disabled", false);
  $('#menuhave_link').val('0');
  $('#menuhave_link').prop('checked',false);
  $("#updatdId").val('');
}
// for view Menu details
// for save user



function saveMenu(formId,url,addNew=''){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
       dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
        showLoader();
            }, 
        success: function (obj)
        {  
          console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {
          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg); 
              setTimeout(function(){
                getRecord()
                close_modal('ManageMenuModal');
              },2000)
          }
        if (obj.err == 1)
        { 
          showErrorMessage(formId,obj.msg);           
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);  
      }
    }
  });
}

function changeMenuStatus(menuid){
  //console.log("test");
    $.post(base_url+'admin/changemenuStatus', { 'menuid':menuid })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          getRecord();
        },2000)
    })
}

function getMenu(menuid){

  lockModal('ManageMenuModal');
  showModal('ManageMenuModal');
    var url="admin/getmenu";
    data={menuid:menuid};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);
    console.log(obj);
      $('#menu_name').val(obj['menulist'][0].menu_name);     
      $('#menu_link').val(obj['menulist'][0].menu_url);
      if(obj['menulist'][0].menuhave_link=='1'){
        $('#havemenulinkdiv').show();

      }
      else {
        $('#havemenulinkdiv').hide();
      }
      $("#menu_type").val(obj['menulist'][0].menu_type);
        /*var $select = $('#menu_type');
        $select.filter('option[value='+obj['menulist'][0].menu_type+']').prop('selected', true);*/
        /*var $radios1 = $('input[name=menuhave_link]');
        $radios1.filter('[value='+obj['menulist'][0].menuhave_link+']').prop('checked', true);*/
        var menuhave_link=obj['menulist'][0].menuhave_link;
        console.log(menuhave_link);

        var prop=false;
        if(menuhave_link == 1) {
           prop=true; 
        }
        $('#menuhave_link').prop('checked',prop);
       // $('#menuhave_link').prop('checked',(value == menuhave_link));

        var $radios = $('input:radio[name=link]');
        $radios.filter('[value='+obj['menulist'][0].menu_url_target+']').prop('checked', true);
    }); 
  }

  function showMenu(menuid){
    lockModal('ManageMenuModal');
    showModal('ManageMenuModal');
    $('#ManageMenuModal').find(".modal-title").html("");
    $('#ManageMenuModal').find(".modal-title").html("View Menu");
    /*$('.notview').hide();
    $('.updateOnly').hide();*/
    $('#saveBtn').hide();
    getMenu(menuid);
    $('input[type="text"]').attr('readonly',true);
    $('#menu_name').prop("disabled", true);
    $('#menu_link').prop("disabled", true);
   // $('.summernoteEditor').summernote('disable');
 
  }
   function editMenu(menuid){
      $("#updatdId").val(menuid);
      resetForm('ManageMenuForm');
      lockModal('ManageMenuModal');
      showModal('ManageMenuModal');
      $('#ManageMenuModal').find(".modal-title").html("");
      $('#ManageMenuModal').find(".modal-title").html("Edit Menu");
   
      getMenu(menuid);
      $('input[type="text"]').attr('readonly',false);
      $('#menu_name').prop("disabled", false);
      $('#menu_link').prop("disabled", false); 
}

function deleteMenu(menuid){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteMenu', { 'menuid':menuid })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              getRecord()
            },2000)
          })
        .fail(function(){
          swal("Cancelled", "Something went wrong", "error");
        })
    }else{
      swal("Cancelled", "Your file is safe", "error"); 
    }
  });
}

function subMenufun(menuid,uploadType){
  resetForm('SubmenuForm');
  lockModal('submenuModal');
  showModal('submenuModal');
  $("#menu_type_id").multiSelect("refresh");
  $('#submenuModal').find(".modal-title").html("");
  $('#submenuModal').find(".modal-title").html("Upload New Sub menu");
  $('.error').remove();
  $('#menuid').val(menuid);
  $('#uploadType').val(uploadType);
  console.log(uploadType);
  if(uploadType=='1'){
     $("#menu_type_id").multiSelect("refresh");
    $('#fornormaltypeofmenu').show();
    $('#forothertypeofmenu').hide();
    $('#submenulistTable').show();

    var url="admin/getSubmenuByid";
    data={menuid:menuid};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
      var table = $('#submenulistTable').DataTable({
        "searching": true,
        "pageLength": 20 ,
        "destroy": true,
        "rowReorder": true,
       /* "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
          
          decorateRow();
          //return nRow; 
          } */
        });
      var rows = table.rows().remove().draw();
       obj = $.parseJSON(succ);
       console.log(obj);
      $.each(obj['result'], function(i,v) {

    /*var url="admin/getSubmenuByid";
    data={menuid:menuid};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    //console.log(obj);
    var table = $('#submenulistTable').DataTable();
    //table.columns.adjust().draw();
    var rows = table.rows().remove().draw();

    $.each(obj['result'], function(i,v) {*/
      //console.log(obj['result'][i].menu_name);

      if(obj['result'][i].menu_url_target==0){
        var tab ="No";
      }else{
        var tab="Yes";
      }

      if(obj['result'][i].menu_status==1){
        var status ='<a href="javascript:void(0);" onclick="changesubMenuStatus('+obj['result'][i].menu_id+');" data-toggle="tooltip" title="active !" "="" style="text-decoration:none;"><span class="label btn-primary">Active</span></a>';
      }else{
        var status ='<a href="javascript:void(0);" onclick="changesubMenuStatus('+obj['result'][i].menu_id+');" data-toggle="tooltip" title="Inactive!" style="text-decoration:none;"><span class="cancel btn btn-xs btn-danger btn-default">Inactive</span></a>';
      }
      var action='<a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="EDIT" onclick="editsubMenu('+obj['result'][i].menu_id+');"> <i class="fa fa-pencil"></i> </a>';
    


    var th= '<th>Name</th><th style="width: 17px;">Link</th><th>Open in new tab</th>';
        var rowIndex= $('#submenulistTable').dataTable().fnAddData([
          (i+1),
          obj['result'][i].menu_name,         
          obj['result'][i].menu_url,
          tab,
          status,
          action
        ]);

         var row = $('#submenulistTable').dataTable().fnGetNodes(rowIndex);
        $(row).attr('id',"row_"+obj['result'][i].menu_id);

          });
          });


  }
  else if(uploadType=='2') {
     $("#menu_type_id").multiSelect("refresh");
    $('#fornormaltypeofmenu').hide();
    $('#forothertypeofmenu').show();
    $('#submenulistTable').hide();
    $('#selecttypename').html('Provider list');
    $('#submenuModal .panel-default').hide();
    var url="admin/getTypeidlist";
    console.log($('#uploadType').val());
    var uploadType=$('#uploadType').val();
    data={menu_type:uploadType};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
    var html="";
    $("#menu_type_id optgroup").html(html);
    

    $.each(obj['result'], function(i,v) {
       html ="<option value='"+obj['result'][i].provider_id+"'>"+obj['result'][i].title+"</option";
       $("#menu_type_id optgroup").append(html);


    });
    //console.log(html);

    
     $("#menu_type_id").multiSelect("refresh");

     var url2="admin/getmenu";
    data2={menuid:menuid};
    var pro2 = viewDetailsByData(data2,url2);
    pro2.success(function (suc){
    obj2 = $.parseJSON(suc);
    console.log(data2);
    console.log(obj2);
    /*$('#submenu_name').val(obj['menulist'][0].menu_name);
    $('#submenu_url').val(obj['menulist'][0].menu_url);
    var $radios = $('input:radio[name=submenu_url_target]');
    $radios.filter('[value='+obj['menulist'][0].menu_url_target+']').prop('checked', true);*/

     if(obj2['menulist'][0].menu_type_id){
        var datas2=obj2['menulist'][0].menu_type_id;
        dataarray2=datas2.split(",");
        $("#menu_type_id").val(dataarray2);
        $("#menu_type_id").multiSelect("refresh");
      }
    
    /*$('#updatedId').val(menuId);
    $('#cancelBtn').show();*/
        
      $('#submenuModal').animate({
          scrollTop: $("#submenuModal").first().offset().top - 250
      }, 1000);
  });


    });

  }
 else if(uploadType=='3') {
   $("#menu_type_id").multiSelect("refresh");
    $('#fornormaltypeofmenu').hide();
    $('#forothertypeofmenu').show();
    $('#submenulistTable').hide();
    $('#selecttypename').html('Show list');
    $('#submenuModal .panel-default').hide();
    var url="admin/getTypeidlist";
    console.log($('#uploadType').val());
    var uploadType=$('#uploadType').val();
    data={menu_type:uploadType};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
    var html="";
    $("#menu_type_id optgroup").html(html);
    

    $.each(obj['result'], function(i,v) {
       html ="<option value='"+obj['result'][i].weddding_festival_id+"'>"+obj['result'][i].title+"</option";
       $("#menu_type_id optgroup").append(html);


    });
    //console.log(html);

    
     $("#menu_type_id").multiSelect("refresh");

     var url2="admin/getmenu";
    data2={menuid:menuid};
    var pro2 = viewDetailsByData(data2,url2);
    pro2.success(function (suc){
    obj2 = $.parseJSON(suc);
    console.log(data2);
    console.log(obj2);
    /*$('#submenu_name').val(obj['menulist'][0].menu_name);
    $('#submenu_url').val(obj['menulist'][0].menu_url);
    var $radios = $('input:radio[name=submenu_url_target]');
    $radios.filter('[value='+obj['menulist'][0].menu_url_target+']').prop('checked', true);*/

     if(obj2['menulist'][0].menu_type_id){
        var datas2=obj2['menulist'][0].menu_type_id;
        dataarray2=datas2.split(",");
        $("#menu_type_id").val(dataarray2);
        $("#menu_type_id").multiSelect("refresh");
      }
    
    /*$('#updatedId').val(menuId);
    $('#cancelBtn').show();*/
        
      $('#submenuModal').animate({
          scrollTop: $("#submenuModal").first().offset().top - 250
      }, 1000);
  });


    });

  }
 else if(uploadType=='4') {
  $("#menu_type_id").multiSelect("refresh");
  console.log('ticket');
    $('#fornormaltypeofmenu').hide();
    $('#forothertypeofmenu').show();
    $('#submenulistTable').hide();
    $('#selecttypename').html('Ticket list');
    $('#submenuModal .panel-default').hide();
    var url="admin/getTypeidlist";
    console.log($('#uploadType').val());
    var uploadType=$('#uploadType').val();
    data={menu_type:uploadType};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
    var html="";
    $("#menu_type_id optgroup").html(html);
    

    $.each(obj['result'], function(i,v) {
       html ="<option value='"+obj['result'][i].ticket_id+"'>"+obj['result'][i].ticket_name+"</option";
       $("#menu_type_id optgroup").append(html);


    });
    //console.log(html);

    
     $("#menu_type_id").multiSelect("refresh");

     var url2="admin/getmenu";
    data2={menuid:menuid};
    var pro2 = viewDetailsByData(data2,url2);
    pro2.success(function (suc){
    obj2 = $.parseJSON(suc);
    console.log(data2);
    console.log(obj2);
    /*$('#submenu_name').val(obj['menulist'][0].menu_name);
    $('#submenu_url').val(obj['menulist'][0].menu_url);
    var $radios = $('input:radio[name=submenu_url_target]');
    $radios.filter('[value='+obj['menulist'][0].menu_url_target+']').prop('checked', true);*/

     if(obj2['menulist'][0].menu_type_id){
        var datas2=obj2['menulist'][0].menu_type_id;
        dataarray2=datas2.split(",");
        $("#menu_type_id").val(dataarray2);
        $("#menu_type_id").multiSelect("refresh");
      }
    
    /*$('#updatedId').val(menuId);
    $('#cancelBtn').show();*/
        
      $('#submenuModal').animate({
          scrollTop: $("#submenuModal").first().offset().top - 250
      }, 1000);
  });


    });

  }
  
}


function saveSubmenu(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);
    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
          showLoader();
            }, 
        success: function (obj)
        {
         hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
                  get_Data($('#menuid').val(),$('#uploadType').val());
                  //checkGalleryWithInfoOrWithoutInfo($('#uploadType').val());
                  /*var $radios1 = $('input:radio[name=gallaryWithInfo]');
                  $radios1.filter('[value='+$('#uploadType').val()+']').prop('checked', true);*/
                  $('#cancelBtn').hide();
                /*$('.gallaryInfo').show();
                $('.withoutGallaryInfo').hide();*/
            },2000) 
        }
        if (obj.err == 1)
        { 
        showErrorMessage(formId,obj.msg);           
        }
    
        if (obj.err == 2)
        {
          appendMessageBody(formId);
          showDatabaseErrorMessage(formId,obj.msg);  
        }
      }
    });
  }


  function get_Data(menuid,uploadType){
    console.log(menuid+'eati');
  $('#submenuModal').animate({
      scrollTop: $("#submenuModal").first().offset().top + 300
  }, 1000);
  $('#submenuModal').find('.dataTables_wrapper').css("display","none");

 
  $('#menuid').val(menuid);
  resetForm('SubmenuForm');
  $('#updatedId').val('');
    var url="admin/getSubmenuByid";
    data={menuid:menuid};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
      $('#submenulistTable').show();
      $('#submenulistTable_wrapper').show();
     
    var table = $('#submenulistTable').DataTable();
    //table.columns.adjust().draw();
    var rows = table.rows().remove().draw();

    $.each(obj['result'], function(i,v) {
      console.log(obj['result'][i].menu_status);
      
     if(obj['result'][i].menu_url_target==0){
        var tab ="No";
      }else{
        var tab="Yes";
      }

      if(obj['result'][i].menu_status==1){
        var status ='<a href="javascript:void(0);" onclick="changesubMenuStatus('+obj['result'][i].menu_id+');" data-toggle="tooltip" title="active !" "="" style="text-decoration:none;"><span class="label btn-primary">Active</span></a>';
      }else{
        var status ='<a href="javascript:void(0);" onclick="changesubMenuStatus('+obj['result'][i].menu_id+');" data-toggle="tooltip" title="Inactive!" style="text-decoration:none;"><span class="cancel btn btn-xs btn-danger btn-default">Inactive</span></a>';
      }
      var action='<a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="EDIT" onclick="editsubMenu('+obj['result'][i].menu_id+');"> <i class="fa fa-pencil"></i> </a>';
    
    var th= '<th>Name</th><th style="width: 17px;">Link</th><th>Open in new tab</th>';
        var rowIndex = $('#submenulistTable').dataTable().fnAddData([
          (i+1),
          obj['result'][i].menu_name,         
          obj['result'][i].menu_url,
          tab,
          status,
          action
        ]);
         var row = $('#submenulistTable').dataTable().fnGetNodes(rowIndex);
        $(row).attr('id',"row_"+obj['result'][i].menu_id);
    });
  });

}

function subdecorateRow(){
  //console.log('Yes');
   var SearchFieldsTable = $("#submenulistTable tbody");
    var trows = SearchFieldsTable.children("tr");
     var ids=[];
    var newPostion=[];
 
   
    $.each(trows, function (index, row1) {
      rowId = $(row1).attr("id");
      ids.push(rowId);
      newPostion.push(index+1);
    });

    var url="admin/updateMenuPosition";
    data={id:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
  var menuid=$('#menuid').val(menuid);
  var uploadType=$('#uploadType').val(uploadType);

       subMenufun(menuid,uploadType);
    // obj = $.parseJSON(succ);
        console.log(succ);
  
      });
      

}
function changesubMenuStatus(menuid){
  //console.log("test");
    $.post(base_url+'admin/changemenuStatus', { 'menuid':menuid })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          console.log(menuid,$('#uploadType').val());
           get_Data($('#menuid').val(),$('#uploadType').val());
        },2000)
    })
}


function editsubMenu(menuid){
    var url="admin/getmenu";
    data={menuid:menuid};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
    $('#submenu_name').val(obj['menulist'][0].menu_name);
    $('#submenu_url').val(obj['menulist'][0].menu_url);
    var $radios = $('input:radio[name=submenu_url_target]');
    $radios.filter('[value='+obj['menulist'][0].menu_url_target+']').prop('checked', true);
    
    $('#updatedId').val(menuid);
    $('#cancelBtn').show();
        
      $('#submenuModal').animate({
          scrollTop: $("#submenuModal").first().offset().top - 250
      }, 1000);
  });
}
