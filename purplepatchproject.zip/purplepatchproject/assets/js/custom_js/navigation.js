
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  var table = $('#navigationTable').DataTable();
  my_sortable=$('#navigationTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/navigationList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      }
    });
  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#navigationTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    console.log("id "+ids+" pos "+newPostion );
    var url="admin/updatePosition";
    data={menuId:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    //obj = $.parseJSON(succ);
      alert("Success");

      });
    });
});



function getRecord(){
    $('#navigationTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/navigationList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
        { sWidth: '10%' }
      ]
    });
    $('#navigationTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
  }


/*
function saveOurVision(formId,url){ 
  var descp =CKEDITOR.instances["description"].getData();
  document.getElementById("description").value=descp;

    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: function(){
        //showLoader();
          }, 
        success: function (obj)
        {  
          console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {

          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg); 
          $('#ourVisionModal').animate({scrollTop : 0}, 'slow'); 
            setTimeout(function(){
              var dt = $("#ourVisionTable").DataTable();
              dt.ajax.reload(null, false);
              close_modal('ourVisionModal');
            },2000)
          }
        if (obj.err == 1)
        {
          $('#ourVisionModal').animate({scrollTop : 0}, 'slow'); 
          showErrorMessage(formId,obj.msg);
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);
        $('#ourVisionModal').animate({scrollTop : 0}, 'slow');  
      }
    }
  });
}*/

  function editNavigation(id){
    $("#updatdId").val(id);
    $('#editbtn_'+id).hide();
    $('#span_'+id).hide();
    $('#cancelbtn_'+id).show();
    $('#savebtn_'+id).show();
    $('#menu_'+id).show();
    //getVision(id);

  }

  function cancelUpdate(id){
    $('#editbtn_'+id).show();
    $('#span_'+id).show();
    $('#cancelbtn_'+id).hide();
    $('#savebtn_'+id).hide();
    $('#menu_'+id).hide();
  }
  function update(id){
    var menu = $('#menu_'+id).val();
    var id = id;
    data = {menu:menu,id:id}
     $.ajax({
        url: base_url+"admin/updateMenu",
        type: "POST",
        data: data,
        beforeSend: function(){
        showLoader();
          }, 
        success: function (succ)
        {
          hideLoader();
          obj = $.parseJSON(succ);
          if (obj.err == 1)
          {
           $('#error_'+id).show();
           $('#error_'+id).html("Menu is empty.");  
          }

          if (obj.err == 0)
          {
              swal({
                type: 'success',
                title: obj.msg,
                showConfirmButton: false,
                timer: 2000
              });
            setTimeout(function(){
              var dt = $("#navigationTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          }
          if (obj.err == 2)
          {
              swal({
                type: 'warning',
                title: obj.msg,
                showConfirmButton: false,
                timer: 2000
              });
            setTimeout(function(){
              var dt = $("#navigationTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          } 
        }
      });
  }

/*function getVision(id){

    var url="admin/getVisionById";
    data={id:id};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);

    $('#vision_title').val(obj['vision'][0].title);

   
    if(obj['vision'][0].image!=''){
      var imageurl = base_url+obj['vision'][0].image;
       $('#vision_image_old').val(obj['vision'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    if(obj['vision'][0].logo!=''){
      var imageurl = base_url+obj['vision'][0].logo;
       $('#vision_logo_old').val(obj['vision'][0].logo);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_0').attr('src', imageurl);

    CKEDITOR.instances['description'].setData(obj['vision'][0].description);
    $('#meta_key').val(obj['vision'][0].meta_key);
    $('#meta_title').val(obj['vision'][0].meta_title);
    $('#meta_desc').val(obj['vision'][0].meta_desc);

    }); 
  }
*/


function changeNavigationStatus(navigationid,status){
  //console.log("test");
    $.post(base_url+'admin/changeNavigationStatus', { 'navigationid':navigationid,'status':status })
      .done(function(response){
  
      obj = $.parseJSON(response);
      if(obj.err==0){
        swal({
          type: 'success',
          title: obj.msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#navigationTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
      }
      if(obj.err==2){
        swal({
          type: 'warning',
          title: obj.msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#navigationTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
      }

    })
}




function deleteVision(visionId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteVision', { 'visionId':visionId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              getRecord()
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }

/*function showImage(sliderId){
  lockModal('ImageModal');
  showModal('ImageModal');
  $('#ImageModal').find(".modal-title").html("");
  $('#ImageModal').find(".modal-title").html("All Image");
    var url="admin/getslider";
    data={sliderId:sliderId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);
    console.log(obj['sliderlist'][0])
      var imageurl=base_url+'assets/uploads/slider/'+obj['sliderlist'][0].image;
      $('#viewsliderimage').attr('src', imageurl);
    });
  }*/

