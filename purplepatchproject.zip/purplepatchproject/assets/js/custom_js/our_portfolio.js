$(document).ready(function(){ 
  $('#pagesliderimage').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });
    getPagecontent();
  });
  function getPagecontent(){
    var url="admin/getPageContent";
    var page_id=$("#page_id").val();
      data={page_id:page_id};
      var pro = viewDetailsByData(data,url);
      pro.success(function (succ){
      obj = $.parseJSON(succ);
      console.log(obj)
      if(obj['content'][0].content_title!=''|| obj['content'][0].content_title!=null){
        $('#pagetitle').val(obj['content'][0].content_title);
      }

      if(obj['content'][0].content_url!==''|| obj['content'][0].content_url!==null){
        $('#pageslug').val(obj['content'][0].content_url);
      }     
      if(obj['content'][0].content_slider!==''|| obj['content'][0].content_slider!==null){
        if(obj['content'][0].content_slider){
              var datas1=obj['content'][0].content_slider;
              dataarray1=datas1.split(",");
              $("#pagesliderimage").val(dataarray1);
              $("#pagesliderimage").multiSelect("refresh");
            }
      }

      $('#updatdId').val(obj['content'][0].content_id);
      $('#meta_keypage').val(obj['content'][0].content_meta_key);
        $('#meta_titlepage').val(obj['content'][0].content_meta_title);
        $('#meta_descpage').val(obj['content'][0].content_meta_desc);
    });
  }


function savePageContent(formId,url){ 
  /*var descp =CKEDITOR.instances["weworkdis"].getData();
    document.getElementById("weworkdis").value=descp;*/
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: function(){
        //showLoader();
          }, 
        success: function (obj)
        {  
          console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {
          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg);         

            setTimeout(function(){
              getPagecontent();
            },2000)
          }
        if (obj.err == 1)
        {
          showErrorMessage(formId,obj.msg);
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);
      }
    }
  });
}
