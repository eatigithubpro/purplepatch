
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  getRecord();
});
function getRecord(){
    $('#productTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/productList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '8%' },
        { sWidth: '20%' },
        { sWidth: '10%' },
        { sWidth: '13%' },
        { sWidth: '20%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '15%' }
      ]
    });
    $('#productTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
  }

function addNew(){
  $('#imgbox_0').attr('src',base_url+"assets/images/noimage.png");
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');

  resetForm('productForm');
  lockModal('productModal');
  showModal('productModal');
  $('#productModal').find(".modal-title").html("");
  $('#productModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}

function saveProduct(formId,url){ 
  var descp =CKEDITOR.instances["description"].getData();
  document.getElementById("description").value=descp;

    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: function(){
        //showLoader();
          }, 
        success: function (obj)
        {  
          console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {

          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg); 
          $('#productModal').animate({scrollTop : 0}, 'slow'); 
            setTimeout(function(){
              getRecord()
              close_modal('productModal');
            },2000)
          }
        if (obj.err == 1)
        {
          $('#productModal').animate({scrollTop : 0}, 'slow'); 
          showErrorMessage(formId,obj.msg);
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);
        $('#productModal').animate({scrollTop : 0}, 'slow');  
      }
    }
  });
}

  function editProduct(id){

    $("#updatdId").val(id);
    resetForm('productForm');
    lockModal('productModal');
    showModal('productModal');
    $('#productModal').find(".modal-title").html("");
    $('#productModal').find(".modal-title").html("Edit Vision");

    getProduct(id);
  }

function getProduct(id){

    var url="admin/getProductById";
    data={id:id};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);

    $('#product_title').val(obj['product'][0].title);

   
    if(obj['product'][0].image!=''){
      var imageurl = base_url+obj['product'][0].image;
      $('#product_image_old').val(obj['product'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);



    if(obj['product'][0].thumbnail_image!=''){
      var imageurl = base_url+obj['product'][0].thumbnail_image;
       $('#thumbnails_old').val(obj['product'][0].thumbnail_image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_0').attr('src', imageurl);
    $('#video_url').val(obj['product'][0].video);
    CKEDITOR.instances['description'].setData(obj['product'][0].description);
    $('#meta_key').val(obj['product'][0].meta_key);
    $('#meta_title').val(obj['product'][0].meta_title);
    $('#meta_desc').val(obj['product'][0].meta_desc);

    }); 
  }



function changeProductStatus(productId){
  //console.log("test");
    $.post(base_url+'admin/changeProductStatus', { 'productId':productId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#productTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteProduct(productId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteProduct', { 'productId':productId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#productTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }

/*function showImage(sliderId){
  lockModal('ImageModal');
  showModal('ImageModal');
  $('#ImageModal').find(".modal-title").html("");
  $('#ImageModal').find(".modal-title").html("All Image");
    var url="admin/getslider";
    data={sliderId:sliderId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);
    console.log(obj['sliderlist'][0])
      var imageurl=base_url+'assets/uploads/slider/'+obj['sliderlist'][0].image;
      $('#viewsliderimage').attr('src', imageurl);
    });
  }*/

