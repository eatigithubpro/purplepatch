$(document).ready(function(){ 
    getPagecontent()
    

    $('#clientfeedbacklist').multiSelect({
        columns: 1,
        placeholder: 'Select',
        search: true,
        selectAll: false
    });

  });
  function getPagecontent(){
    var url="admin/getPageContent";
    var page_id=$("#page_id").val();
      data={page_id:page_id};
      var pro = viewDetailsByData(data,url);
      pro.success(function (succ){
      obj = $.parseJSON(succ);
      console.log('eati')
      console.log(obj)
      console.log(obj['content'][0].content_id)
      console.log('sinah')
      if(obj['content'][0].content_title!=''|| obj['content'][0].content_title!=null){
        $('#pagetitle').val(obj['content'][0].content_title);
      }

      if(obj['content'][0].content_url!==''|| obj['content'][0].content_url!==null){
        $('#pageslug').val(obj['content'][0].content_url);
      }


          if(obj['content'][0].content_pressarticle_image!=''){
      var imageurl2 = base_url+obj['content'][0].content_pressarticle_image;
      $('#pressarticle_image_old').val(obj['content'][0].content_pressarticle_image);
    }else{
      var imageurl2 = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_2').attr('src', imageurl2);


    if(obj['content'][0].content_pressarticle_title!=''|| obj['content'][0].content_pressarticle_title!=null){
        $('#pressarticletitle').val(obj['content'][0].content_pressarticle_title);
      }

  if(obj['content'][0].content_pressarticle!=''){
      CKEDITOR.instances['pressarticledis'].setData(obj['content'][0].content_pressarticle);
    }
        if(obj['content'][0].content_testimonialtitle!==''|| obj['content'][0].content_testimonialtitle!==null){
          $('#clientfeedbacktitle').val(obj['content'][0].content_testimonialtitle);
        }
        if(obj['content'][0].content_testimonialsubtitle!==''|| obj['content'][0].content_testimonialsubtitle!==null){
          $('#clientfeedbacksubtitle').val(obj['content'][0].content_testimonialsubtitle);
        }

      

      if(obj['content'][0].content_testimoniallist!==''|| obj['content'][0].content_testimoniallist!==null){
        if(obj['content'][0].content_testimoniallist){
              var datas6=obj['content'][0].content_testimoniallist;
              dataarray6=datas6.split(",");
              $("#clientfeedbacklist").val(dataarray6);
              $("#clientfeedbacklist").multiSelect("refresh");
            }
      }


      $('#updatdId').val(obj['content'][0].content_id);
      $('#meta_key').val(obj['content'][0].content_meta_key);
        $('#meta_title').val(obj['content'][0].content_meta_title);
        $('#meta_desc').val(obj['content'][0].content_meta_desc);
    });
  }


function savePageContent(formId,url){ 
var page_id=$("#page_id").val();
 var descp =CKEDITOR.instances["pressarticledis"].getData();
    document.getElementById("pressarticledis").value=descp;
  // if(page_id=='2'){
  // var descp =CKEDITOR.instances["weworkdis"].getData();
  //   document.getElementById("weworkdis").value=descp;
  // }
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: function(){
        //showLoader();
          }, 
        success: function (obj)
        {  
          console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {

          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg);
           

            setTimeout(function(){
              getPagecontent();
            },2000)
          }
        if (obj.err == 1)
        {
          showErrorMessage(formId,obj.msg);
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);
      }
    }
  });
}
