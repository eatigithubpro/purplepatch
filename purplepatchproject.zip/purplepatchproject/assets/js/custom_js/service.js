
$(document).ready(function(){ 
  
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  my_sortable = $('#ServiceTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/ServiceList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
        /*{ sWidth: '20%' },
        { sWidth: '20%' },*/
        { sWidth: '20%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' } 
      ]
    });

  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#ServiceTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    console.log("id "+ids+" pos "+newPostion );
    var url="admin/updateServicePosition";
    data={menuId:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    //obj = $.parseJSON(succ);
      //alert("Success");
        swal({
          type: 'success',
          title: 'Success',
          showConfirmButton: false,
          timer: 2000
        });

      });
    });

    $('#ServiceTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
});

function addNew(){
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');
  resetForm('ServiceForm');
  lockModal('ServiceModal');
  showModal('ServiceModal');
  $('#ServiceModal').find(".modal-title").html("");
  $('#ServiceModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
  $("#service_type").prop('checked',false);
      $("#service_type").val(0);
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}

function saveService(formId,url){ 
    var descp =CKEDITOR.instances["description"].getData();
    document.getElementById("description").value=descp;
  pro= saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
      {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#ServiceModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          var dt = $("#ServiceTable").DataTable();
          dt.ajax.reload(null, false);
          close_modal('ServiceModal');
        },2000)
      }
    if (obj.err == 1)
    {
      $('#ServiceModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }

    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#ServiceModal').animate({scrollTop : 0}, 'slow');  
    }
  })
 
}

function editService(id){
  CKEDITOR.instances['description'].setData('');
    $("#updatdId").val(id);
    resetForm('ServiceForm');
    lockModal('ServiceModal');
    showModal('ServiceModal');
    $('#ServiceModal').find(".modal-title").html("");
    $('#ServiceModal').find(".modal-title").html("Edit");

    getServiceById(id);
}

function getServiceById(id){
  var url="admin/getServiceById";
  data={id:id};
  var pro = viewDetailsByData(data,url);
  pro.success(function (succ){
  obj = $.parseJSON(succ);
  $('#service_title').val(obj['service'][0].title);
    if(obj['service'][0].image!=''){
      var imageurl = base_url+obj['service'][0].image;
      $('#service_image_old').val(obj['service'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    if(obj['service'][0].description!=''){
      CKEDITOR.instances['description'].setData(obj['service'][0].description);
    }


    /*if(obj['service'][0].subtitle!=''){
      $('#service_subtitle').val(obj['service'][0].subtitle);
    }
    if(obj['service'][0].service_link!=''){
      $('#service_link').val(obj['service'][0].service_link);
    }
    if(obj['service'][0].service_type==1){
      $("#service_type").prop('checked',true);
      $("#service_type").val(1);
    }else{
       $("#service_type").prop('checked',false);
      $("#service_type").val(0);
    } */
    // if(obj['project'][0].project_price!=''){
    //   $('#project_price').val(obj['project'][0].project_price);
    // }
    // if(obj['project'][0].project_area!=''){
    //   $('#project_area').val(obj['project'][0].project_area);
    // }
    // if(obj['project'][0].project_bedroom!=''){
    //   $('#project_bedroom').val(obj['project'][0].project_bedroom);
    // }
    // if(obj['project'][0].project_livingroom!=''){
    //   $('#project_livingroom').val(obj['project'][0].project_livingroom);
    // }
    // if(obj['project'][0].project_bathroom!=''){
    //   $('#project_bathroom').val(obj['project'][0].project_bathroom);
    // }
   /* $('#meta_key').val(obj['service'][0].meta_key);
        $('#meta_title').val(obj['service'][0].meta_title);
        $('#meta_desc').val(obj['service'][0].meta_description);*/
  }); 
}

function changeServiceStatus(serviceId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeServiceStatus', { 'serviceId':serviceId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#ProjectTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteservice(serviceId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteService', { 'serviceId':serviceId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#ServiceTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }





function getAddSliderById(serviceId){
    //var serviceId='10';
    //alert(projectId);

     resetForm('addSliderForm');
  lockModal('addSliderModal');
  showModal('addSliderModal');
  $('#addSliderModal').find(".modal-title").html("");
  $('#addSliderModal').find(".modal-title").html("Add Slider");
  $('.error').remove();
  $('#serviceid').val(serviceId);

    var url="admin/getAddSliderById";
    data={serviceId:serviceId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
      var table = $('#addSliderlistTable').DataTable({
        "searching": true,
        "pageLength": 20 ,
        "destroy": true,
        "rowReorder": true,
       /* "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
          
          decorateRow();
          //return nRow; 
          } */
        });
      var rows = table.rows().remove().draw();
       obj = $.parseJSON(succ);
       console.log(obj);
       
      $.each(obj['result'], function(i,v) {

//console.log(obj['result'][i].detail_title)
      

      if(obj['result'][i].status==1){
        var status ='<a href="javascript:void(0);" onclick="changeaddSliderStatus('+obj['result'][i].slider_id+','+obj['result'][i].status+');" data-toggle="tooltip" title="active !" "="" style="text-decoration:none;"><span class="label btn-primary">Active</span></a>';
      }else{
        var status ='<a href="javascript:void(0);" onclick="changeaddSliderStatus('+obj['result'][i].slider_id+','+obj['result'][i].status+');" data-toggle="tooltip" title="Inactive!" style="text-decoration:none;"><span class="cancel btn btn-xs btn-danger btn-default">Inactive</span></a>';
      }
      var action='<a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="EDIT" onclick="editaddSlider('+obj['result'][i].slider_id+');"> <i class="fa fa-pencil"></i> </a> <a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="Delete!" onclick="deleteAddSlider('+obj['result'][i].slider_id+');"><i class="fa fa-times"></i></a>';
    


   // var th= '<th>Title</th><th style="width: 17px;">Description</th>';
    var th= '<th>Title</th>';

    if(obj['result'][i].slider_beforeimage){
          var imgsrc=base_url+obj['result'][i].slider_beforeimage;
          var image="<img src="+imgsrc+" style='height: 38px;width: 100%;border-radius: 20%;'></img>";
        }else{
          var imgsrc=base_url+"assets/images/noimage.png";
          var image="<img src="+imgsrc+" style='height: 38px;width: 100%;border-radius: 20%;'></img>"; 
        } 
    if(obj['result'][i].slider_afterimage){
          var imgsrc2=base_url+obj['result'][i].slider_afterimage;
          var image2="<img src="+imgsrc2+" style='height: 38px;width: 100%;border-radius: 20%;'></img>";
        }else{
          var imgsrc2=base_url+"assets/images/noimage.png";
          var image2="<img src="+imgsrc2+" style='height: 38px;width: 100%;border-radius: 20%;'></img>"; 
        } 
        var rowIndex= $('#addSliderlistTable').dataTable().fnAddData([
          (i+1),
          image,
          // image2,
          //obj['result'][i].slider_title,         
         // obj['result'][i].detail_dis,
          status,
          action
        ]);

         var row = $('#addSliderlistTable').dataTable().fnGetNodes(rowIndex);
        $(row).attr('id',"row_"+obj['result'][i].slider_id);

          });
          });


   }


   function saveaddSlider(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);
    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
          showLoader();
            }, 
        success: function (obj)
        {
         hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
                  getAddSliderById($('#serviceid').val());
                  $('#imgbox_2').attr('src',base_url+'assets/images/noimage.png');
                  $('#imgbox_3').attr('src',base_url+'assets/images/noimage.png');
                  //checkGalleryWithInfoOrWithoutInfo($('#uploadType').val());
                  /*var $radios1 = $('input:radio[name=gallaryWithInfo]');
                  $radios1.filter('[value='+$('#uploadType').val()+']').prop('checked', true);*/
                  $('#cancelBtn').hide();
                /*$('.gallaryInfo').show();
                $('.withoutGallaryInfo').hide();*/
            },2000) 
        }
        if (obj.err == 1)
        { 
        showErrorMessage(formId,obj.msg);           
        }
    
        if (obj.err == 2)
        {
          appendMessageBody(formId);
          showDatabaseErrorMessage(formId,obj.msg);  
        }
      }
    });
  }

  function subdecorateRow(){
  //console.log('Yes');
   var SearchFieldsTable = $("#addSliderlistTable tbody");
    var trows = SearchFieldsTable.children("tr");
     var ids=[];
    var newPostion=[];
 
   
    $.each(trows, function (index, row1) {
      rowId = $(row1).attr("id");
      ids.push(rowId);
      newPostion.push(index+1);
    });

    var url="admin/updateaddSliderPosition";
    data={id:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
  var serviceid=$('#serviceid').val();

       getAddSliderById(serviceid);
    // obj = $.parseJSON(succ);
        console.log(succ);
  
      });
      

}

function deleteAddSlider(addsliderId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteAddSlider', { 'addsliderId':addsliderId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var serviceid=$('#serviceid').val();
              getAddSliderById(serviceid);
              /*var dt = $("#addSliderlistTable").DataTable();
              dt.ajax.reload(null, false);*/
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });


  
  }


  function changeaddSliderStatus(addsliderId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeAddSliderStatus', { 'addsliderId':addsliderId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var serviceid=$('#serviceid').val();
              getAddSliderById(serviceid);
         /* var dt = $("#addSliderlistTable").DataTable();
          dt.ajax.reload(null, false);*/
        },2000)
    })
}

function editaddSlider(addsliderId){
    var url="admin/getaddSliderbysliderId";
    data={addsliderId:addsliderId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
    // $('#addtitle').val(obj['addslider'][0].slider_title);
    // $('#adddes').val(obj['addslider'][0].slider_dis);

    if(obj['addslider'][0].slider_beforeimage){
     var imgsrc=base_url+obj['addslider'][0].slider_beforeimage;
    }else{
      var imgsrc=base_url+"assets/images/noimage.png";
    }
    if(obj['addslider'][0].slider_afterimage){
     var imgsrc2=base_url+obj['addslider'][0].slider_afterimage;
    }else{
      var imgsrc2=base_url+"assets/images/noimage.png";
    }

    $('#imgbox_2').attr('src',imgsrc);
    $('#sliderbefore_image_old').val(obj['addslider'][0].slider_beforeimage);

    $('#imgbox_3').attr('src',imgsrc2);
    $('#sliderafter_image_old').val(obj['addslider'][0].slider_afterimage);
    
    $('#sliderserviceId').val(addsliderId);
    $('#cancelBtn').show();
        
      $('#addSliderModal').animate({
          scrollTop: $("#addSliderModal").first().offset().top - 250
      }, 1000);
  });
}