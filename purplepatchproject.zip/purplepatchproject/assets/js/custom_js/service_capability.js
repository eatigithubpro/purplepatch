$(document).ready(function(){ 
  /*$("#addcreative").click(function(){
    //alert(kac);
    var newDiv = '<div><div class="row "><div class="col-md-5"><label>Add Title</label><input type="text" id="addtitle" name="addtitle[]" placeholder="Enter Add Title" class="form-control"></div><div class="col-md-5"><label>Add Description</label><textarea type="text" id="adddes" class="form-control" name="adddes[]" placeholder="Add Description."></textarea></div><div class="col-md-1 optionBox"><a href="javascript:void(0)" class="removecross" onclick="crossonclick(this);" ><i class="fa fa-times "></i></a></div></div><hr></div>'; 
    */

    /*var newDiv = '<div class="row"><div class="col-md-5"><label>Add Title</label><input type="text" id="addtitle" name="addtitle[]" placeholder="Enter Add Title" class="form-control"></div><div class="col-md-5"><label>Add Description</label><textarea type="text" id="adddes" class="form-control" name="adddes" placeholder="Add Description."></textarea></div><div class="col-md-1"><span class="remove">Remove Option</span></div></div><hr>';*/
  //newDiv.style.background = "#000";
 /* console.log(newDiv);
   $('#creativecontentlist').append(newDiv);
  });*/


  //$('.optionBox').on('click','.remove',function() {
    /*$("#removecross").click(function(){
      alert('adnclk')
    //console.log($(this).parent().parent());
   //$(this).parent().parent().remove();
  // $(this).parent().remove();
  });*/

var table = $('#addDetaillistTable').DataTable({
        "searching": true,
        "destroy": true,
        "rowReorder": true,
        "pageLength": 20 
        });
      table.on( 'row-reorder', function ( e, diff, edit ) {
          subdecorateRow();
    });

  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  my_sortable = $('#serviceCapabilityTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/serviceCapabilityList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
        { sWidth: '40%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' } 
      ]
    });

  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#serviceCapabilityTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    console.log("id "+ids+" pos "+newPostion );
    var url="admin/updateServiceCapabilityPosition";
    data={menuId:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    //obj = $.parseJSON(succ);
      //alert("Success");
        swal({
          type: 'success',
          title: 'Success',
          showConfirmButton: false,
          timer: 2000
        });

      });
    });

    $('#serviceCapabilityTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
});

function addNew(){
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');
  resetForm('serviceCapabilityForm');
  lockModal('serviceCapabilityModal');
  showModal('serviceCapabilityModal');
  $('#serviceCapabilityModal').find(".modal-title").html("");
  $('#serviceCapabilityModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}

function saveServiceCapability(formId,url){ 
    var descp =CKEDITOR.instances["description"].getData();
    document.getElementById("description").value=descp;

    /*var descp2 =CKEDITOR.instances["short_description"].getData();
    document.getElementById("short_description").value=descp2;*/
  pro= saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
      {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#serviceCapabilityModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          var dt = $("#serviceCapabilityTable").DataTable();
          dt.ajax.reload(null, false);
          close_modal('serviceCapabilityModal');
        },2000)
      }
    if (obj.err == 1)
    {
      $('#serviceCapabilityModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }

    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#serviceCapabilityModal').animate({scrollTop : 0}, 'slow');  
    }
  })
 
}

  function editGrowingCompany(id){
    CKEDITOR.instances['description'].setData('');
    $("#updatdId").val(id);
    resetForm('serviceCapabilityForm');
    lockModal('serviceCapabilityModal');
    showModal('serviceCapabilityModal');
    $('#serviceCapabilityModal').find(".modal-title").html("");
    $('#serviceCapabilityModal').find(".modal-title").html("Edit");

    getServiceCapabilityById(id);
  }

function getServiceCapabilityById(id){
  var url="admin/getServiceCapabilityById";
  data={id:id};
  var pro = viewDetailsByData(data,url);
  pro.success(function (succ){
  obj = $.parseJSON(succ);
  console.log(obj['service'][0].description);

 // $('#description').val(obj['service'][0].description); 


  $('#service_title').val(obj['service'][0].title);
    if(obj['service'][0].image!=''){
      var imageurl = base_url+obj['service'][0].image;
      $('#service_image_old').val(obj['service'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    if(obj['service'][0].description!=''){
      CKEDITOR.instances['description'].setData(obj['service'][0].description);
    }
    /*
    if(obj['service'][0].short_description!=''){
      CKEDITOR.instances['short_description'].setData(obj['service'][0].short_description);
    }*/

    if(obj['service'][0].meta_key!=''){
      $('#meta_key').val(obj['service'][0].meta_key);
    }
    if(obj['service'][0].meta_title!=''){
      $('#meta_title').val(obj['service'][0].meta_title);
    }
    if(obj['service'][0].meta_description!=''){
      $('#meta_desc').val(obj['service'][0].meta_description);
    }
    /*if(obj['service'][0].short_description!=''){
      $('#short_description').val(obj['service'][0].short_description);
    }*/
  }); 
}

function changeServiceCapabilityStatus(serviceId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeServiceCapabilityStatus', { 'serviceId':serviceId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#serviceCapabilityTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteServiceCapability(serviceId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteServiceCapability', { 'serviceId':serviceId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#serviceCapabilityTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });


  
  }

  /*function crossonclick(value){
    //console.log(value.parent());
    $(value).parent().parent().parent().remove();
  }*/
 /*$('.optionBox').on('click','.removecross',function() {
   // $("#removecross").click(function(){
      alert('adnclk')
    //console.log($(this).parent().parent());
   //$(this).parent().parent().remove();
  // $(this).parent().remove();
  });
*/
/* $(".removecross").click(function(){
  alert('sdvs')
   });*/

   function getAdddetailById(serviceId){
    //var serviceId='10';

     resetForm('addDetailForm');
  lockModal('adddetailModal');
  showModal('adddetailModal');
  $('#adddetailModal').find(".modal-title").html("");
  $('#adddetailModal').find(".modal-title").html("Service Add Detail");
  $('.error').remove();
  $('#servicesid').val(serviceId);

    var url="admin/getAdddetailById";
    data={serviceId:serviceId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
      var table = $('#addDetaillistTable').DataTable({
        "searching": true,
        "pageLength": 20 ,
        "destroy": true,
        "rowReorder": true,
       /* "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
          
          decorateRow();
          //return nRow; 
          } */
        });
      var rows = table.rows().remove().draw();
       obj = $.parseJSON(succ);
       console.log(obj);
       
      $.each(obj['result'], function(i,v) {

//console.log(obj['result'][i].detail_title)
      

      if(obj['result'][i].status==1){
        var status ='<a href="javascript:void(0);" onclick="changeaddDetailStatus('+obj['result'][i].detail_id+','+obj['result'][i].status+');" data-toggle="tooltip" title="active !" "="" style="text-decoration:none;"><span class="label btn-primary">Active</span></a>';
      }else{
        var status ='<a href="javascript:void(0);" onclick="changeaddDetailStatus('+obj['result'][i].detail_id+','+obj['result'][i].status+');" data-toggle="tooltip" title="Inactive!" style="text-decoration:none;"><span class="cancel btn btn-xs btn-danger btn-default">Inactive</span></a>';
      }
      var action='<a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="EDIT" onclick="editaddDetail('+obj['result'][i].detail_id+');"> <i class="fa fa-pencil"></i> </a> <a href="javascript:void(0);" data-placement="left" data-toggle="tooltip" class="tooltips" data-original-title="Delete!" onclick="deleteAddDetail('+obj['result'][i].detail_id+');"><i class="fa fa-times"></i></a>';
    


   // var th= '<th>Title</th><th style="width: 17px;">Description</th>';
    var th= '<th>Title</th>';
        var rowIndex= $('#addDetaillistTable').dataTable().fnAddData([
          (i+1),
          obj['result'][i].detail_title,         
         // obj['result'][i].detail_dis,
          status,
          action
        ]);

         var row = $('#addDetaillistTable').dataTable().fnGetNodes(rowIndex);
        $(row).attr('id',"row_"+obj['result'][i].detail_id);

          });
          });


   }


   function saveaddDetail(formId,url){ 
    var form = $('#'+formId)[0];
    var formData = new FormData(form);
    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
         beforeSend: function(){
          showLoader();
            }, 
        success: function (obj)
        {
         hideLoader();
      if (obj.err == 0)
        {
        appendMessageBody(formId);
        showSuccessMessage(formId,obj.msg); 
            setTimeout(function(){
                  getAdddetailById($('#servicesid').val());
                  //checkGalleryWithInfoOrWithoutInfo($('#uploadType').val());
                  /*var $radios1 = $('input:radio[name=gallaryWithInfo]');
                  $radios1.filter('[value='+$('#uploadType').val()+']').prop('checked', true);*/
                  $('#cancelBtn').hide();
                /*$('.gallaryInfo').show();
                $('.withoutGallaryInfo').hide();*/
            },2000) 
        }
        if (obj.err == 1)
        { 
        showErrorMessage(formId,obj.msg);           
        }
    
        if (obj.err == 2)
        {
          appendMessageBody(formId);
          showDatabaseErrorMessage(formId,obj.msg);  
        }
      }
    });
  }

  function subdecorateRow(){
  //console.log('Yes');
   var SearchFieldsTable = $("#addDetaillistTable tbody");
    var trows = SearchFieldsTable.children("tr");
     var ids=[];
    var newPostion=[];
 
   
    $.each(trows, function (index, row1) {
      rowId = $(row1).attr("id");
      ids.push(rowId);
      newPostion.push(index+1);
    });

    var url="admin/updateaddDetailPosition";
    data={id:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
  var servicesid=$('#servicesid').val();

       getAdddetailById(servicesid);
    // obj = $.parseJSON(succ);
        console.log(succ);
  
      });
      

}

function deleteAddDetail(adddetailId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteAddDetail', { 'adddetailId':adddetailId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var servicesid=$('#servicesid').val();
              getAdddetailById(servicesid);
              /*var dt = $("#addDetaillistTable").DataTable();
              dt.ajax.reload(null, false);*/
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });


  
  }


  function changeaddDetailStatus(adddetailId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeAddDetailStatus', { 'adddetailId':adddetailId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var servicesid=$('#servicesid').val();
              getAdddetailById(servicesid);
         /* var dt = $("#addDetaillistTable").DataTable();
          dt.ajax.reload(null, false);*/
        },2000)
    })
}

function editaddDetail(adddetailId){
    var url="admin/getadddetailbyIdb";
    data={adddetailId:adddetailId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (suc){
    obj = $.parseJSON(suc);
    console.log(obj);
    $('#addtitle').val(obj['adddetail'][0].detail_title);
    $('#adddes').val(obj['adddetail'][0].detail_dis);
    
    $('#updatedId').val(adddetailId);
    $('#cancelBtn').show();
        
      $('#adddetailModal').animate({
          scrollTop: $("#adddetailModal").first().offset().top - 250
      }, 1000);
  });
}