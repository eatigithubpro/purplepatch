
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  //getRecord();
  my_sortable = $('#sliderTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/sliderList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
        { sWidth: '30%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '10%' } 
      ]
    });

  my_sortable.on('row-reorder', function ( e, diff, edit ) {
    var SearchFieldsTable = $("#sliderTable tbody");

    var trows = SearchFieldsTable.children("tr");
    var ids=[];
    var newPostion=[];
    $.each(trows, function (index, row) {
      ids.push($(row).attr("id").split("_")[1]);
      newPostion.push(index+1);
    });
    console.log("id "+ids+" pos "+newPostion );
    var url="admin/updateSliderPosition";
    data={menuId:ids,newPostion:newPostion};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    //obj = $.parseJSON(succ);
      //alert("Success");
        swal({
          type: 'success',
          title: 'Success',
          showConfirmButton: false,
          timer: 2000
        });

      });
    });

    $('#sliderTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
});

function addNew(){
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");

 /* $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');*/

  resetForm('sliderForm');
  lockModal('sliderModal');
  showModal('sliderModal');
  $('#sliderModal').find(".modal-title").html("");
  $('#sliderModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function showimagepreview(input,count) {

  var fuData = input;
    var FileUploadPath = fuData.value;
  var Extension = FileUploadPath.substring(
                FileUploadPath.lastIndexOf('.') + 1).toLowerCase();
  if (Extension == "gif" || Extension == "png" || Extension == "bmp"|| Extension == "jpeg" || Extension == "jpg" || Extension == "svg")
     {
      if (input.files && input.files[0]) {
        var filerdr = new FileReader();
        filerdr.onload = function(e) {
          $('#imgbox_'+count).attr('src', e.target.result);
        //console.log($('#imgbox_'+count).attr('src', e.target.result));
        }
        filerdr.readAsDataURL(input.files[0]);
      }
    }else{
      alert('Invalid Image.');
      $('#imgbox_'+count).attr('src',base_url+'assets/images/noimage.png');
    }
    
}

function saveSlider(formId,url){ 
  pro= saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
      {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#sliderModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          var dt = $("#sliderTable").DataTable();
          dt.ajax.reload(null, false);
          close_modal('sliderModal');
        },2000)
      }
    if (obj.err == 1)
    {
      $('#sliderModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }

    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#sliderModal').animate({scrollTop : 0}, 'slow');  
    }
  })
 
}

  function editSlider(id){

    $("#updatdId").val(id);
    resetForm('sliderForm');
    lockModal('sliderModal');
    showModal('sliderModal');
    $('#sliderModal').find(".modal-title").html("");
    $('#sliderModal').find(".modal-title").html("Edit Vision");

    getSliderById(id);
  }

function getSliderById(id){
  var url="admin/getSliderById";
  data={id:id};
  var pro = viewDetailsByData(data,url);
  pro.success(function (succ){
  obj = $.parseJSON(succ);
  $('#slider_title').val(obj['slider'][0].title);

    if(obj['slider'][0].sub_title!=''){
      $('#slider_sub_title').val(obj['slider'][0].sub_title);
    }
    if(obj['slider'][0].link_detail!=''){
      $('#slider_link_detail').val(obj['slider'][0].link_detail);
    }

    if(obj['slider'][0].image!=''){
      var imageurl = base_url+obj['slider'][0].image;
      $('#slider_image_old').val(obj['slider'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    // if(obj['slider'][0].video!=''){
    //   $('#video_url').val(obj['slider'][0].video);
    // }
    if(obj['slider'][0].meta_key!=''){
      $('#meta_key').val(obj['slider'][0].meta_key);
    }
    if(obj['slider'][0].meta_title!=''){
      $('#meta_title').val(obj['slider'][0].meta_title);
    }
    if(obj['slider'][0].meta_description!=''){
      $('#meta_desc').val(obj['slider'][0].meta_description);
    }
  }); 
}

function changeSliderStatus(sliderId,status){
  //console.log("test");
  if(status==1){
    var msg = "Successfully Inactive."
  }else{
   var msg = "Successfully Activated." 
  }

    $.post(base_url+'admin/changeSliderStatus', { 'sliderId':sliderId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: msg,
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#sliderTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteSlider(sliderId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteSlider', { 'sliderId':sliderId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#sliderTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }

/*function showImage(sliderId){
  lockModal('ImageModal');
  showModal('ImageModal');
  $('#ImageModal').find(".modal-title").html("");
  $('#ImageModal').find(".modal-title").html("All Image");
    var url="admin/getslider";
    data={sliderId:sliderId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);
    console.log(obj['sliderlist'][0])
      var imageurl=base_url+'assets/uploads/slider/'+obj['sliderlist'][0].image;
      $('#viewsliderimage').attr('src', imageurl);
    });
  }*/

