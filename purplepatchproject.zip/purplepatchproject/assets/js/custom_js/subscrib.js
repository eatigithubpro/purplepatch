
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  getRecord();
});
function getRecord(){
  $('#subscriberTable').DataTable({
    "destroy": true,
    "bProcessing": true,
    "language": {
        processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
    "serverSide": true,
    "rowReorder": true,
     "ajax":{
      url :base_url+"admin/subscribList",
      type: "post"
    }
  });
  $('#subscriberTable').on('draw.dt', function () {
    $('.popoverData').popover({ trigger: "hover" });
    $('[data-toggle="tooltip"]').tooltip();
  });
}

function addNew(){
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  resetForm('subscriberForm');
  lockModal('subscriberModal');
  showModal('subscriberModal');
  $('#subscriberModal').find(".modal-title").html("");
  $('#subscriberModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function saveClient(formId,url){ 
  var pro = saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
    {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#subscriberModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          getRecord()
          close_modal('subscriberModal');
        },2000)
    }
    if (obj.err == 1)
    {
      $('#subscriberModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }
  
    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#subscriberModal').animate({scrollTop : 0}, 'slow');  
    }
  })
}

  function editClient(id){
    $("#updatdId").val(id);
    resetForm('subscriberForm');
    lockModal('subscriberModal');
    showModal('subscriberModal');
    $('#subscriberModal').find(".modal-title").html("");
    $('#subscriberModal').find(".modal-title").html("Edit Subscriber.");
    getSubscriber(id);
  }

function getSubscriber(id){
    var url="admin/getSubscriberById";
    data={id:id};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);

    $('#name').val(obj['our_client'][0].name);
    
    if(obj['our_client'][0].profile_image!=''){
      var imageurl = base_url+obj['our_client'][0].image;
      $('#client_image_old').val(obj['our_client'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

  
    $('#meta_key').val(obj['our_client'][0].meta_key);
    $('#meta_title').val(obj['our_client'][0].meta_title);
    $('#meta_desc').val(obj['our_client'][0].meta_desc);

    }); 
  }

function changeSubscriberStatus(subcribId){
  //console.log("test");
    $.post(base_url+'admin/changeSubscriberStatus', { 'subcribId':subcribId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#subscriberTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}


function deleteSubscriber(subscribId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteSubscriber', { 'subscribId':subscribId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#subscriberTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }
