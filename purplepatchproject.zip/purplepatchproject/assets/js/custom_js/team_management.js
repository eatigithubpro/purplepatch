
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  getRecord();
});
function getRecord(){
  $('#teamManagementTable').DataTable({
    "destroy": true,
    "bProcessing": true,
    "language": {
        processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
    "serverSide": true,
    "rowReorder": true,
     "ajax":{
      url :base_url+"admin/teamManagementList",
      type: "post",
      error: function(){
        $("#employee_grid_processing").css("display","none");
      }
    },
    "aoColumns": [
      { sWidth: '8%' },
      { sWidth: '10%' },
      { sWidth: '10%' },
      { sWidth: '10%' },
      { sWidth: '10%' },
      { sWidth: '22%' },
      { sWidth: '10%' },
      { sWidth: '10%' } 
    ]
  });
  $('#teamManagementTable').on('draw.dt', function () {
    $('.popoverData').popover({ trigger: "hover" });
    $('[data-toggle="tooltip"]').tooltip();
  });
}

function addNew(){
  $('#imgbox_0').attr('src',base_url+"assets/images/noimage.png");
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');

  resetForm('teamManagementForm');
  lockModal('teamManagementModal');
  showModal('teamManagementModal');
  $('#teamManagementModal').find(".modal-title").html("");
  $('#teamManagementModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function saveTeamManagement(formId,url){ 
  var descp = CKEDITOR.instances["description"].getData();
  document.getElementById("description").value = descp;

  var pro = saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
    {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#teamManagementModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          getRecord()
          close_modal('teamManagementModal');
        },2000)
    }
    if (obj.err == 1)
    {
      $('#teamManagementModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }
  
    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#teamManagementModal').animate({scrollTop : 0}, 'slow');  
    }
  })
}

  function editMamagement(id){
    $("#updatdId").val(id);
    resetForm('teamManagementForm');
    lockModal('teamManagementModal');
    showModal('teamManagementModal');
    $('#teamManagementModal').find(".modal-title").html("");
    $('#teamManagementModal').find(".modal-title").html("Edit Team Management");
    getMamagement(id);
  }

function getMamagement(id){

    var url="admin/getMamagementById";
    data={id:id};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);

    $('#title').val(obj['team_management'][0].title);
    $('#team_type').val(obj['team_management'][0].team_type);
    $('#designation').val(obj['team_management'][0].designation);
    if(obj['team_management'][0].profile_image!=''){
      var imageurl = base_url+obj['team_management'][0].profile_image;
      $('#profile_image_old').val(obj['team_management'][0].profile_image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    CKEDITOR.instances['description'].setData(obj['team_management'][0].description);
    $('#meta_key').val(obj['team_management'][0].meta_key);
    $('#meta_title').val(obj['team_management'][0].meta_title);
    $('#meta_desc').val(obj['team_management'][0].meta_desc);

    }); 
  }



function changeManagementStatus(managementId){
  //console.log("test");
    $.post(base_url+'admin/changeManagementStatus', { 'managementId':managementId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#teamManagementTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}


function deleteManagement(managementId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteManagement', { 'managementId':managementId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#teamManagementTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }
