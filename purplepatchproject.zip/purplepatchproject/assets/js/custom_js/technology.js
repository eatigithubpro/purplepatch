
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  getRecord();
});
function getRecord(){
    $('#technologyTable').DataTable({
      "destroy": true,
      "bProcessing": true,
      "language": {
            processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
      "serverSide": true,
      "rowReorder": true,
       "ajax":{
        url :base_url+"admin/technologyList",
        type: "post",
        error: function(){
          $("#employee_grid_processing").css("display","none");
        }
      },
      "aoColumns": [
        { sWidth: '10%' },
        { sWidth: '20%' },
        { sWidth: '10%' },
        { sWidth: '10%' },
        { sWidth: '30%' },
        { sWidth: '10%' },
        { sWidth: '10%' } 
      ]
    });
    $('#technologyTable').on('draw.dt', function () {
      $('.popoverData').popover({ trigger: "hover" });
      $('[data-toggle="tooltip"]').tooltip();
    });
  }

function addNew(){
  $('#imgbox_0').attr('src',base_url+"assets/images/noimage.png");
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');

  resetForm('technologyForm');
  lockModal('technologyModal');
  showModal('technologyModal');
  $('#technologyModal').find(".modal-title").html("");
  $('#technologyModal').find(".modal-title").html("Add New");
  $("#updatdId").val('');
}

function saveTechnology(formId,url){ 
  var descp = CKEDITOR.instances["description"].getData();
  document.getElementById("description").value = descp;

  var pro = saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
    {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#technologyModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          getRecord()
          close_modal('technologyModal');
        },2000)
    }
    if (obj.err == 1)
    {
      $('#technologyModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }
  
    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#technologyModal').animate({scrollTop : 0}, 'slow');  
    }
  })
}

  function editTechnology(id){
    $("#updatdId").val(id);
    resetForm('technologyForm');
    lockModal('technologyModal');
    showModal('technologyModal');
    $('#technologyModal').find(".modal-title").html("");
    $('#technologyModal').find(".modal-title").html("Edit Technology");
    getTechnology(id);
  }

function getTechnology(id){

    var url="admin/getTechnologyById";
    data={id:id};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);

    $('#technology_title').val(obj['technology'][0].title);

   
    if(obj['technology'][0].image!=''){
      var imageurl = base_url+obj['technology'][0].image;
      $('#technology_image_old').val(obj['technology'][0].image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);



    if(obj['technology'][0].thumbnail_image!=''){
      var imageurl = base_url+obj['technology'][0].logo;
       $('#logo_old').val(obj['technology'][0].logo);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_0').attr('src', imageurl);
    CKEDITOR.instances['description'].setData(obj['technology'][0].description);
    $('#meta_key').val(obj['technology'][0].meta_key);
    $('#meta_title').val(obj['technology'][0].meta_title);
    $('#meta_desc').val(obj['technology'][0].meta_desc);

    }); 
  }



function changeTechnologyStatus(technologyId){
  //console.log("test");
    $.post(base_url+'admin/changeTechnologyStatus', { 'technologyId':technologyId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#technologyTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}




function deleteTechnology(technologyId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteTechnology', { 'technologyId':technologyId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#technologyTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }

/*function showImage(sliderId){
  lockModal('ImageModal');
  showModal('ImageModal');
  $('#ImageModal').find(".modal-title").html("");
  $('#ImageModal').find(".modal-title").html("All Image");
    var url="admin/getslider";
    data={sliderId:sliderId};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);
    console.log(obj['sliderlist'][0])
      var imageurl=base_url+'assets/uploads/slider/'+obj['sliderlist'][0].image;
      $('#viewsliderimage').attr('src', imageurl);
    });
  }*/

