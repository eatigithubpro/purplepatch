
$(document).ready(function(){ 
  $('.popoverData').popover();
  $('[data-toggle="tooltip"]').tooltip();
  getRecord();
  $( "#stars li.star" ).click(function() {
   // alert('teees')
    var startvalue=$(this).data('value');
    $("#starvalue").val(startvalue);
    for (i = 1; i <= startvalue; i++) {
      console.log(i+' i ')
     $("#"+i).children().addClass("fa-star");
     $("#"+i).children().removeClass("fa-star-o");
    }
    var getstartvalue=5-startvalue;
    console.log(getstartvalue+' getstartvalue ')
    for (j = 5; j > startvalue; j--) {
      console.log(j+' j ')
     $("#"+j).children().addClass("fa-star-o");
     $("#"+j).children().removeClass("fa-star");
    }
  });
});

function getRecord(){
  $('#testimonialTable').DataTable({
    "destroy": true,
    "bProcessing": true,
    "language": {
        processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> ' },
    "serverSide": true,
    "rowReorder": true,
     "ajax":{
      url :base_url+"admin/testimonialList",
      type: "post",
      error: function(){
        $("#employee_grid_processing").css("display","none");
      }
    },
    "aoColumns": [
      { sWidth: '10%' },
      { sWidth: '20%' },
      { sWidth: '10%' },
      { sWidth: '20%' },
      { sWidth: '24%' },
      { sWidth: '8%' },
      { sWidth: '8%' } 
    ]
  });
  $('#testimonialTable').on('draw.dt', function () {
    $('.popoverData').popover({ trigger: "hover" });
    $('[data-toggle="tooltip"]').tooltip();
  });
}

function addNew(){
  $('#imgbox_1').attr('src',base_url+"assets/images/noimage.png");
  CKEDITOR.instances['description'].setData('');

  resetForm('testimonialForm');
  lockModal('testimonialModal');
  showModal('testimonialModal');
  $('#testimonialModal').find(".modal-title").html("");
  $('#testimonialModal').find(".modal-title").html("Add New");
   $("#updatdId").val('');
}

function saveTestimonial(formId,url){ 
  var descp = CKEDITOR.instances["description"].getData();
  document.getElementById("description").value = descp;

  var pro = saveRecord(formId,url);
  pro.success(function(obj){
    if (obj.err == 0)
    {
      appendMessageBody(formId);
      showSuccessMessage(formId,obj.msg); 
      $('#testimonialModal').animate({scrollTop : 0}, 'slow'); 
        setTimeout(function(){
          getRecord()
          close_modal('testimonialModal');
        },2000)
    }
    if (obj.err == 1)
    {
      $('#testimonialModal').animate({scrollTop : 0}, 'slow'); 
      showErrorMessage(formId,obj.msg);
    }
  
    if (obj.err == 2)
    {
      appendMessageBody(formId);
      showDatabaseErrorMessage(formId,obj.msg);
      $('#testimonialModal').animate({scrollTop : 0}, 'slow');  
    }
  })
}

  function editTestimonial(id){
    $("#updatdId").val(id);
    resetForm('testimonialForm');
    lockModal('testimonialModal');
    showModal('testimonialModal');
    $('#testimonialModal').find(".modal-title").html("");
    $('#testimonialModal').find(".modal-title").html("Edit Testimonial.");
    getTestimonial(id);
  }

function getTestimonial(id){
    var url="admin/getTestimonialById";
    data={id:id};
    var pro = viewDetailsByData(data,url);
    pro.success(function (succ){
    obj = $.parseJSON(succ);
    console.log(obj)

    $('#name').val(obj['testimonial'][0].name);
    $('#designation').val(obj['testimonial'][0].designation);
    if(obj['testimonial'][0].profile_image!=''){
      var imageurl = base_url+obj['testimonial'][0].profile_image;
      $('#profile_image_old').val(obj['testimonial'][0].profile_image);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);

    CKEDITOR.instances['description'].setData(obj['testimonial'][0].description);
    var startvalue=obj['testimonial'][0].starvalue;
    //alert(startvalue)

    for (i = 1; i <= startvalue; i++) {
      //console.log(i+' i ')
     $("#"+i).children().addClass("fa-star");
     $("#"+i).children().removeClass("fa-star-o");
    }
     $('#publish_date').val(obj['testimonial'][0].publish_date);
    $('#starvalue').val(obj['testimonial'][0].starvalue);
    // $('#meta_key').val(obj['testimonial'][0].meta_key);
    // $('#meta_title').val(obj['testimonial'][0].meta_title);
    // $('#meta_desc').val(obj['testimonial'][0].meta_desc);

    }); 
  }

function changeTestimonialStatus(testimonialId){
  //console.log("test");
    $.post(base_url+'admin/changeTestimonialStatus', { 'testimonialId':testimonialId })
      .done(function(response){
      console.log(response);
        swal({
          type: 'success',
          title: 'Status successfully changed',
          showConfirmButton: false,
          timer: 2000
        });
        setTimeout(function(){
          var dt = $("#testimonialTable").DataTable();
          dt.ajax.reload(null, false);
        },2000)
    })
}


function deleteTestimonial(testimonialId){
  swal({
    title: "Do you want to delete ?",
    type: "warning",
    showCancelButton: true,
    confirmButtonClass: 'btn-success',
    confirmButtonText: 'Yes, delete it!',
    cancelButtonClass: "btn-danger",
    cancelButtonText: "No, cancel !",
    closeOnConfirm: false,
    closeOnCancel: false
  },
  function(isConfirm){
    if (isConfirm){
        $.post(base_url+'admin/deleteTestimonial', { 'testimonialId':testimonialId })
        .done(function(response){
            console.log(response);
            swal({
              type: 'success',
              title: 'Your file has been deleted',
              showConfirmButton: false,
              timer: 2000
            });
            setTimeout(function(){
              var dt = $("#testimonialTable").DataTable();
              dt.ajax.reload(null, false);
            },2000)
          })
          .fail(function(){
            swal({
              type: 'error',
              title: 'Something went wrong',
              showConfirmButton: false,
              timer: 1000
            });
          })
        }else{
        swal({
          type: 'error',
          title: 'Your file is safe',
          showConfirmButton: false,
          timer: 1000
        });
      }
    });
  }
