$(document).ready(function(){ 
    getPagecontent()
    // $('.multiSelectWithCheckbox').multiselect({
    //     columns: 1,
    //     placeholder: 'Select',
    //     search: true,
    //     selectAll: false
    // });

    // $('#pagesliderimage').multiSelect({
    //     columns: 1,
    //     placeholder: 'Select',
    //     search: true,
    //     selectAll: false
    // });


    // $('#ourteamlist').multiSelect({
    //     columns: 1,
    //     placeholder: 'Select',
    //     search: true,
    //     selectAll: false
    // });

  });
  function getPagecontent(){
    var url="admin/getPageContent";
    var page_id=$("#page_id").val();
      data={page_id:page_id};
      var pro = viewDetailsByData(data,url);
      pro.success(function (succ){
      obj = $.parseJSON(succ);
      console.log('eati')
      console.log(obj)
      console.log(obj['content'][0].content_id)
      console.log('sinah')
      if(obj['content'][0].content_title!=''|| obj['content'][0].content_title!=null){
        $('#pagetitle').val(obj['content'][0].content_title);
      }

      if(obj['content'][0].content_url!==''|| obj['content'][0].content_url!==null){
        $('#pageslug').val(obj['content'][0].content_url);
      }

      // if(obj['content'][0].content_slider_speed!==''|| obj['content'][0].content_slider_speed!==null){
      //   $('#slider_speed').val(obj['content'][0].content_slider_speed);
      // }

      // if(obj['content'][0].content_slider!==''|| obj['content'][0].content_slider!==null){
      //   if(obj['content'][0].content_slider){
      //         var datas1=obj['content'][0].content_slider;
      //         dataarray1=datas1.split(",");
      //         $("#pagesliderimage").val(dataarray1);
      //         $("#pagesliderimage").multiSelect("refresh");
      //       }
      // }


      if(obj['content'][0].content_aboutimage!=''){
      var imageurl = base_url+obj['content'][0].content_aboutimage;
      $('#about_image_old').val(obj['content'][0].content_aboutimage);
    }else{
      var imageurl = base_url+"assets/images/noimage.png";
    }
    $('#imgbox_1').attr('src', imageurl);


    if(obj['content'][0].content_abouttitle!=''|| obj['content'][0].content_abouttitle!=null){
        $('#abouttitle').val(obj['content'][0].content_abouttitle);
      }

    /*if(obj['content'][0].content_aboutsubtitle!=''|| obj['content'][0].content_aboutsubtitle!=null){
        $('#aboutsubtitle').val(obj['content'][0].content_aboutsubtitle);
      }

    if(obj['content'][0].content_aboutlink!=''|| obj['content'][0].content_aboutlink!=null){
        $('#aboutlink').val(obj['content'][0].content_aboutlink);
      }*/

      // if(obj['content'][0].content_aboutcontent!==''|| obj['content'][0].content_aboutcontent!==null){
      //   $('#aboutdis').val(obj['content'][0].content_aboutcontent);
      // }

      if(obj['content'][0].content_aboutcontent!=''){
        CKEDITOR.instances['aboutdis'].setData(obj['content'][0].content_aboutcontent);
      }



    // if(obj['content'][0].content_visiontitle!=''|| obj['content'][0].content_visiontitle!=null){
    //     $('#visiontitle').val(obj['content'][0].content_visiontitle);
    //   }

    // if(obj['content'][0].content_visionsubtitle!=''|| obj['content'][0].content_visionsubtitle!=null){
    //     $('#visionsubtitle').val(obj['content'][0].content_visionsubtitle);
    //   }

    // if(obj['content'][0].content_visionsdis!=''|| obj['content'][0].content_visionsdis!=null){
    //     $('#visiondis').val(obj['content'][0].content_visionsdis);
    //   }

    //   if(obj['content'][0].content_teamlist!==''|| obj['content'][0].content_teamlist!==null){
    //       if(obj['content'][0].content_teamlist){
    //             var datas6=obj['content'][0].content_teamlist;
    //             dataarray6=datas6.split(",");
    //             $("#ourteamlist").val(dataarray6);
    //             $("#ourteamlist").multiSelect("refresh");
    //           }
    //     }

    //     if(obj['content'][0].content_teamlisttitle!==''|| obj['content'][0].content_teamlisttitle!==null){
    //       $('#ourteamtitle').val(obj['content'][0].content_teamlisttitle);
    //     }
        




      $('#updatdId').val(obj['content'][0].content_id);
      $('#meta_key').val(obj['content'][0].content_meta_key);
        $('#meta_title').val(obj['content'][0].content_meta_title);
        $('#meta_desc').val(obj['content'][0].content_meta_desc);
    });
  }


function savePageContent(formId,url){ 
var page_id=$("#page_id").val();
  // if(page_id=='2'){
  // var descp =CKEDITOR.instances["weworkdis"].getData();
  //   document.getElementById("weworkdis").value=descp;
  // }
  var aboutdis =CKEDITOR.instances["aboutdis"].getData();
    document.getElementById("aboutdis").value=aboutdis;
    var form = $('#'+formId)[0];
    var formData = new FormData(form);

    $.ajax({
        url: base_url+url,
        type: "POST",
        dataType: "json",
        contentType: false,
        processData: false,
        data: formData,
        beforeSend: function(){
        //showLoader();
          }, 
        success: function (obj)
        {  
          console.log(obj);
          hideLoader();
          if (obj.err == 0)
          {

          appendMessageBody(formId);
          showSuccessMessage(formId,obj.msg);
           

            setTimeout(function(){
              getPagecontent();
            },2000)
          }
        if (obj.err == 1)
        {
          showErrorMessage(formId,obj.msg);
        }
    
      if (obj.err == 2)
      {
        appendMessageBody(formId);
        showDatabaseErrorMessage(formId,obj.msg);
      }
    }
  });
}
