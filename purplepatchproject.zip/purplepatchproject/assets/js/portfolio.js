$(document).ready(function() {

    $('#projects-1,#projects-2,#projects-3,#projects-4').owlCarousel({
        center: true,
        items: 1,
        loop: true,
        margin: 10,
        nav: false,
        autoplay: true,
        smartSpeed: 1500,
        responsive: {
            600: {
                items: 1
            }
        }
    });


});